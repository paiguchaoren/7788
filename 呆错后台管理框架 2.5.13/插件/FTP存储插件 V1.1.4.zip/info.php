<?php
return [
    //唯一标识
    'module'   => 'ftposs',
    //插件名称
    'name'     => 'FTP存储',
    //插件描述
    'info'     => '将附件同步传输到FTP服务器存储，可减轻网站服务器的负载与数据实时备份！',
    //插件版本
    'version'  => '1.1.4',
    //依赖数据库
    'datatype' => ['sqlite', 'mysql'],
    //依赖插件版本
    'rely'     => [
        'daicuo' => '2.4.22',
    ],
];