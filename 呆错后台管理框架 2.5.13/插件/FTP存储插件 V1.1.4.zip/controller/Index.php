<?php
namespace app\ftposs\controller;

use app\common\controller\Front;

class Index extends Front
{
    public function _initialize()
    {
        parent::_initialize();
    }
    
    public function index()
    {
        //DcConfig('common.site_applys.ftposs.version')
        return lang('ftposs/index/index');
    }
}