<?php
return [
    'ftposs/admin/index' => 'FTP存储',
    'ftposs/admin/error' => 'FTP模块不支持，请在php.ini里加载ftp扩展！',
    'ftposs/index/index' => '<a href="https://www.daicuo.org/store/ftposs" target="_blank">呆错存储插件（FtpOss）</a>',
    'ftp_status'         => '启用FTP远程附件',
    'ftp_pasv'           => '被动模式(pasv)连接',
    'ftp_unlink'         => '上传成功后删除本地附件',
    'ftp_host'           => 'FTP 服务器地址',	
    'ftp_port'           => 'FTP 服务器端口',
    'ftp_user'           => 'FTP 服务器帐号',	
    'ftp_pwd'            => 'FTP 服务器密码',
    'ftp_timeout'        => 'FTP 传输超时时间（秒）',
    'ftp_dir'            => '远程附件目录',
    'ftp_cdn'            => '远程访问 URL',
];