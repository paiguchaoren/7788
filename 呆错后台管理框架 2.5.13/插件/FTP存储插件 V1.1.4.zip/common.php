<?php
/**
 * 上传单个附件到远程
 * @version 1.0.1 首次引入
 * @param string $file 必需;本地附件列表,不带上传目录
 * @return bool
 */
function ftpossSave($file=''){
    //实例化FTP
    $ftp = new \app\ftposs\loglic\Ftp([
        'ftp_host'  => config('ftposs.ftp_host'),
        'ftp_port'  => config('ftposs.ftp_port'),
        'ftp_user'  => config('ftposs.ftp_user'),
        'ftp_pwd'   => config('ftposs.ftp_pwd'),
        'ftp_dir'   => config('ftposs.ftp_dir'),
        'ftp_pasv'  => config('ftposs.ftp_pasv'),
    ]);
    //链接FTP
    if(!$ftp->connect()){
        return false;
    }
    //相对路径（datas/attachment/20220219/01.jpg）
    $file = trim(config('common.upload_path')).'/'.$file;
    //上传文件
    $result = $ftp->put('./'.$file, $file);
    //关闭链接
    $ftp->bye();
    //返回结果
    return $result;
}

/**
 * 删除单个远程附件
 * @version 1.0.2 首次引入
 * @param string $file 必需;本地附件列表,不带上传目录
 * @return bool
 */
function ftpossDelete($file=''){
    //实例化FTP
    $ftp = new \app\ftposs\loglic\Ftp([
        'ftp_host'  => config('ftposs.ftp_host'),
        'ftp_port'  => config('ftposs.ftp_port'),
        'ftp_user'  => config('ftposs.ftp_user'),
        'ftp_pwd'   => config('ftposs.ftp_pwd'),
        'ftp_dir'   => config('ftposs.ftp_dir'),
        'ftp_pasv'  => config('ftposs.ftp_pasv'),
    ]);
    //链接FTP
    if(!$ftp->connect()){
        return false;
    }
    //相对路径（datas/attachment/20220219/01.jpg）
    $file = trim(config('common.upload_path'),'/').'/'.$file;
    //上传文件
    $result = $ftp->unlink($file);
    //关闭链接
    $ftp->bye();
    //返回结果
    return $result;
}

/**
 * 上传多个附件到远程
 * @version 1.0.2 首次引入
 * @param mixed $files 必需;本地附件列表,不带上传目录
 * @return bool
 */
function ftpossSaveAll($files=''){
    $results = [];
    //实例化FTP
    $ftp = new \app\ftposs\loglic\Ftp([
        'ftp_host'  => config('ftposs.ftp_host'),
        'ftp_port'  => config('ftposs.ftp_port'),
        'ftp_user'  => config('ftposs.ftp_user'),
        'ftp_pwd'   => config('ftposs.ftp_pwd'),
        'ftp_dir'   => config('ftposs.ftp_dir'),
        'ftp_pasv'  => config('ftposs.ftp_pasv'),
    ]);
    //链接FTP
    if(!$ftp->connect()){
        return false;
    }
    //转化为数组
    if(is_string($files)){
        $files = [$files];
    }
    //批量上传
    foreach($files as $key=>$file){
        //相对路径（datas/attachment/20220219/01.jpg）
        $file = trim(config('common.upload_path'),'/').'/'.$file;
        //上传文件
        $result = $ftp->put('./'.$file, $file);
        //上传结果
        array_push($results,$result);
    }
    //关闭链接
    $ftp->bye();
    //返回结果
    return $results;
}

/**
 * 删除多个远程附件
 * @version 1.0.2 首次引入
 * @param mixed $files 必需;本地附件列表,不带上传目录
 * @return bool
 */
function ftpossDeleteAll($files=''){
    $results = [];
    //实例化FTP
    $ftp = new \app\ftposs\loglic\Ftp([
        'ftp_host'  => config('ftposs.ftp_host'),
        'ftp_port'  => config('ftposs.ftp_port'),
        'ftp_user'  => config('ftposs.ftp_user'),
        'ftp_pwd'   => config('ftposs.ftp_pwd'),
        'ftp_dir'   => config('ftposs.ftp_dir'),
        'ftp_pasv'  => config('ftposs.ftp_pasv'),
    ]);
    //链接FTP
    if(!$ftp->connect()){
        return false;
    }
    //转化为数组
    if(is_string($files)){
        $files = [$files];
    }
    //批量删除
    foreach($files as $key=>$file){
        //相对路径（datas/attachment/20220219/01.jpg）
        $file = trim(config('common.upload_path'),'/').'/'.$file;
        //上传文件
        $result = $ftp->unlink($file);
        //上传结果
        array_push($results, $result);
    }
    //关闭链接
    $ftp->bye();
    //返回结果
    return $results;
}