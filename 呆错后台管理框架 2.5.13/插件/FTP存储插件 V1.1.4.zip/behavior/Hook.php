<?php
namespace app\ftposs\behavior;

class Hook
{
    //按定义的上传文件列表上传至远程文件（原始/水印/缩略图）
    public function uploadSaveAfter(&$params)
    {
        if($params["result"]['item'] && config('ftposs.ftp_status')){
            foreach($params["result"]['item'] as $key=>$value){
                //上传文件到远程
                $result = ftpossSave($value);
                //上传后删除本地
                if( $result && config('ftposs.ftp_unlink') ){
                    unset($params['upload']);//释放占用
                    @unlink('./'.trim(config('common.upload_path'),'/').'/'.$value);//删除本地
                }
            }
        }
    }
    
    //按定义的删除文件列表删除远程文件
    public function uploadDeleteAfter(&$params)
    {
        if($params['item'] && config('ftposs.ftp_status')){
            foreach($params['item'] as $key=>$value){
                $result = ftpossDelete($value);
            }
        }
    }
}