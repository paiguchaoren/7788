<?php
namespace app\ftposs\event;

use app\common\controller\Addon;

class Admin extends Addon
{
	
	public function _initialize()
    {
		parent::_initialize();
	}

	public function index()
    {
        if(!function_exists('ftp_connect')){
            $this->error(lang('ftposs/admin/index'));
        }
        
        $this->assign('fields', DcFormItems(model('ftposs/Admin','loglic')->fields()));
        
        return $this->fetch('ftposs@admin/index');
	}
    
    public function update()
    {
        $post = input('post.');
        $post['ftp_dir'] = '/'.ltrim($post['ftp_dir'],'/');
        $status = \daicuo\Op::write($post, 'ftposs', 'config', 'system' ,0, 'yes');
		if( !$status ){
		    $this->error(lang('fail'));
        }
        $this->success(lang('success'));
	}
}