<?php
namespace app\ftposs\loglic;

class Install
{
    public function mysql()
    {
        return true;
    }
    
    public function sqlite()
    {
        return true;
    }
}