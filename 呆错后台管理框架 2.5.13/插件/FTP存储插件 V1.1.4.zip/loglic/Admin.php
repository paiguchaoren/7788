<?php
namespace app\ftposs\loglic;

class admin
{
    protected $error = '';
    
    public function getError()
    {
        return $this->error;
    }
    
    public function fields($data=[])
    {
        return [
            'ftp_status'  => [
                'type'  => 'custom',
                'option'=> [1=>lang('yes'),0=>lang('no')],
                'value' => config('ftposs.ftp_status'),
            ],
            'ftp_pasv'  => [
                'type'  => 'custom',
                'option'=> [1=>lang('yes'),0=>lang('no')],
                'value' => intval(config('ftposs.ftp_pasv')),
            ],
            'ftp_unlink'  => [
                'type'  => 'custom',
                'option'=> [1=>lang('yes'),0=>lang('no')],
                'value' => config('ftposs.ftp_unlink'),
            ],
            'ftp_host'  => [
                'type'  => 'text',
                'value' => config('ftposs.ftp_host'),
                'required'   => true,
            ],
            'ftp_port'  => [
                'type'  => 'text',
                'value' => DcEmpty(config('ftposs.ftp_port'),21),
            ],
            'ftp_user'  => [
                'type'  => 'text',
                'value' => config('ftposs.ftp_user'),
            ],
            'ftp_pwd'  => [
                'type'  => 'text',
                'value' => config('ftposs.ftp_pwd'),
            ],
            'ftp_timeout' => [
                'type'  => 'text',
                'value' => intval(config('ftposs.ftp_timeout')),
            ],
            'ftp_dir'   => [
                'type'  => 'text',
                'value' => DcEmpty(config('ftposs.ftp_dir'),'/'),
            ],
        ];
    }
}