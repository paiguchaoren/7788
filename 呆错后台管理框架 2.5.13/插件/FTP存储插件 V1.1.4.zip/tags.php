<?php
return [
    'upload_save_after' => [
        'app\\ftposs\\behavior\\Hook',
    ],
    'upload_delete_after' => [
        'app\\ftposs\\behavior\\Hook',
    ],
];