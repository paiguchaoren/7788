<?php
namespace app\video\event;

use app\common\controller\Addon;

class Count extends Addon
{
	public function _initialize()
    {
		parent::_initialize();
	}
    
	public function index()
    {
        echo number_format(model('video/Count','loglic')->views());
	}
}