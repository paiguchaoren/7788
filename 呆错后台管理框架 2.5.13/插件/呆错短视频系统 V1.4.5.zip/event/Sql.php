<?php
namespace app\video\event;

class Sql
{
    /**
    * 安装时触发
    * @return bool 只有返回true时才会往下执行
    */
	public function install()
    {
        //初始配置
        model('video/Install','loglic')->config();
        
        //初始字段
        model('video/Install','loglic')->field();
        
        //初始路由
        model('video/Install','loglic')->route();
        
        //初始字段
        model('video/Install','loglic')->lang();
        
        //后台菜单
        model('video/Install','loglic')->menu();
        
        //前台菜单
        model('video/Install','loglic')->navs();
        
        //栏目分类
        model('video/Install','loglic')->category();
        
        //网站标签
        model('video/Install','loglic')->tag();
        
        //采集规则
        model('video/Install','loglic')->collect();
        
        //测试数据
        model('video/Install','loglic')->detail();
        
        //清空缓存
        \think\Cache::clear();
        
        //返回结果
        return true;
	}
    
    /**
    * 升级时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function upgrade()
    {
        //新增字段
        model('video/Upgrade','loglic')->field();
        
        //更新基础信息
        model('video/Upgrade','loglic')->status();

        //更新打包配置
        model('video/Upgrade','loglic')->pack();
        
        //清空缓存
        \think\Cache::clear();

        return true;
    }
    
    /**
    * 卸载时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function remove()
    {
        return model('video/Datas','loglic')->remove();
    }
    
    /**
    * 删除时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function unInstall()
    {
        return model('video/Datas','loglic')->delete();
	}
}