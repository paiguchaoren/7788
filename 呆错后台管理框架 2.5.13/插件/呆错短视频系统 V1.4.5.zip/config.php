<?php
return [
    'video' => [
        'theme'       => 'default',
        'theme_wap'   => 'default',
    ]
];