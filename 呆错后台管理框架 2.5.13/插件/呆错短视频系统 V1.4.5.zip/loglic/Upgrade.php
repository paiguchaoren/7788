<?php
namespace app\video\loglic;

use app\common\loglic\Update;

class Upgrade extends Update
{
    //更新应用状态
    public function status()
    {
        \daicuo\Apply::updateStatus('video', 'enable');
        
        return true;
    }
    
    //更新应用打包
    public function pack()
    {
        if(config('common.apply_module') == 'video'){
            \daicuo\Op::write([
                'apply_name'    => '呆错短视频系统',
                'apply_module'  => 'video',
                'apply_version' => config('apply.version'),
                'apply_rely'    => '',
            ], 'common', 'config', 'system', 0, 'yes');
        }
        return true;
    }
    
    //更新应用配置
    public function config()
    {
        return true;
    }
    
    //更新路由规则
    public function route()
    {
        return true;
    }
    
    //更新语言包
    public function lang()
    {
        return true;
    }
    
    //更新应用字段
    public function field()
    {
        config('common.validate_name', false);
        
        return model('common/Field','loglic')->install([
            [
                'op_name'     => 'video_player',
                'op_value'    => json_encode([
                    'type'         => 'text',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'video',
                'op_controll' => 'detail',
                'op_action'   => 'default',
            ],
        ]);
    }
    
    //更新后台菜单
    public function menu()
    {
        return true;
    }
    
    //更新前台菜单
    public function navs()
    {
        return true;
    }
    
    //更新栏目分类
    public function category()
    {
        return true;
    }
    
    //更新网站标签
    public function tag()
    {
        return true;
    }
}