<?php
namespace app\video\loglic;

class Install
{
    //一键安装回调
    public function mysql()
    {
        \daicuo\Apply::install('video','install');
        
        \daicuo\Apply::install('friend','install');
        
        \daicuo\Apply::install('adsense','install');
        
        $this->routeIndex('video/index/index','video');
        
        return true;
    }
    
    //批量添加初始配置
    public function config()
    {
        config('common.validate_name', false);
        
        return model('common/Config','loglic')->install([
            'theme'             => 'default',
            'theme_wap'         => 'default',
            'index_title'       => '呆错短视频系统',
            'index_keywords'    => '呆错短视频系统,视频管理系统,videoCms,DaiCuoVideo',
            'index_description' => '呆错短视频系统是一款专业的免费视频管理系统，适合做短视频垂直细分内容平台。',
            'meta_referer'      => 1,
            'slug_first'        => 1,
            'request_max'       => 0,
            'search_hot'        => '',
            'search_action'     => '',
            'limit_index'       => 0,
            'limit_category'    => 30,
            'limit_tag'         => 60,
            'limit_search'      => 10,
            'limit_sitemap'     => 100,
            'rewrite_index'     => 'video$',
        ],'video');
    }
    
    //批量添加扩展字段
    public function field()
    {
        config('common.validate_name', false);
        
        return model('common/Field','loglic')->install([
            [
                'op_name'     => 'video_cover',
                'op_value'    => json_encode([
                    'type'         => 'image',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'video',
                'op_controll' => 'detail',
                'op_action'   => 'default',
            ],
            [
                'op_name'     => 'video_image',
                'op_value'    => json_encode([
                    'type'         => 'image',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'video',
                'op_controll' => 'detail',
                'op_action'   => 'default',
            ],
            [
                'op_name'     => 'video_up',
                'op_value'    => json_encode([
                    'type'         => 'number',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'video',
                'op_controll' => 'detail',
                'op_action'   => 'default',
            ],
            [
                'op_name'     => 'video_down',
                'op_value'    => json_encode([
                    'type'         => 'number',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'video',
                'op_controll' => 'detail',
                'op_action'   => 'default',
            ],
            [
                'op_name'     => 'video_player',
                'op_value'    => json_encode([
                    'type'         => 'text',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'video',
                'op_controll' => 'detail',
                'op_action'   => 'default',
            ],
            [
                'op_name'     => 'video_referer',
                'op_value'    => json_encode([
                    'type'         => 'text',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'video',
                'op_controll' => 'detail',
                'op_action'   => 'default',
            ],
            [
                'op_name'     => 'video_letter',
                'op_value'    => json_encode([
                    'type'         => 'text',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'video',
                'op_controll' => 'detail',
                'op_action'   => 'default',
            ],
            [
                'op_name'     => 'video_tpl',
                'op_value'    => json_encode([
                    'type'         => 'text',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'video',
                'op_controll' => 'detail',
                'op_action'   => 'default',
            ],
            [
                'op_name'     => 'video_head',
                'op_value'    => json_encode([
                    'type'         => 'select',
                    'option'       => [1=>lang('on'),0=>lang('off')],
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'video',
                'op_controll' => 'detail',
                'op_action'   => 'default',
            ],
            [
                'op_name'     => 'video_hot',
                'op_value'    => json_encode([
                    'type'         => 'select',
                    'option'       => [1=>lang('on'),0=>lang('off')],
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'video',
                'op_controll' => 'detail',
                'op_action'   => 'default',
            ],
        ]);
    }
    
    //批量添加路由
    public function route()
    {
        config('common.validate_name', false);
        
        return model('common/Route','loglic')->install([
            [
                'rule'        => 'video$',
                'address'     => 'video/index/index',
                'method'      => '*',
                'op_module'   => 'video',
                'op_controll' => 'route',
                'op_action'   => 'system',
            ],
        ]);
    }
    
    //批量添加语言包
    public function lang()
    {
        return model('common/Lang','loglic')->install([
            'video/page/index/title'       => '网站地图',
            'video/page/index/keywords'    => '网站地图,网站目录',
            'video/page/index/description' => '网站地图页能够清晰展示网站的目录结构。',
            'video/page/head/title'        => '推荐视频',
            'video/page/head/keywords'     => '推荐视频,好看的视频',
            'video/page/head/description'  => '小编精心为您推荐的视频。',
            'video/page/hot/title'         => '热门视频',
            'video/page/hot/keywords'      => '热门视频,好看的视频',
            'video/page/hot/description'   => '小编精心为您收集的全网热门视频。',
            'video/page/news/title'        => '最近更新',
            'video/page/news/keywords'     => '最新视频,最近更新的视频',
            'video/page/news/description'  => '近期更新的视频列表。',
            'video/page/views/title'       => '人气视频',
            'video/page/views/keywords'    => '人气视频,点击数最多的视频',
            'video/page/views/description' => '点击数最多、人气最高的视频列表。',
            'video/page/types/title'       => '栏目分类',
            'video/page/types/keywords'    => '网站频道,分类列表',
            'video/page/types/description' => '网站所有栏目分类列表。',
            'video/page/tags/title'        => '网站标签',
            'video/page/tags/keywords'     => '标签列表,tags',
            'video/page/tags/description'  => '网站所有视频标签列表。',
        ],'video','zh-cn');
    }
    
    //批量添加后台菜单
    public function menu()
    {
        config('common.validate_name', false);
        
        $result = model('common/Menu','loglic')->install([
            [
                'term_name'   => '视频',
                'term_slug'   => 'video',
                'term_info'   => 'fa-file-video-o',
                'term_module' => 'video',
                'term_order'  => 9,
            ],
        ]);
        
        return model('common/Menu','loglic')->install([
            [
                'term_name'   => '视频管理',
                'term_slug'   => 'video/admin/index',
                'term_info'   => 'fa-navicon',
                'term_module' => 'video',
                'term_order'  => 9,
            ],
            [
                'term_name'   => '视频采集',
                'term_slug'   => 'video/collect/index',
                'term_info'   => 'fa-cloud',
                'term_module' => 'video',
                'term_order'  => 8,
            ],
            [
                'term_name'   => '栏目管理',
                'term_slug'   => 'admin/category/index?parent=video&term_module=video',
                'term_info'   => 'fa-list',
                'term_module' => 'video',
                'term_order'  => 7,
            ],
            [
                'term_name'   => '标签管理',
                'term_slug'   => 'admin/tag/index?parent=video&term_module=video',
                'term_info'   => 'fa-tags',
                'term_module' => 'video',
                'term_order'  => 6,
            ],
            [
                'term_name'   => '菜单管理',
                'term_slug'   => 'admin/navs/index?parent=video&navs_module=video',
                'term_info'   => 'fa-sitemap',
                'term_module' => 'video',
                'term_order'  => 5,
            ],
            [
                'term_name'   => '语言扩展',
                'term_slug'   => 'admin/lang/index?parent=video&op_module=video',
                'term_info'   => 'fa-commenting',
                'term_module' => 'video',
                'term_order'  => 4,
            ],
            [
                'term_name'   => '字段扩展',
                'term_slug'   => 'admin/field/index?parent=video&op_module=video',
                'term_info'   => 'fa-cube',
                'term_module' => 'video',
                'term_order'  => 3,
            ],
            [
                'term_name'   => 'SEO优化',
                'term_slug'   => 'video/seo/index',
                'term_info'   => 'fa-anchor',
                'term_module' => 'video',
                'term_order'  => 2,
            ],
            [
                'term_name'   => '百度推送',
                'term_slug'   => 'video/baidu/index',
                'term_info'   => 'fa-car',
                'term_module' => 'video',
                'term_order'  => 1,
            ],
            [
                'term_name'   => '频道设置',
                'term_slug'   => 'video/config/index',
                'term_info'   => 'fa-gear',
                'term_module' => 'video',
                'term_order'  => 0,
            ],
        ],'视频');
    }
    
    //批量添加前台菜单
    public function navs()
    {
        config('common.validate_name', false);

        return model('common/Navs','loglic')->install([
            [
                'navs_name'       => '视频首页',
                'navs_url'        => 'video/index/index',
                'navs_status'     => 'normal',
                'navs_type'       => 'navbar',
                'navs_module'     => 'video',
                'navs_active'     => 'videoindexindex',
                'navs_target'     => '_self',
                'navs_order'      => 99,
            ],
            [
                'navs_name'       => '网站地图',
                'navs_url'        => 'video/page/index',
                'navs_status'     => 'normal',
                'navs_type'       => 'link',
                'navs_module'     => 'video',
                'navs_active'     => 'videopageindex',
                'navs_target'     => '_self',
                'navs_order'      => 9,
            ],
            [
                'navs_name'       => '栏目分类',
                'navs_url'        => 'video/page/types',
                'navs_status'     => 'normal',
                'navs_type'       => 'link',
                'navs_module'     => 'video',
                'navs_active'     => 'videopagetypes',
                'navs_target'     => '_self',
                'navs_order'      => 8,
            ],
            [
                'navs_name'       => '网站标签',
                'navs_url'        => 'video/page/tags',
                'navs_status'     => 'normal',
                'navs_type'       => 'link',
                'navs_module'     => 'video',
                'navs_active'     => 'videopagetags',
                'navs_target'     => '_self',
                'navs_order'      => 7,
            ],
            [
                'navs_name'       => '推荐视频',
                'navs_url'        => 'video/page/head',
                'navs_status'     => 'normal',
                'navs_type'       => 'link',
                'navs_module'     => 'video',
                'navs_active'     => 'videopagehead',
                'navs_target'     => '_self',
                'navs_order'      => 6,
            ],
            [
                'navs_name'       => '热门视频',
                'navs_url'        => 'video/page/hot',
                'navs_status'     => 'normal',
                'navs_type'       => 'link',
                'navs_module'     => 'video',
                'navs_active'     => 'videopagehot',
                'navs_target'     => '_self',
                'navs_order'      => 5,
            ],
            [
                'navs_name'       => '人气视频',
                'navs_url'        => 'video/page/views',
                'navs_status'     => 'normal',
                'navs_type'       => 'link',
                'navs_module'     => 'video',
                'navs_active'     => 'videopageviews',
                'navs_target'     => '_self',
                'navs_order'      => 4,
            ],
            [
                'navs_name'       => '最新视频',
                'navs_url'        => 'video/page/news',
                'navs_status'     => 'normal',
                'navs_type'       => 'link',
                'navs_module'     => 'video',
                'navs_active'     => 'videopagenews',
                'navs_target'     => '_self',
                'navs_order'      => 3,
            ],
        ]);
    }
    
    //批量添加分类
    public function category()
    {
        config('common.validate_name', false);

        return model('common/Category','loglic')->install([
            [
                'term_name'       => '科学科普',
                'term_slug'       => 'kexuekepu',
                'term_type'       => 'navbar',
                'term_module'     => 'video',
            ],
            [
                'term_name'       => '法律法规',
                'term_slug'       => 'falvfagui',
                'term_type'       => 'navbar',
                'term_module'     => 'video',
            ],
            [
                'term_name'       => '人文历史',
                'term_slug'       => 'renwenlishi',
                'term_type'       => 'navbar',
                'term_module'     => 'video',
            ],
            [
                'term_name'       => '商业理财',
                'term_slug'       => 'shangyelicai',
                'term_type'       => 'navbar',
                'term_module'     => 'video',
            ],
            [
                'term_name'       => '职业职场',
                'term_slug'       => 'zhiyezhichang',
                'term_type'       => 'navbar',
                'term_module'     => 'video',
            ],
            [
                'term_name'       => '艺术兴趣',
                'term_slug'       => 'yishuxingqu',
                'term_type'       => 'navbar',
                'term_module'     => 'video',
            ],
            [
                'term_name'       => '情感心理',
                'term_slug'       => 'qingganxinli',
                'term_type'       => 'navbar',
                'term_module'     => 'video',
            ],
            [
                'term_name'       => '校园学习',
                'term_slug'       => 'xiaoyuanxuexi',
                'term_type'       => 'navbar',
                'term_module'     => 'video',
            ],
        ]);
    }
    
    //批量添加标签
    public function tag()
    {
        config('common.validate_name', false);

        return model('common/Tag','loglic')->install([
            [
                'term_name'       => 'mp4',
                'term_slug'       => 'mp4',
                'term_module'     => 'video',
            ],
            [
                'term_name'       => 'm3u8',
                'term_slug'       => 'm3u8',
                'term_module'     => 'video',
            ],
        ]);
    }
    
    //添加采集规则
    public function collect()
    {
        config('common.validate_name', false);
        
        return model('video/Collect','loglic')->write([
            'collect_name'     => '演示数据',
            'collect_url'      => 'http://demo.daicuo.com/index.php',
            'collect_token'    => 'fb05aabf582499263dfc235a82629069',
            'collect_category' => '',
        ]);
    }
    
    //添加测试数据
    public function detail()
    {
        $data = [];
        $data['info_module']   = 'video';
        $data['info_controll'] = 'detail';
        $data['info_action']   = 'index';
        $data['info_staus']    = 'normal';
        $data['info_type']     = 'index';
        $data['info_user_id']  = 1;
        $data['info_order']    = 9;
        $data['info_name']     = '呆错短视频系统播放M3U8格式的演示视频';//名称
        $data['info_excerpt']  = 'https://hao.daicuo.cc/video/m3u8/demo.m3u8';//播放地址
        $data['info_content']  = '呆错短视频系统是一款专业的免费视频管理系统，适合做短视频垂直细分内容平台。';//详情
        $data['info_type']     = 'index';//形式(index|vertical)
        $data['term_id']       = model('common/Term','loglic')->nameToId('科学科普', 'video', 'category', 'yes');
        $data['term_id']       = DcArrayArgs(model('common/Term','loglic')->nameToId('daicuo,m3u8', 'video', 'tag', 'yes'), $data['term_id']);
        $data['video_cover']   = 'https://cdn.daicuo.cc/images/daicuo/640x380.png';//封面
        $data['video_up']      = 9;
        $data['video_down']    = 0;
        $data['video_head']    = 1;
        $data['video_hot']     = 1;
        $data['video_letter']  = 'd';
        //定义验证等
        config('common.validate_scene', false);
        config('common.where_slug_unique', false);
        config('custom_fields.info_meta', model('common/Info','loglic')->metaKeys('video','detail','index'));
        //返回结果
        return \daicuo\Info::save($data, 'info_meta,term_map');
    }
    
    //设置首页路由
    private function routeIndex($address='index/index/index', $module='video')
    {
        //公共
        \daicuo\Op::write([
            'site_name'  => '呆错短视频系统',
            'url_suffix' => '.html',
        ], 'common', 'config', 'system', 0, 'yes');
        //配置
        \daicuo\Op::write([
            'rewrite_index' => '/',
        ], 'video', 'config', 'system', 0, 'yes');
        //删除
        \daicuo\Op::delete_all([
            'op_name'   => ['eq','site_route'],
            'op_module' => ['eq','video'],
        ]);
        //新增
        return \daicuo\Route::save([
            'rule'        => '/',
            'address'     => $address,
            'method'      => '*',
            'op_module'   => $module,
        ]);
    }
}