<?php
namespace app\video\loglic;

class Datas
{
    //卸载时删除插件配置（不删除分类、标签、菜单、内容）
    public function remove()
    {
        //删除插件配置表
        \daicuo\Op::delete_module('video');
        
        //删除前台菜单
        model('common/Navs','loglic')->unInstall('video');
        
        //删除后台菜单
        model('common/Menu','loglic')->unInstall('video');
        
        return true;
    }
    
    //按插件应用名删除数据
    public function delete()
    {
        //删除插件配置表
        \daicuo\Op::delete_module('video');
        
        //删除队列表
        \daicuo\Term::delete_module('video');
        
        //删除内容表
        \daicuo\Info::delete_module('video');
        
        return true;
    }
}