<?php
namespace app\video\controller;

use app\common\controller\Front;

class Page extends Front
{

    public function _initialize()
    {
        parent::_initialize();
    }
    
    //地图首页
    public function index()
    {
        return $this->fetch();
    }
    
    //栏目分类
    public function types()
    {
        return $this->fetch();
    }
    
    //标签列表
    public function tags()
    {
        return $this->fetch();
    }
    
    //热门视频
    public function hot()
    {
        return $this->fetch();
    }
    
    //推荐视频
    public function head()
    {
        return $this->fetch();
    }

    //最近更新
    public function news()
    {
        return $this->fetch();
    }
    
    //人气视频
    public function views()
    {
        return $this->fetch();
    }
    
    //自定义
    public function _empty($name='')
    {
        $name = DcDirPath(DcHtml($name));
        if(is_file('./'.$this->site['path_view'].'page/'.$name.'.tpl')){
            return $this->fetch($name);
        }
        return $name;
    }
}