<?php
return [
    'admin_index_count' => [
        'app\\video\\behavior\\Hook',
    ],
    'admin_index_footer' => [
        'app\\video\\behavior\\Hook',
    ],
    'admin_caps_front' => [
        'app\\video\\behavior\\Hook',
    ],
    'admin_caps_back' => [
        'app\\video\\behavior\\Hook',
    ]
];