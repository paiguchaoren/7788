<?php
return [
    'database_backup_path'     => './datas/backup/',//备份目录
    'database_backup_size'     => '10485760',//单位字节 B
    'database_backup_compress' => true,//是否压缩
    'database_backup_level'    => 5,//压缩级别
];