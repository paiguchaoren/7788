<?php
return [
    'upload_save_after' => [
        'app\\alioss\\behavior\\Hook',
    ],
    'upload_delete_after' => [
        'app\\alioss\\behavior\\Hook',
    ],
];