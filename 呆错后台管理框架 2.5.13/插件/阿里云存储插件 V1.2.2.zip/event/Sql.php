<?php
namespace app\alioss\event;

class Sql
{
    /**
    * 安装时触发
    * @return bool 只有返回true时才会往下执行
    */
	public function install()
    {
        $this->config();
        
        $this->menu();
        
        return true;
	}
    
    /**
    * 升级时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function upgrade()
    {
        $this->menu();
        
        \daicuo\Apply::updateStatus('alioss', 'enable');
        
        return true;
    }
    
    /**
    * 卸载时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function remove()
    {
        return $this->unInstall();
    }
    
    /**
    * 删除时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function unInstall()
    {
        model('common/Config','loglic')->unInstall('alioss');

        model('common/Menu','loglic')->unInstall('alioss');

        return true;
	}
	
    private function config()
    {
        return model('common/Config','loglic')->install([
            'status'     => 0,
            'unlink'     => 0,
            'key_id'     => '',
            'key_secret' => '',
            'endpoint'   => '',
            'bucket'     => '',
        ],'alioss');
    }
    
    private function menu()
    {
        if(!db('term')->where('term_controll','eq','menu')->where('term_name','eq','存储')->value('term_id')){
            model('common/Menu','loglic')->install([
                [
                    'term_name'     => '存储',
                    'term_slug'     => 'storage',
                    'term_info'     => 'fa-cloud',
                    'term_action'   => 'left',
                    'term_module'   => 'admin',
                    'term_order'    => -8,
                ],
            ]);
        }
        
        model('common/Menu','loglic')->unInstall('alioss');
        
        model('common/Menu','loglic')->install([
            [
                'term_name'   => '阿里云存储',
                'term_slug'   => 'alioss/admin/index?parent=storage',
                'term_info'   => 'fa-cloud-upload',
                'term_module' => 'alioss',
                'term_action' => 'left',
                'term_order'  => 2,
            ]
        ],'存储');
        
        return true;
    }
}