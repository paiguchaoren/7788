<?php
namespace app\alioss\event;

use app\common\controller\Addon;

class Admin extends Addon
{
	
    public function _initialize()
    {
        parent::_initialize();
    }

    public function index()
    {
        $this->assign('fields', DcFormItems($this->fields()));

        return $this->fetch('alioss@admin/index');
    }
    
    public function update()
    {
        $result = \daicuo\Op::write(input('post.'), 'alioss', 'config', 'system' ,0, 'yes');
		if( !$result ){
		    $this->error(lang('fail'));
        }
        $this->success(lang('success'));
	}
    
    protected function fields()
    {
        return [
            'status' => [
                'type'  => 'custom',
                'option'=> [1=>lang('yes'),0=>lang('no')],
                'value' => config('alioss.status'),
                'title' => lang('alioss_status'),
            ],
            'unlink' => [
                'type'  => 'custom',
                'option'=> [1=>lang('yes'),0=>lang('no')],
                'value' => intval(config('alioss.unlink')),
                'title' => lang('alioss_unlink'),
            ],
            'key_id' => [
                'type'     => 'text',
                'value'    => config('alioss.key_id'),
                'required' => true,
                'title'    => lang('alioss_key_id'),
                'tips'     => lang('alioss_tips'),
            ],
            'key_secret' => [
                'type'     => 'text',
                'value'    => config('alioss.key_secret'),
                'required' => true,
                'title'    => lang('alioss_key_secret'),
                'tips'     => lang('alioss_key_tips'),
            ],
             'endpoint' => [
                'type'     => 'text',
                'value'    => config('alioss.endpoint'),
                'required' => true,
                'title'    => lang('alioss_endpoint'),
                'tips'     => lang('alioss_endpoint_tips'),
            ],
             'bucket' => [
                'type'     => 'text',
                'value'    => config('alioss.bucket'),
                'required' => true,
                 'title'   => lang('alioss_bucket'),
            ],
        ];
    }
}