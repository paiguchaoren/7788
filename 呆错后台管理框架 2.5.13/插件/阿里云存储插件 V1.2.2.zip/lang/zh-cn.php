<?php
return [
    'alioss/admin/index'   => '阿里云存储配置',
    'alioss/index/index'   => '<a href="https://www.daicuo.org/store/alioss" target="_blank">呆错存储插件（AliOss）</a>',
    'alioss_status'        => '是否开启阿里云存储',
    'alioss_unlink'        => '上传后删除本地附件',
    'alioss_key_id'        => '阿里云AccessKeyID',	
    'alioss_key_secret'    => '阿里云AccessKeySecret',
    'alioss_endpoint'      => '阿里云OSS上传地址',	
    'alioss_bucket'        => '存储空间Bucket名称',
    'alioss_tips'          => '<a class="text-purple" href="https://www.aliyun.com/product/oss?userCode=2xkm9pyk" target="_blank">免费开通阿里云存储</a>',
    'alioss_key_tips'      => '<a class="text-purple" href="https://help.aliyun.com/document_detail/53045.htm" target="_blank">创建AccessKeySecret</a>',
    'alioss_endpoint_tips' => 'http://协议、如（http://oss-cn-shenzhen.aliyuncs.com）',
];