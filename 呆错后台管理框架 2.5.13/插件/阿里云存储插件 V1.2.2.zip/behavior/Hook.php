<?php
namespace app\alioss\behavior;

class Hook
{
    //按定义的上传文件列表上传至远程文件（原始/水印/缩略图）
    public function uploadSaveAfter(&$params)
    {
        if($params["result"]['item'] && config('alioss.status')){
            foreach($params["result"]['item'] as $key=>$value){
                //上传文件到远程
                $result = model('alioss/Aliyun','loglic')->uploadFile($value);
                //上传后删除本地
                if( $result && config('alioss.unlink') ){
                    unset($params['upload']);
                    @unlink('./'.trim(config('common.upload_path'),'/').'/'.$value);
                }
            }
        }
    }
    
    //按定义的删除文件列表删除远程文件
    public function uploadDeleteAfter(&$params)
    {
        if($params['item'] && config('alioss.status')){
            foreach($params['item'] as $key=>$value){
                model('alioss/Aliyun','loglic')->deleteFile($value);
            }
        }
    }
}