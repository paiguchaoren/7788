<?php
namespace app\alioss\loglic;

require './apps/alioss/vendor/autoload.php';

use OSS\OssClient;

use OSS\Core\OssException;

//20220418/8c28a577ffd9b320895b1bfc2a33a85d.jpg

class Aliyun
{
    protected $error = '';
    
    public function getError()
    {
        return $this->error;
    }
    
    /**
     * 上传指定的本地文件
     * @param OssClient $ossClient OSSClient实例
     * @param string $object 上传的文件名称
     * @return null
     */
    public function uploadFile($object='')
    {
        $prefix = trim(config('common.upload_path'),'/').'/';//上传目录前缀
        try{
            $ossClient = new OssClient(config('alioss.key_id'), config('alioss.key_secret'), config('alioss.endpoint'));
            $ossClient->uploadFile(config('alioss.bucket'), $prefix.$object, './'.$prefix.$object);
        } catch(OssException $e) {
            $this->error = $e->getMessage();
            return false;
        }
        return true;
    }
    
    /**
     * 删除指定的远程文件
     * @param OssClient $ossClient OSSClient实例
     * @param string $object 上传的文件名称
     * @return null
     */
    public function deleteFile($object='')
    {
        $prefix = trim(config('common.upload_path'),'/').'/';//上传目录前缀
        try{
            $ossClient = new OssClient(config('alioss.key_id'), config('alioss.key_secret'), config('alioss.endpoint'));
            $ossClient->deleteObject(config('alioss.bucket'), $prefix.$object);
        } catch(OssException $e) {
            $this->error = $e->getMessage();
            return false;
        }
        return true;
    }
}