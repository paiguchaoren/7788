<?php
namespace app\alioss\controller;

use app\common\controller\Front;

class Index extends Front
{
    public function _initialize()
    {
        parent::_initialize();
    }
    
    public function index()
    {
        return lang('alioss/index/index');
    }
}