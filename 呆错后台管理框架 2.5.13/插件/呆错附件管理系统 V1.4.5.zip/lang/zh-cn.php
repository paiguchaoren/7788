<?php
return [
    //后台节点
    'addon/attachment/config/index'     => '附件配置',
    'addon/attachment/admin/index'      => '附件管理',
    'addon/attachment/admin/edit'       => '附件修改',
    
    //前台节点
    'attachment/index/score'            => '附件消耗积分',
    
    //错误模块
    'attachment/error/system'     => '系统错误，请联系管理员',
    'attachment/error/mimeType'   => '不支持的文件类型禁止上传',
    'attachment/error/fileExit'   => '文件已失效，请联系管理员',
    'attachment/error/isReadable' => '无读取权限，请联系管理员',
    'attachment/error/curlDown'   => '获取远程附件出错',
    'attachment/error/isDelete'   => '附件已被删除',
    'attachment/error/needLogin'  => '请先登录',
    'attachment/error/scoreLess'  => '积分不足，请先充值',
    'attachment/error/notUser'    => '这不是你上传的文件',
    'attachment/error/needAuth'   => '您没有权限',
    
    //配置模块
    'open_image'                  => '本地图片',
    'open_file'                   => '本地文件',
    'open_outer'                  => '网络文件',
    'open_option_close'           => '禁用',
    'open_option_jump'            => '跳转真实地址',
    'open_option_browser'         => '发送到浏览器',
    
    //内容模块
    'attachment_name'             => '附件名称',
    'attachment_title'            => '原文件名',
    'attachment_path'             => '保存路径',
    'attachment_mime'             => '附件类型',
    'attachment_ext'              => '附件后缀',
    'attachment_size'             => '附件大小',
    'attachment_slug'             => '附件HASH',
    'attachment_score'            => '附件积分',
    'attachment_status'           => '状态',
    'attachment_complete'         => '上传完成',
    'upload_result_url'           => '上传成功后返回样式',
];