<?php
return [
    //插件唯一标识
    'module'   => 'attachment',
    //插件名称
    'name'     => '附件管理',
    //插件描述
    'info'     => '呆错附件管理是一款征对用户上传的文件进行可视化管理的工具！',
    //插件版本
    'version'  => '1.4.6',
    //依赖数据库
    'datatype' => ['sqlite', 'mysql'],
    //依赖插件版本
    'rely'     => [
        'daicuo' => '2.4.22'
    ],
];