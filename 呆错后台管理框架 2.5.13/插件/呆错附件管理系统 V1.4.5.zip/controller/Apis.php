<?php
namespace app\attachment\controller;

use app\common\controller\Api;

class Apis extends Api
{
    // 权限认证
    protected $auth = [
         'check'       => true,
         'none_login'  => [],
         'none_right'  => '*',
         'error_login' => 'user/login/index',
         'error_right' => '',
    ];
    
    // 初始化
	public function _initialize()
    {
        $this->request->filter('trim,strip_tags,htmlspecialchars');
        
		parent::_initialize();
	}
    
    //展示列表
    public function index()
    {
        $args = array();
        $args['user_id']   = $this->site['user']['user_id'];
        //$args['type']      = $this->query['info_type'];
        //$args['mime_type'] = $this->query['info_mime_type'];
        $args['cache']     = false;
        $args['with']      = 'info_meta';
        $args['simple']    = true;
        $args['sort']      = 'info_id';
        $args['order']     = 'desc';
        $args['paginate']  = [
            'list_rows' => 10,
            'page'      => $this->site['page'],
            'path'      => 'javascript:callBack("[pagePath]")',
        ];
        if(input('searchText')){
            $args['title'] = ['like','%'.input('searchText').'%'];
        }
        if($pageStart=input('pageStart')){
            $args['id']    = ['lt',$pageStart];
        }
        //查询数据
        return json(attachmentSelect(DcArrayEmpty($args)));
    }
    
    //上传附件
    public function save()
    {
        if(!$this->uploadAuth()){
            $this->error(lang('attachment/error/needAuth'));
        }
        return json(\daicuo\Upload::save_all($this->request->file('file')));
    }
    
    //删除附件
	public function delete()
    {
	    $infoId = input('id/d',0);
        //非自己的附件
        if(!$this->isMy($infoId)){
            $this->error(lang('attachment/error/notUser'));
        }
        //删除附件与记录
        attachmentDelete($infoId,true);
        //返回结果
        $this->success(lang('success'));
	}
    
    //修改附件
    public function update()
    {
        //POST普通信息
        if(!$infoId = input('post.id/d')){
            $this->error(lang('mustIn'));
        }
        //非自己的附件
        if(!$this->isMy($infoId)){
            $this->error(lang('attachment/error/notUser'));
        }
        //只修改数据库信息
        if(is_null($this->request->file('file'))){
            $data = [];
            $data['info_title'] = input('post.title/s');
            $data['attachment_score'] = input('post.score/d',0);
            attachmentUpdatePost($infoId, $data);
        }else{
            //上传前验证权限
            if(!$this->uploadAuth()){
                $this->error(lang('attachment/error/needAuth'));
            }
            //重新上传的附件信息
            $result = \daicuo\Upload::save_all($this->request->file('file'));
            if($result['code']){
                //删除原附件但不删除附件记录
                attachmentDelete($infoId, false);
                //修改数据库记录信息
                $data = [];
                $data['info_name']        = $result['data']['file_name'];//附存文件名
                $data['info_slug']        = $result['data']['slug'];//sha1/md5
                $data['info_title']       = $result['data']['old_name'];//原始文件名
                $data['info_excerpt']     = $result['data']['attachment'];//保存路径
                $data['info_type']        = $result['data']['ext'];//后缀
                $data['info_order']       = $result['data']['size'];//文件大小字节
                $data['info_mime_type']   = $result['data']['type'];//文件类型
                $data['attachment_score'] = input('post.score/d',0);//附件积分
                attachmentUpdatePost($infoId, $data);
            }
        }
        $this->success(lang('success'));
    }
    
    //判断是否为自己的附件
    private function isMy($infoId=0){
        return db('info')->where('info_id','eq',$infoId)->where('info_user_id','eq',$this->site['user']['user_id'])->value('info_id');
    }
    
    //手动验证上传权限
    private function uploadAuth()
    {
        if(\daicuo\Auth::check('api/upload/save', $this->site['user']['user_capabilities'], $this->site['user']['user_caps'])) {
            return true;
        }
        return false;
    }
}