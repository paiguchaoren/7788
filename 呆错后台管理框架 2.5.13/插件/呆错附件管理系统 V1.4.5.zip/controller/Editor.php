<?php
namespace app\attachment\controller;

use app\common\controller\Front;

class Editor extends Front
{
    public function _initialize()
    {
        $this->request->filter('trim,strip_tags,htmlspecialchars');
        
        parent::_initialize();
        
        if(!$this->site['user']['user_id']){
            exit(DcError(lang('user_login_error')));
        }
    }
    
    //附件列表
    public function index()
    {
        $args = array();
        $args['user_id']  = $this->site['user']['user_id'];
        $args['cache']    = false;
        $args['with']     = 'info_meta';
        $args['simple']   = true;
        $args['sort']     = 'info_id';
        $args['order']    = 'desc';
        $args['paginate'] = [
            'list_rows' => 9,
            'page'      => $this->site['page'],
            'path'      => false,
        ];
        if($searchText = input('searchText')){
            $args['title'] = ['like','%'.$searchText.'%'];
        }
        if($pageStart = input('pageStart')){
            $args['id']    = ['lt',$pageStart];
        }
        //数据列表
        $result = attachmentSelect(DcArrayEmpty($args));
        foreach($result['data'] as $key=>$value){
            $result['data'][$key]['image'] = attachmentInfoImage($value);
        }
        $this->assign($result);
        //地址参数
        $this->assign([
            'searchText' => $searchText,
            'pageStart'  => DcArrayResult($result['next_item'])[0]['info_id'],
        ]);
        return $this->fetch();
    }
    
    //修改附件
    public function edit()
    {
        $result = attachmentGet([
            'cache'   => false,
            'with'    => 'info_meta',
            'id'      => $this->query['id'],
            'user_id' => $this->site['user']['user_id']
        ]);
        
        $this->assign($result);
        
        return $this->fetch();
    }
    
    //积分上传
    public function score()
    {
        return $this->fetch();
    }
}