<?php
namespace app\attachment\loglic;

class Form
{
    /**
    * 生成后台配置表单
    * @version 1.4.4 首次引入
    * @param array $data 可选;初始数据;默认：空
    * @return array 标准的呆错表单组件格式（二维数组）
    */
    public function config($data=[])
    {
        //查询表单字段
        $fields = model('common/Field','loglic')->forms([
            'module'   => 'attachment',
            'controll' => 'config',
            'action'   => 'system',
            'sort'     => 'op_id',
            'order'    => 'asc',
        ]);
        //初始化字段参数
        $fields = array_map(function($field){
            if(isset($field['title'])){
                $field['title'] = lang($field['title']);
            }
            if(!isset($field['class_left'])){
               $field['class_left'] = 'col-md-2'; 
            }
            if(!isset($field['class_right'])){
               $field['class_right'] = 'col-md-6'; 
            }
            if(isset($field['option'])){
                foreach($field['option'] as $keyOption=>$valueOption){
                    $field['option'][$keyOption] = lang($valueOption);
                }
            }
            return $field;
        },$fields);
        //初始化默认值
        $fields = DcFields(DcArrayEmpty($fields), $data);
        //初始化表单格式
        return DcFormItems($fields);
    }
}