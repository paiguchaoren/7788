<?php
namespace app\attachment\loglic;

class Info
{
    protected $error = '';
    
    /**
    * 定义附件管理系统的初始字段
    * @param array $data 必需,初始数据,默认：空
    * @return array
    */
    public function fields($data=[])
    {
        $fields = [
            'info_id' => [
                'order'           => 1,
                'type'            => 'hidden',
                'value'           => $data['info_id'],
                'data-title'      => lang('info_id'),
                'data-filter'     => false,
                'data-visible'    => true,
                'data-sortable'   => true,
                'data-width'      => '80',
                'data-width-unit' => 'px',
            ],
            'info_name' => [
                'order'           => 3,
                'type'            => 'text',
                'value'           => $data['info_name'],
                'title'           => lang('attachment_name'),
                'data-title'      => lang('attachment_name'),
            ],
            'info_title' => [
                'order'           => 4,
                'type'            => 'text',
                'value'           => $data['info_title'],
                'title'           => lang('attachment_title'),
                'data-title'      => lang('attachment_title'),
                'data-align'      => 'left',
                'data-filter'     => false,
                'data-visible'    => true,
                'data-class'      => 'text-break text-wrap',
                'data-width'      => '300px',
            ],
            'info_excerpt' => [
                'order'           => 2,
                'type'            => 'text',
                'value'           => $data['info_excerpt'],
                'title'           => lang('attachment_path'),
                'data-title'      => lang('attachment_path'),
                'data-filter'     => false,
                'data-visible'    => true,
                'data-align'      => 'left',
                'data-class'      => 'text-break text-wrap',
                'data-width'      => '350px',
            ],
            'info_mime_type' => [
                'order'           => 6,
                'type'            => 'text',
                'value'           => $data['info_mime_type'],
                'title'           => lang('attachment_mime'),
                'data-title'      => lang('attachment_mime'),
                'data-filter'     => true,
                'data-visible'    => true,
            ],
            'info_type' => [
                'order'           => 7,
                'type'            => 'text',
                'value'           => $data['info_type'],
                'title'           => lang('attachment_ext'),
                'data-title'      => lang('attachment_ext'),
                'data-filter'     => true,
                'data-visible'    => true,
            ],
            'info_order' => [
                'order'           => 8,
                'type'            => 'number',
                'value'           => intval($data['info_order']),
                'title'           => lang('attachment_size'),
                'data-title'      => lang('attachment_size'),
                'data-visible'    => true,
                'data-sortable'   => true,
            ],
            'info_status' => [
                'order'           => 0,
                'type'            => 'select',
                'value'           => DcEmpty($data['info_status'],'normal'),
                'option'          => ['normal'=>lang('normal'),'hidden'=>lang('hidden'),'private'=>lang('private')],
                'data-filter'     => true,
                'data-visible'    => false,
            ],
            'info_status_text' => [
                'order'           => 99,
                'data-title'      => lang('attachment_status'),
                'data-visible'    => true,
            ],
            'info_views' => [
                'order'           => 18,
                'type'            => 'number',
                'value'           => intval($data['info_views']),
                'data-filter'     => false,
                'data-visible'    => true,
                'data-sortable'   => true,
            ],
            'info_user_id' => [
                'order'           => 96,
                'type'            => 'text',
                'value'           => DcEmpty($data['info_user_id'],$data['info_slug']),
                'data-filter'     => true,
                'data-visible'    => true,
                'data-sortable'   => true,
            ],
            'info_slug' => [
                'order'           => 97,
                'type'            => 'text',
                'value'           => $data['info_slug'],
                'title'           => lang('attachment_slug'),
                'data-title'      => lang('attachment_slug'),
                'data-visible'    => false,
                'data-sortable'   => true,
            ],
            'info_update_time' => [
                'order'           => 98,
                'data-visible'    => true,
                'data-sortable'   => true,
                'data-width'      => 120,
            ],
        ];
        //动态扩展字段（可精确到操作名）
        $customs = model('common/Info','loglic')->metaList('attachment', 'detail');
        //合并所有字段
        if($customs){
            $fields = DcArrayPush($fields, DcFields($customs, $data), false);
        }
        //返回所有表单字段
        return $fields;
    }
    
    /**
     * 获取错误信息
     * @return mixed
     */
    public function getError()
    {
        return $this->error;
    }
}