<?php
namespace app\attachment\loglic;

use app\common\loglic\Update;

class Upgrade extends Update
{
    //在线升级回调
    public function init()
    {
        return true;
    }
    
    //更新应用状态
    public function status()
    {
        return \daicuo\Apply::updateStatus('attachment', 'enable');
    }
    
    //升级配置
    public function config()
    {
        return true;
    }
    
    //升级插入字段(1.4.5)
    public function field()
    {
        return true;
    }
}