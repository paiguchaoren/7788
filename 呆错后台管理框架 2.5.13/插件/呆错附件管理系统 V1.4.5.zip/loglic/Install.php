<?php
namespace app\attachment\loglic;

class Install
{
    //一键安装回调
    public function mysql()
    {
        return true;
    }
    
    //批量写入插件初始配置
    public function config()
    {
        config('common.validate_name', false);
        
        return model('common/Config','loglic')->install([
            'open_image' => 2,
            'open_file'  => 2,
            'open_outer' => 1,
        ],'attachment');
    }
    
    //语言定义
    public function lang()
    {
        return true;
    }
    
    //批量写入插件动态字段
    public function field()
    {
        return model('common/Field','loglic')->install([
            [
                'op_name'     => 'open_image',
                'op_value'    => json_encode([
                    'type'      => 'select',
                    'option'    => [0=>'open_option_close',1=>'open_option_jump',2=>'open_option_browser'],
                    'relation'  => 'eq',
                ]),
                'op_module'   => 'attachment',
                'op_controll' => 'config',
                'op_action'   => 'system',
            ],
            [
                'op_name'     => 'open_file',
                'op_value'    => json_encode([
                    'type'      => 'select',
                    'option'    => [0=>'open_option_close',1=>'open_option_jump',2=>'open_option_browser'],
                    'relation'  => 'eq',
                ]),
                'op_module'   => 'attachment',
                'op_controll' => 'config',
                'op_action'   => 'system',
            ],
            [
                'op_name'     => 'open_outer',
                'op_value'    => json_encode([
                    'type'      => 'select',
                    'option'    => [0=>'open_option_close',1=>'open_option_jump',2=>'open_option_browser'],
                    'relation'  => 'eq',
                ]),
                'op_module'   => 'attachment',
                'op_controll' => 'config',
                'op_action'   => 'system',
            ],
            [
                'op_name'     => 'attachment_score',
                'op_value'    => json_encode([
                    'type'         => 'number',
                    'value'        => 'intval',
                    'relation'     => 'eq',
                    'data-visible' => true,
                    'data-sortable'=> true,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'attachment',
                'op_controll' => 'detail',
                'op_action'   => 'index',
                'op_order'    => 10,
            ]
        ]);
    }
    
    //批量添加后台菜单
    public function menu()
    {
        //批量添加后台一级菜单
        $result = model('common/Menu','loglic')->install([
            [
                'term_name'   => '附件',
                'term_slug'   => 'attachment',
                'term_info'   => 'fa-file',
                'term_module' => 'attachment',
                'term_order'  => 9,
            ],
        ]);
        
        //批量添加后台二级菜单
        $result = model('common/Menu','loglic')->install([
            [
                'term_name'   => '附件管理',
                'term_slug'   => 'attachment/admin/index',
                'term_info'   => 'fa-file-o',
                'term_module' => 'attachment',
                'term_order'  => 4,
            ],
            [
                'term_name'   => '字段管理',
                'term_slug'   => 'admin/field/index?parent=attachment&op_module=attachment',
                'term_info'   => 'fa-cube',
                'term_module' => 'attachment',
                'term_order'  => 3,
            ],
            [
                'term_name'   => '后台菜单',
                'term_slug'   => 'admin/menu/index?parent=attachment&term_module=attachment',
                'term_info'   => 'fa-navicon',
                'term_module' => 'attachment',
                'term_order'  => 2,
            ],
            [
                'term_name'   => '频道设置',
                'term_slug'   => 'attachment/config/index',
                'term_info'   => 'fa-gear',
                'term_module' => 'attachment',
                'term_order'  => 1,
            ],
        ],'附件');
        
        return true;
    }
}