<?php
namespace app\attachment\loglic;

class Remove
{
    //卸载
    public function init()
    {
        model('common/Config','loglic')->unInstall('attachment');
        
        model('common/Lang','loglic')->unInstall('attachment');
        
        model('common/Field','loglic')->unInstall('attachment');
        
        //model('common/Route','loglic')->unInstall('attachment');
        
        //model('common/User','loglic')->unInstall('attachment');
        
        //model('common/Role','loglic')->unInstall('attachment');
        
        //model('common/Auth','loglic')->unInstall('attachment');
        
        //model('common/Navs','loglic')->unInstall('attachment');
        
        model('common/Menu','loglic')->unInstall('attachment');
        
        //model('common/Category','loglic')->unInstall('attachment');
        
        //model('common/Tag','loglic')->unInstall('attachment');
        
        return true;
    }
}