<?php
namespace app\attachment\loglic;

class Delete
{
    //删除
    public function init()
    {
        //删除配置表数据
        \daicuo\Op::delete_module('attachment');
        
        //删除队列表数据
        \daicuo\Term::delete_module('attachment');
        
        //删除内容表数据
        \daicuo\User::delete_module('attachment');
        
        //删除用户表数据
        \daicuo\User::delete_module('attachment');
        
        //删除日志表数据
        \daicuo\Log::delete_module('attachment');
        
        //清空缓存
        \think\Cache::clear();
        
        //返回结果
        return true;
	}
}