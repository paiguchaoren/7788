<?php
namespace app\attachment\event;

class Sql
{
    /**
    * 安装时触发
    * @return bool 只有返回true时才会往下执行
    */
	public function install()
    {
        //批量写入插件动态配置
        model('attachment/Install','loglic')->config();
        
        //批量写入插件动态字段
        model('attachment/Install','loglic')->field();
        
        //批量添加后台菜单
        model('attachment/Install','loglic')->menu();
        
        //清空缓存
        \think\Cache::clear();
        
        //返回结果
        return true;
	}
    
    /**
    * 升级时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function upgrade()
    {
        //删除公共配置(common)
        \daicuo\Op::delete_all([
            'op_module'   => 'common',
            'op_controll' => 'config',
            'op_name'     => 'attachment'
        ]);
        
        model('common/Config','loglic')->unInstall('attachment');
        
        model('common/Field','loglic')->unInstall('attachment');
        
        model('common/Menu','loglic')->unInstall('attachment');
        
        model('attachment/install','loglic')->config();
        
        model('attachment/install','loglic')->field();
        
        model('attachment/Install','loglic')->menu();
        
        return model('attachment/Upgrade','loglic')->status();
    }
    
    /**
    * 卸载时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function remove()
    {
        return model('attachment/Remove','loglic')->init();
    }
    
    /**
    * 删除时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function unInstall()
    {
        return model('attachment/Delete','loglic')->init();
	}
}