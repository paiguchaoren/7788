<?php
namespace app\attachment\event;

use app\common\controller\Addon;

class Admin extends Addon
{
    public function _initialize()
    {
        parent::_initialize();
    }
    
    //定义表单字段列表
    protected function fields($data=[])
    {
        return model('attachment/Info','loglic')->fields($data);
    }
    
    //定义表单初始数据
    protected function formData()
    {
        if( $id = input('id/d',0) ){
            return attachmentGet(['cache'=>false,'id'=>$id]);
		}
        return [];
    }
    
    //定义表格数据（JSON）
    protected function ajaxJson()
    {
        $args = array();
        $args['cache']    = false;
        $args['with']     = 'info_meta,user';
        $args['search']   = $this->query['searchText'];
        $args['limit']    = DcEmpty($this->query['pageSize'], 50);
        $args['page']     = DcEmpty($this->query['pageNumber'], 1);
        $args['sort']     = DcEmpty($this->query['sortName'], 'info_id');
        $args['order']    = DcEmpty($this->query['sortOrder'], 'desc');
        $args['module']   = $this->query['info_module'];
        $args['controll'] = $this->query['info_controll'];
        $args['action']   = $this->query['info_action'];
        $args['status']   = $this->query['info_status'];
        $args['type']     = $this->query['info_type'];
        $args['mime_type']= $this->query['info_mime_type'];
        $args['user_id']  = $this->query['info_user_id'];
        //按META字段条件筛选
        //$args['meta_query'] = attachmentMetaQuery($this->query);
        //按META字段排序
        if( !in_array($args['sort'],['info_id','info_order','info_views','info_hits','info_user_id','info_create_time','info_update_time']) ){
            $args['meta_key'] = $args['sort'];
            $args['sort']     = 'meta_value_num';
        }
        //查询数据
        $list = attachmentSelect( DcArrayEmpty($args) );
        if( is_null($list) ){
            return [];
        }
        return $list;
    }
    
    public function edit()
    {
        if( !$data=$this->formData() ){
            $this->error(lang('empty'));
        }
        
        $this->assign('data', $data);
        
        $this->assign('query', $this->query);
        
        $this->assign('fields', $this->formFields('edit', $this->fields($data)));
        
        return $this->fetch('attachment@admin/edit');
    }
    
    public function preview()
    {
        if( !$id = input('id/d',0) ){
            $this->error(lang('mustIn'));
        }
        $this->redirect(DcUrlAdmin('attachment/index/id',['val'=>$id]),302);
    }
    
    public function delete()
    {
        attachmentDelete(input('id/a'));
        
        $this->success(lang('success'));
    }
    
    public function update()
    {
        if( !attachmentUpdate(input('post.')) ){
            $this->error(\daicuo\Info::getError());
        }
        $this->success(lang('success'));
    }
    
    public function status()
    {
        if( !$ids = input('post.id/a') ){
            $this->error(lang('errorIds'));
        }
        $data = [];
        $data['info_status'] = input('request.value/s', 'hidden');
        dbUpdate('common/Info',['info_id'=>['in',$ids]], $data);
        $this->success(lang('success'));
    }
}