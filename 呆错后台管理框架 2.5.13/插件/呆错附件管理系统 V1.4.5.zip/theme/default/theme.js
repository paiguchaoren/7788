//扩展附件JS库
daicuo.attachment = {
    //附件首页
    index: {
        uploadSuccess: function(uploader, file, responseObject){
            $('#url').val(file.responseTp.data.url);
        },
        uploadFail: function(uploader, data){
            daicuo.bootstrap.dialog(data.msg);
        },
        uploadComplete: function(uploader, files){
            return false;
        }
    },
    //积分上传页
    score: {
        init: function(){
            $(document).on("click",'[data-toggle="attachment-score"]',function(){
                daicuo.ajax.get($(this).attr('href'),function(html,status,xhr){
                    daicuo.bootstrap.dialogForm(html);
                    daicuo.attachment.score.onUpload();
                },function(xhr,status,html){
                    daicuo.bootstrap.dialog(status);
                });
                return false;
            });
        },
        //监听积分上传
        onUpload: function(){
            daicuo.upload.init({
                element: '[data-toggle="uploadScore"]',
                container: 'editorUpload',
                multiple: true,
                params: {score: 10},
                onInit: function(up){
                    $(document).on('change', '#attachment-score', function(){
                        up.setOption("params", {
                           score : $(this).val()
                        })
                    });
                },
                onError: function(up, data){
                    daicuo.bootstrap.dialog(data.msg);
                },
                onSuccess: function(up, file){
                    $('#url').val(file.responseTp.data.url);
                    $(".dc-modal").modal("hide");
                }
            });
        }
    },
    //附件列表页
    editor: {
        //初始化元素'[data-toggle="attachment-editor"]'
        init: function(element){
            $(document).on("click",element,function(){
                daicuo.attachment.editor.get($(this).data('url'));
            });
            //插入
            daicuo.attachment.editor.insert();
            //删除
            daicuo.attachment.editor.delete();
            //修改
            daicuo.attachment.editor.edit();
            //下一页
            daicuo.attachment.editor.next();
            //搜索
            daicuo.attachment.editor.search();
        },
        //监听插入链接
        insert: function(){
            $(document).on("click",'[data-toggle="attachment-insert"]',function(){
                $('#url').val($(this).attr('href'));
                $(".dc-modal").modal("hide");
                return false;
            });
        },
        //监听删除链接
        delete: function(){
            $(document).on("click",'[data-toggle="attachment-delete"]',function(){
                daicuo.ajax.get($(this).attr('href'),function(json,status,xhr){
                    daicuo.attachment.editor.get($('[data-toggle="attachment-form"]').attr('action'));
                },function(json,status,html){
                    daicuo.bootstrap.dialog(status);
                });
                return false;
            });
        },
        //监听修改链接
        edit: function(){
            $(document).on("click",'[data-toggle="attachment-edit"]',function(){
                daicuo.ajax.get($(this).attr('href'),function(html,status,xhr){
                    //动态加载MODAL
                    daicuo.attachment.editor.modalShow('modal-edit', html);
                    //修改页表单事件
                    daicuo.attachment.edit.onSubmit();
                    //修改页上传事件
                    daicuo.attachment.edit.onUpload();
                },function(json,status,html){
                    daicuo.bootstrap.dialog(status);
                });
                return false;
            });
        },
        //监听下一页按钮
        next: function(){
            $(document).on("click",'[data-toggle="attachment-start"]',function(){
                daicuo.attachment.editor.get(daicuo.attachment.editor.urlNext());
            });
        },
        //监听搜索表单
        search: function(){
            $(document).on('submit','[data-toggle="attachment-form"]', function() {
                daicuo.ajax.post($(this).attr('action'), $(this).serialize(), function(html, status, xhr) {
                    daicuo.bootstrap.dialogForm(html);
                });
                return false;
            });
        },
        //请求附件列表
        get: function(url){
            daicuo.ajax.get(url,function(html,status,xhr){
                daicuo.bootstrap.dialogForm(html);
            },function(xhr,status,html){
                daicuo.bootstrap.dialog(status);
            });
        },
        //显示MODAL(modal-edit)
        modalShow: function(element,html){
            $('#'+element).remove();
            $(".dc-modal").after('<div class="modal" id="'+element+'"><div class="modal-dialog modal-sm modal-dialog-centered"><div class="modal-content"><div class="modal-body">' + html + '</div></div></div></div>');
            $('#'+element).modal('show');
        },
        //隐藏MODAL(#modal-edit)
        modalHide: function(element){
            $('#'+element).modal('hide');
        },
        //当前页URL
        urlReferer: function(){
            return $('[data-toggle="attachment-form"]').attr('action')+'?searchText='+$('[data-toggle="attachment-search"]').val()+'&pageStart='+$('[data-toggle="attachment-start"]').data('referer');
        },
        //下一页URL
        urlNext: function(){
            return $('[data-toggle="attachment-form"]').attr('action')+'?searchText='+$('[data-toggle="attachment-search"]').val()+'&pageStart='+$('[data-toggle="attachment-start"]').data('start');
        }
    },
    //附件修改页
    edit: {
        onSubmit: function(){
            $(document).off('submit','[data-toggle="attachment-edit-form"]').on('submit','[data-toggle="attachment-edit-form"]', function() {
                daicuo.ajax.post($(this).attr('action'), $(this).serialize(), function(json, status, xhr) {
                    daicuo.attachment.editor.modalHide('modal-edit');
                    daicuo.attachment.editor.get(daicuo.attachment.editor.urlReferer());
                });
                return false;
            });
        },
        onUpload: function(){
            daicuo.upload.init({
                element: '#attachment-edit-upload',
                container: 'editorEditUpload',
                multiple: false,
                params: {
                    id: $('#attachment-edit-id').val(),
                    score: $('#attachment-edit-score').val()
                },
                onInit: function(up){
                    $(document).on('change', '#attachment-edit-score', function(){
                        up.setOption("params", {
                           score : $(this).val()
                        })
                    });
                },
                onError: function(up, data){
                    daicuo.attachment.editor.modalShow(data.msg);
                },
                onSuccess: function(up, file){
                    daicuo.attachment.editor.modalHide('modal-edit');
                    daicuo.attachment.editor.get(daicuo.attachment.editor.urlReferer());
                }
            });
        }
    }
};
$(document).ready(function () {
    //普通上传
    window.daicuo.upload.init();
    //积分上传
    window.daicuo.attachment.score.init();
    //选择附件
    window.daicuo.attachment.editor.init('[data-toggle="attachment-editor"]');
});