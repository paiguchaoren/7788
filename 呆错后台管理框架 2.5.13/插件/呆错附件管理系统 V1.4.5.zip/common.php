<?php
/**
 * 将上传的附件信息保存至数据库
 * @version 1.0.6 首次引入
 * @param array $post 附件信息
 * @return int 自动ID
 */
function attachmentSave($post=[])
{
    config('common.validate_name','attachment/Info');
        
    config('common.validate_scene','save');

    config('common.where_slug_unique',false);
    
    config('custom_fields.info_meta',model('common/Info','loglic')->metaKeys('attachment','detail'));
    
    $post = DcArrayArgs($post,[
        'info_module'   => 'attachment',
        'info_controll' => 'detail',
        'info_action'   => 'index',
        'info_staus'    => 'normal',
        'info_type'     => '',//后缀
        'info_user_id'  => 1,
    ]);

    return \daicuo\Info::save($post, 'info_meta');
}

/**
 * 删除附件的同时根据条件删除数据库里记录信息
 * @version 1.0.6 首次引入
 * @param array $ids 附件ID,数组格式
 * @param bool $isDelDb 可选,是否删除数据库记录,默认：true
 * @return int 自动ID
 */
function attachmentDelete($ids=[],$isDelDb=true)
{
    if(is_string($ids)){
        $ids = explode(',',$ids);
    }
    //附件列表
    $files = db('info')->field('info_id,info_excerpt,info_mime_type')->where(['info_id'=>['in',$ids]])->select();
    //删除附件
    foreach($files as $key=>$value){
        if(attachmentIsHost($value['info_excerpt'])){
            \daicuo\Upload::delete($value['info_excerpt'],$value['info_mime_type']);
        }
    }
    //删除记录
    if($isDelDb){
        return model('common/Info','loglic')->deleteIds($ids);
    }
    return true;
}

/**
 * 按附件ID更新一条附件信息
 * @version 1.0.6 首次引入
 * @param array $post 附件信息（需传入主键ID）
 * @return mixed obj|null
 */
function attachmentUpdate($post=[])
{
    config('common.validate_name','attachment/Info');
        
    config('common.validate_scene','update');

    config('common.where_slug_unique',false);
    
    config('custom_fields.info_meta', model('common/Info','loglic')->metaKeys('attachment','detail'));
    
    $post = DcArrayArgs($post,[
        'info_module'   => 'attachment',
        'info_controll' => 'detail',
        //'info_action'   => 'index',
        //'info_staus'    => 'normal',
        'info_type'     => '',
        'info_user_id'  => 1,
    ]);
    
    return \daicuo\Info::update_id($post['info_id'], $post, 'info_meta');
}

/**
 * 查询多条附件信息，支持分页
 * @version 1.0.6 首次引入
 * @param array $args 查询参数请参考呆错后台管理框架内容模型
 * @return mixed obj|array|null
 */
function attachmentSelect($args)
{
    $args = DcArrayArgs($args,[
        'cache'    => true,
        'result'   => 'array',
        'module'   => 'attachment',
        'with'     => '',
        'view'     => [],
        'field'    => 'info_name,info_slug,info_title,info_excerpt,info_order,info_type,info_mime_type,info_status,info_views,info_hits,info_module,info_controll,info_action,info_create_time,info_user_id,info_update_time,info_keywords,info_description',
    ]);
    //动态生成视图查询或关联查询条件
    if($args['meta_query']){
        if(config('database.type') == 'mysql'){
            $args['field'].=',info.info_id';
        }else{
            $args['field'] = 'info.*';
        }
    }else{
        if($args['meta_key'] || $args['meta_value']){
            array_push($args['view'],['info_meta', NULL, 'info_meta.info_id=info.info_id']);
        }
        if($args['view']){
            $args['field'].=',info.info_id';
            array_push($args['view'],['info', NULL]);
        }else{
            $args['field'].=',info_id';
        }
    }
    //查询数据
    return model('common/Info','loglic')->select($args);
}

/**
 * 查询一条附件信息
 * @version 1.0.6 首次引入
 * @param array $args 查询参数请参考呆错后台管理框架内容模型
 * @return mixed obj|array|null
 */
function attachmentGet($args)
{
    $args = DcArrayArgs($args,[
        'cache'    => true,
        'module'   => 'attachment',
    ]);
    
    return model('common/Info','loglic')->get($args);
}

/**
 * 根据内容模型扩展字段自动生成筛选查询参数
 * @version 1.0.6 首次引入
 * @param array $query 查询参数(通常为URL参数)
 * @return array 用于arg的meta_query参数
 */
function attachmentMetaQuery($query=[])
{
    return DcMetaQuery(model('common/Info','loglic')->metaList('attachment','detail'), $query);
}

/**
* 通过表单写入附件信息
* @version 1.3.1 首次引入
* @param string $infoTitle 必需,原始文件名,默认：空
* @param string $infoExcerpt 必需,附件外链地址,默认：空
* @param int $infoScore 可选,附件积分,默认：空
* @param int $infoParent 可选,附件所属内容ID,默认：空
* @param int $infoMimeType 可选,文件头,默认：空
* @param int $infoType 可选,后缀,默认：空
* @return int 递增ID
*/
function attachmentSavePost($infoTitle='', $infoExcerpt='', $infoScore=0, $infoParent=0, $infoMimeType='http')
{
    config('custom_fields.info_meta',model('common/Info','loglic')->metaKeys('attachment','detail'));

    return \daicuo\Info::save([
        'info_title'       => $infoTitle,//原始文件名
        'info_name'        => md5($infoExcerpt),//保存文件名
        'info_slug'        => md5($infoExcerpt),//拼音别名
        'info_excerpt'     => $infoExcerpt,//附件外链地址
        'info_parent'      => intval($infoParent),//所属内容ID
        'info_type'        => DcEmpty(strrchr($infoExcerpt,"."),'.zip'),//文件后缀
        'info_mime_type'   => $infoMimeType,//文件类型（application/zip）
        'info_user_id'     => DcUserCurrentGetId(),//所属用户
        'attachment_score' => intval($infoScore),//附件积分
        'info_order'       => 1024,
        'info_module'      => 'attachment',
        'info_controll'    => 'detail',
        'info_action'      => 'index',
        'info_staus'       => 'normal',
    ]);
}

/**
* 通过表单修改附件信息
* @version 1.3.1 首次引入
* @param int $infoId 必需,附件ID,默认：空
* @param array $data 必需,待更新数据内容,默认：空
* @return int 对应的ID
*/
function attachmentUpdatePost($infoId='', $data=[])
{
    config('custom_fields.info_meta',model('common/Info','loglic')->metaKeys('attachment','detail'));

    $result = \daicuo\Info::update_id($infoId, $data);

    return intval($result['info_id']);
}

/**
 * 增加用户积分日志
 * @version 1.3.1 首次引入
 * @param int $logUserId 用户ID
 * @param int $logInfoId 附件ID
 * @param int $logValue 增减值
 * @return int 影响条数
 */
function attachmentSetScore($logUserId=0, $logInfoId=0, $logValue=0)
{
    $data = [];
    $data['log_name']     = 'attachment/index/score';
    $data['log_user_id']  = $logUserId;
    $data['log_info_id']  = $logInfoId;
    $data['log_value']    = $logValue;
    $data['log_module']   = 'attachment';
    $data['log_controll'] = 'index';
    $data['log_action']   = 'score';
    $data['log_type']     = 'userScore';
    $data['log_ip']       = request()->ip();
    return model('common/Log','loglic')->save($data);
}

/**
 * 获取用户是否有积分支付记录
 * @version 1.3.1 首次引入
 * @param int $logUserId 用户ID
 * @param int $logInfoId 附件ID
 * @return int 影响条数
 */
function attachmentgetScore($logUserId=0, $logInfoId=0)
{
    $where = [
        'log_user_id'  => $logUserId,
        'log_info_id'  => $logInfoId,
        'log_module'   => 'attachment',
        'log_controll' => 'index',
        'log_action'   => 'score',
        'log_type'     => 'userScore',
    ];
    return db('log')->where($where)->value('log_id');
}

/**
 * 发送本地文件到客户端
 * @version 1.3.1 首次引入
 * @param string $filePath 本地附件保存路径（不保含上传目录）
 * @param string $fileName 原始文件名
 * @param string $mimeType 上传附件类型
 * @return header 根据head配置显示
 */
function attachmentSendBrowser($filePath='', $fileName='test.zip', $mimeType='image/png')
{
    //附件为相对地址（本地上传）
    $filePath = trim(config('common.upload_path')).'/'.$filePath;
    //浏览权限
    if(!is_readable($filePath)){
        config('daicuo.error','attachment/error/isReadable');
        return false;
    }
    //HEADER
    header('Content-Type: '.$mimeType);
    header('Content-Length: '.filesize($filePath));
    //保存文件名
    if(substr($mimeType,0,5) != 'image'){
        header('Content-Disposition: attachment;filename = '.$fileName);//basename($file)
    }
    //读取文件
    return readfile($filePath);
}

/**
 * 发送远程附件到浏览器（application/octet-stream）
 * @version 1.3.1 首次引入
 * @param string $filePath 本地附件保存路径（不保含上传目录）
 * @param string $fileName 原始文件名
 * @param string $mimeType 上传附件类型
 * @return header 根据head配置显示
 */
function attachmentCurlBrowser($filePath='', $fileName='', $mimeType='')
{
    if(!$filePath){
        config('daicuo.error','empty');
        return false;
    }
    //CURL组件
    $ch = curl_init();
    curl_setopt ($ch, CURLOPT_URL, $filePath);
    curl_setopt ($ch, CURLOPT_HEADER, 0);
    curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1); 
    curl_setopt ($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt ($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt ($ch, CURLOPT_ENCODING, "");
    //https自动处理
    if(parse_url($filePath, PHP_URL_SCHEME) == 'https'){
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    }
    //获取到的内容
    $content = curl_exec($ch);
    //状态码
    $httpCode = curl_getinfo($ch,CURLINFO_HTTP_CODE);
    //验证数据
    if($httpCode!=200){
        config('daicuo.error','attachment/error/curlDown');
        return false;
    }
    //文件大小
    $fileSize = curl_getinfo($ch, CURLINFO_SIZE_DOWNLOAD);
    //文件类型
    $mimeType = DcEmpty(curl_getinfo($ch, CURLINFO_CONTENT_TYPE),'application/zip');
    //关闭链接
    curl_close($ch);
    //HEADER
    header('Content-Type: '.$mimeType);
    header('Content-Length: '.$fileSize);
    //保存文件名
    if( !in_array(substr($mimeType,0,5),['image','text/']) ){
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment;filename='.DcEmpty($fileName, md5($filePath).'.zip'));
    }
    //显示内容
    return $content;
}

/**
 * 是否为本地服务器保存的附件
 * @version 1.4.1 首次引入
 * @param string $filePath 必需;附件路径;默认：空
 * @return bool true|false
 */
function attachmentIsHost($filePath='')
{
    if(parse_url($filePath,PHP_URL_SCHEME)){
        return false;
    }
    return true;
}

/**
 * 通过附件信息返回图片真实链接
 * @version 1.4.1 首次引入
 * @param array $info 必需;数据库保存的附件信息;默认：空
 * @param string $type 可选;thumb|water;默认：water
 * @return string 访问链接|空
 */
function attachmentInfoImage($info=[], $type='water')
{
    if(substr($info['info_mime_type'],0,5) != 'image'){
        return '';
    }
    if(!$file = trim($info['info_excerpt'])){
        return '';
    }
    return attachmentUrlImage($info['info_excerpt'], $type); 
}

/**
 * 返回本地图片真实链接
 * @version 1.4.1 首次引入
 * @param array $info 必需;数据库保存的附件信息;默认：空
 * @param string $type 可选;thumb|water;默认：water
 * @return string 访问链接|空
 */
function attachmentUrlImage($file='', $type='water')
{
    //返回水印与小图
    if($type == 'water'){
        if(!config('common.upload_water_locate')){
            $type = false;
        }
    }elseif($type == 'thumb'){
        if(!config('common.upload_thumb_type')){
            $type = false;
        }
    }
    //是否小图与水印
    if($type){
        $fileArray = pathinfo($file);
        $file = $fileArray['dirname'].'/'.$fileArray['filename'].'_'.$type.'.'.$fileArray['extension'];
    }
    //本地附件CDN加速开关
    if( config('common.upload_cdn') ){
        return rtrim(config('common.upload_cdn'),'/').DcRoot().trim(config('common.upload_path'),'/').'/'.$file;
    }
    //相对路径直接返回真实路径
    return DcRoot().trim(config('common.upload_path'),'/').'/'.$file;
}