<?php
namespace app\attachment\behavior;

class Hook
{
    public function uploadSaveAfter(&$params)
    {
        if($params["result"]['attachment']){
            //修改附件不处理
            if(input('post.id')){
                return false;
            }
            //新增附件记录
            $data = [];
            $data['info_parent']      = 0;//内容ID
            $data['info_name']        = $params["result"]['file_name'];//附存文件名
            $data['info_slug']        = $params["result"]['slug'];//sha1/md5
            $data['info_title']       = $params["result"]['old_name'];//原始文件名
            $data['info_excerpt']     = $params["result"]['attachment'];//保存路径
            $data['info_type']        = $params["result"]['ext'];//后缀
            $data['info_order']       = $params["result"]['size'];//文件大小字节
            $data['info_mime_type']   = $params["result"]['type'];//文件类型
            $data['info_user_id']     = DcUserCurrentGetId();//当前用户ID
            $data['attachment_score'] = intval(input('post.score'));//附件积分
            //返回附件ID字段
            if($infoId = attachmentSave($data)){
                $params['result']['id']    = $infoId;
                $params['result']['score'] = $data['attachment_score'];
                $params['result']['urlId'] = DcUrl('attachment/index/id',['val'=>$infoId]);
            }
        }
    }
}