<?php
return [
    'attachment' => [
        'theme'     => 'default',
        'theme_wap' => 'default',
    ]
];