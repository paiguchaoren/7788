<?php
return [
    'upload_save_after' => [
        'app\\attachment\\behavior\\Hook',
    ],
];