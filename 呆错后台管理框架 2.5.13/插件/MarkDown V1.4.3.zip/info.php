<?php
/*
** 插件基础信息
*/
return [
    //插件唯一标识
    'module'   => 'markdown',
    //插件名称
    'name'     => 'MarkDown',
    //插件描述
    'info'     => '呆错框架编辑器插件（MarkDown）非常适用于技术文档编写，支持文件与图片上传！',
    //插件版本
    'version'  => '1.4.3',
    //依赖数据库
    'datatype' => ['sqlite', 'mysql'],
    //依赖插件版本
    'rely'     => [
        'daicuo' => '2.4.22',
    ],
];