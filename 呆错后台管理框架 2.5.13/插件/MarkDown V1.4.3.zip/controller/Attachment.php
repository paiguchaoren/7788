<?php
namespace app\markdown\controller;

use app\common\controller\Api;

class Attachment extends Api
{
    // 权限认证
    protected $auth = [
         'check'       => true,
         'rule'        => 'api/upload/save',
         'none_login'  => [],
         'none_right'  => [],
         'error_login' => 'user/login/index',
         'error_right' => '',
    ];
    
    // 初始化
	public function _initialize()
    {
        $this->request->filter('trim,strip_tags,htmlspecialchars');
        
		parent::_initialize();
	}
    
    // 添加网络文件
    public function save()
    {
        //未安装附件管理插件
        if(!function_exists('attachmentSave')){
            $data = [];
            $data['name']  = md5($data['url']);
            $data['url']   = input('post.attachment_url/u','https://cdn.daicuo.cc/images/daicuo/logo.png');//保存路径
            $data['score'] = 0;
            return $this->success('success',$data);
        }
        //已安装附件管理插件
        $data = [];
        $data['info_parent']      = 0;//内容ID
        $data['info_excerpt']     = input('post.attachment_url/s');//保存路径
        $data['info_name']        = md5($data['info_excerpt']);//保存文件名
        $data['info_slug']        = $data['info_name'];//sha1/md5
        $data['info_title']       = input('post.info_name/s',uniqid());//原始文件名
        $data['info_type']        = DcEmpty(parse_url($data['info_excerpt'],PHP_URL_SCHEME),'http');//后缀
        $data['info_order']       = '1024';//文件大小字节
        $data['info_mime_type']   = 'application/octet-stream';//文件类型
        $data['info_user_id']     = $this->site['user']['user_id'];
        $data['attachment_score'] = intval(input('post.attachment_score/d'));//附件积分
        //保存附件信息
        if($infoId = attachmentSave($data)){
            return $this->success('ok',['name'=>$data['info_name'],'score'=>$data['attachment_score'],'url'=>DcUrl('attachment/index/id',['val'=>$infoId])]);
        }
        return $this->error('error');
    }
}