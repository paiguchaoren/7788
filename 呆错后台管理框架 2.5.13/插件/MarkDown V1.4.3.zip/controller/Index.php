<?php
namespace app\markdown\controller;

use app\common\controller\Front;

class Index extends Front
{

	public function _initialize()
    {
		parent::_initialize();
	}
    
    //首页演示
	public function index()
    {
        config('common.editor_name','markdown');
        
        $file = new \files\File();
        
        $file->d_delete(TEMP_PATH);
        
		return $this->fetch();
	}
    
    //积分附件
    public function upload()
    {
        return $this->fetch();
    }
    
    //网络文件
    public function outer()
    {
        return $this->fetch();
    }
}