<?php
//编辑器列表
DcConfigMerge('common.editor_list', ['markdown']);

//插件配置
return [
    'markdown' => [
        'editor_path'     => './apps/markdown/view/editor/index.tpl',
        'editor_function' => 'markdownParse',
        'theme'           => 'default',
        'theme_wap'       => 'default'
    ]
];