<?php
namespace app\markdown\event;

class Sql
{
    /**
    * 安装时触发
    * @return bool 只有返回true时才会往下执行
    */
	public function install()
    {
        $this->insertConfig();
        
        $this->clearTemp();
        
        return true;
	}
    
    /**
    * 升级时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function upgrade()
    {
        $this->insertConfig();
        
        $this->clearTemp();
        
        if( !\daicuo\Apply::updateStatus('markdown', 'enable') ){
            return false;
        }
        
        return true;
	}

    /**
    * 卸载插件时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function remove()
    {
        
        return $this->unInstall();
    }
    
    /**
    * 删除时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function unInstall()
    {
        if(config('common.editor_name') == 'markdown'){
            model('common/Config','loglic')->delete(['name'=>'editor_name']);
            $this->clearTemp();
        }
        return true;
	}
    
    //写入数据
    private function insertConfig()
    {
        //保证唯一
        db('op')->where(['op_name'=>'editor_name'])->delete();
        //添加数据
        model('common/Config','loglic')->install([
            'editor_name' => 'markdown',
        ],'common');
    }
    
    //清除模板缓存
    private function clearTemp()
    {
        $file = new \files\File();
        $file->d_delete(TEMP_PATH);
    }
}