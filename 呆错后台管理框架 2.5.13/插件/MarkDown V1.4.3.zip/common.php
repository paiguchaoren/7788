<?php
/**
 * PHP版解析MarkDown代码
 */
function markdownParse($str){
    $parser = model('markdown/Parser','loglic');
    $parser->_html = true;
    return $parser->makeHtml($str);
}