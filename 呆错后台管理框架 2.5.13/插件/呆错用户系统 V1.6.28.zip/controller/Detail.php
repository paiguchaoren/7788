<?php
namespace app\user\controller;

use app\common\controller\Front;

class Detail extends Front
{
    public function _initialize()
    {
		parent::_initialize();
    }
    
    public function index()
    {
        //用户信息
        if($id = intval($this->query['id'])){
            $info = model('common/User','loglic')->get([
                'cache'  => true,
                'status' => 'normal',
                'id'     => ['eq',$id],
            ]);
        }
        if(!$info){
            $this->error(lang('error_user_empty'),'user/index/index');
        }
        unset($info['user_pass']);
        unset($info['user_token']);
        $this->assign($info);
        return $this->fetch();
    }
}