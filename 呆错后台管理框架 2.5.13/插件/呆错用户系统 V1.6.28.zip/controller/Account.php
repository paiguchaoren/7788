<?php
namespace app\user\controller;

use app\common\controller\Front;

class Account extends Front
{
    private $captchaList = [];
    
    public function _initialize()
    {
        $this->request->filter('trim,strip_tags,htmlspecialchars');
        
		parent::_initialize();
        
        if( $this->site['user']['user_id'] ){
            $this->redirect(DcUrl('user/center/index'), 302);
        }
        
        if(!config('user.captcha_login')){
            $this->error(lang('error_captcha_login'),'user/login/index');
        }
        
        if(!$this->captchaList=model('user/Captcha','loglic')->captchaList()){
            $this->error(lang('error_captcha_disabled'),'user/login/index');
        }
    }
    
    public function index()
    {
        if( $this->site['user']['user_id'] ){
            $this->redirect(DcUrl('user/center/index'), 302);
        }
        
        $this->assign('captcha_list', $this->captchaList);
        
        return $this->fetch();
    }
    
    //发送验证码
    public function notice()
    {
        $userName = input('post.user_name');
        //表单验证
        if(!is_mobile($userName)){
            if(!is_email($userName)){
                $this->error(lang('error_user_empty'));
            }
        }
        //图形验证码
        if(captcha_check(input('post.img_captcha')) == false){
            $this->error(lang('error_captcha'));
        }
        //发送频率限制
        if(!model('user/Captcha','loglic')->interval()){
            $this->error(model('user/Captcha','loglic')->getError());
        }
        //发送验证码
        if(!model('user/Captcha','loglic')->account($userName)){
            $this->error(model('user/Captcha','loglic')->getError());
        }
        //返回结果
        $this->success(lang('success'), 'user/login/index', ['action'=>'notice']);
    }
    
    //根据验证码登录或注册
    public function update()
    {
        $post = input('post.');
        //验证规则
        $validate = new \think\Validate([
            'user_name'    => 'require',
            'user_captcha' => 'require',
        ],[
            'user_name.require'    => lang('error_name_require'),
            'user_captcha.require' => lang('error_captcha_require'),
        ]);
        if(!$validate->check($post)){
            $this->error($validate->getError());
        }
        //动态码验证
        if(!model('user/Captcha','loglic')->check($post['user_name'],$post['user_captcha'],'account')){
            $this->error(model('user/Captcha','loglic')->getError());
        }
        //自动登录
        if($userId = model('user/Captcha','loglic')->getUserId()){
            db('user')->where('user_id',$userId)->update(['user_status'=>'normal']);
            \daicuo\User::logout();
            \daicuo\User::set_current_user($userId);
            \daicuo\User::set_auth_cookie($userId);
        }
        //操作成功
        $this->success(lang('success'), 'user/center/index', ['action'=>'update']);
    }
}