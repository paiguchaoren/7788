<?php
namespace app\user\controller;

use app\common\controller\Front;

class Center extends Front
{
    protected $auth = [
         'check'       => true,
         'none_login'  => '',
         'none_right'  => '*',
         'error_login' => 'user/login/index',
         'error_right' => 'user/login/index',
    ];
    
	public function _initialize()
    {
		parent::_initialize();
	}
    
	public function index()
    {
        $this->assign('captcha_list', model('user/Captcha','loglic')->captchaList());
        
		return $this->fetch();
	}
}