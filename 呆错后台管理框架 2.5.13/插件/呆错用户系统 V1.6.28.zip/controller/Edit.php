<?php
namespace app\user\controller;

use app\common\controller\Front;

class Edit extends Front
{
    protected $auth = [
         'check'       => true,
         'none_login'  => '',
         'none_right'  => '*',
         'error_login' => 'user/login/index',
         'error_right' => 'user/login/index',
    ];
    
	public function _initialize()
    {
        $this->request->filter('trim,strip_tags,htmlspecialchars');
        
		parent::_initialize();
        
        if(!config('user.edit')){
            $this->error(lang('error_disabled'),'user/center/index');
        }
	}
    
	public function index()
    {
        $this->assign('fields',$this->fields($this->site['user']));
        
		return $this->fetch();
	}
    
    public function update()
    {
        //获取表单字段
        $fields  = $this->fields($this->site['user']);
        //过滤表单数据
        $post = DcArrayFilter(input('post.'),array_keys($fields));
        //过滤敏感词
        $post = array_map('userWordFilter',$post);
        //表单验证规则
        $rules = array_column($fields,'validate','name');
        $validate = new \think\Validate($rules,[
            'user_slug.length'    => lang('user_slug').lang('error_length').'6~30',
            'user_nice_name.length' => lang('user_nice_name').lang('error_length').'3~30',
        ]);
        //自定义验证规则
        $validate->extend('unique', function($value, $rule, $data, $field) {
            return $this->unique($field, $value);
        });
        //验证动态表单
        if(!$validate->check($post)){
            $this->error($validate->getError());
        }
        //修改资料
        $post['user_id'] = $this->site['user']['user_id'];
        if(!$result = model('common/User','loglic')->write($post, false, false, false)){
            $this->error(model('common/User','loglic')->getError());
        }
        //操作成功
        $this->success(lang('success'), 'user/edit/index', ['action'=>'update']);
    }
    
    //表单字段（支持后台自定义）
    private function fields($data=[])
    {
        $fields = [
            'user_slug' => [
                'order'           => 0,
                'type'            => 'text',
                'value'           => $data['user_slug'],
                'validate'        => 'length:6,30|unique',
                'scene'           => 'update',
                'required'        => true,
                'maxlength'       => 30,
                'disabled'        => true,
                'tips'            => '<a class="text-purple" href="javascript:;" data-target="user_slug" data-toggle="disabled">修改</a>',
            ],
            'user_nice_name' => [
                'order'           => 0,
                'type'            => 'text',
                'value'           => $data['user_nice_name'],
                'validate'        => 'length:3,30|unique',
                'scene'           => 'update',
                'required'        => true,
                'disabled'        => true,
                'maxlength'       => 30,
                'tips'            => '<a class="text-purple" href="javascript:;" data-target="user_nice_name" data-toggle="disabled">修改</a>',
            ],
            'user_tag' => [
                'order'           => 0,
                'type'            => 'text',
                'value'           => $data['user_tag'],
                'maxlength'       => 60,
                'disabled'        => true,
                'tips'            => '<a class="text-purple" href="javascript:;" data-target="user_tag" data-toggle="disabled">修改</a>',
            ],
            'user_sign' => [
                'order'           => 0,
                'type'            => 'text',
                'value'           => $data['user_sign'],
                'maxlength'       => 120,
            ],
        ];
        //合并字段管理添加的动态字段
        if($customs = model('common/Field','loglic')->forms(['module'=>'user','controll'=>['eq','edit'],'action'=>['eq','index']])){
            $fields = array_merge($fields, DcFields($customs, $data));
        }
        //格式化字段列表
        return DcFormItems($fields);
    }
    
    //唯一验证
    private function unique($field='user_slug', $value='')
    {
        $result = db('user')->where([
            $field => ['eq',$value],
            'user_id' => ['neq',$this->site['user']['user_id']],
        ])->value('user_id');
        if(is_null($result)){
            return true;
        }
        return lang('error_'.$field.'_unique');
	}
    
    //过滤敏感词
    private function wordFilter($string='')
    {
        if(config('user.word_filter')){
            foreach(explode(',',config('user.word_filter')) as $key=>$value){
                $string = str_replace($value,'',$string);
            }
        }
        return $string;
    }
}