<?php
namespace app\user\controller;

use app\common\controller\Front;

class Oauth extends Front
{
    protected $auth = [
         'check'       => true,
         'none_login'  => '',
         'none_right'  => '*',
         'error_login' => 'user/login/index',
         'error_right' => 'user/login/index',
    ];
    
	public function _initialize()
    {
		parent::_initialize();
	}
    
    //第一步：扩展授权登录列表
    //第二步：检测user['oauth_'.第三方登录应用名]是否有值
	public function index()
    {
        if(!config('user.oauths')){
            $this->error(lang('error_oauth_off'),'user/center/index');
        }
        //三方登录列表
        $list = [];
        foreach(explode(',',config('user.oauths')) as $value){
            $module = reset(explode('/',$value));
            $list[$value]['name']      = lang('oauth_'.$module);
            $list[$value]['isBind']    = DcEmpty($this->site['user']['oauth_'.$module],false);
            $list[$value]['urlBind']   = DcUrl($module.'/'.'bind/index');
            $list[$value]['urlDelete'] = DcUrl($module.'/'.'bind/delete');
        }
        $this->assign('list',$list);
		return $this->fetch();
	}
}