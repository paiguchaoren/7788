<?php
namespace app\user\event;

use think\Controller;

class Admin extends Controller
{
	public function _initialize()
    {
		parent::_initialize();
	}

	public function index()
    {
        $items = [
            'theme'                => ['type'=>'select', 'value'=>config('user.theme'), 'option'=>DcThemeOption('user')],
            'theme_wap'            => ['type'=>'select', 'value'=>config('user.theme_wap'),'option'=>DcThemeOption('user')],
            'limit_index'          => ['type'=>'text', 'value'=>config('user.limit_index'),'placeholder'=>lang('addon_user_zero')],
            'html_1'               => ['type'=>'html', 'value'=>'<hr>'],
            'register_name'        => ['type'=>'select', 'value'=>config('user.register_name'),'option'=>[true=>lang('open'),false=>lang('close')]],
            'register_email'       => ['type'=>'select', 'value'=>config('user.register_email'),'option'=>[true=>lang('open'),false=>lang('close')]],
            'register_mobile'      => ['type'=>'select', 'value'=>config('user.register_mobile'),'option'=>[true=>lang('open'),false=>lang('close')],'tips'=>lang('addon_user_register_tips')],
            'edit'                 => ['type'=>'select', 'value'=>config('user.edit'),'option'=>[true=>lang('open'),false=>lang('close')]],
            'html_2'               => ['type'=>'html', 'value'=>'<hr>'],
            'captcha_email'        => ['type'=>'select', 'value'=>config('user.captcha_email'),'option'=>$this->notice('mail')],
            'captcha_mobile'       => ['type'=>'select', 'value'=>config('user.captcha_mobile'),'option'=>$this->notice('sms'),'tips'=>lang('addon_user_captcha_tips')],
            'captcha_login'        => ['type'=>'select', 'value'=>config('user.captcha_login'),'option'=>[true=>lang('open'),false=>lang('close')]],
            'captcha_reset'        => ['type'=>'select', 'value'=>config('user.captcha_reset'),'option'=>[true=>lang('open'),false=>lang('close')]],
            'captcha_interval'     => ['type'=>'text', 'value'=>config('user.captcha_interval'),'placeholder'=>lang('addon_user_second')],
            'captcha_expire'       => ['type'=>'text', 'value'=>config('user.captcha_expire'),'placeholder'=>lang('addon_user_second')],
            'captcha_content'      => ['type'=>'textarea', 'value'=>config('user.captcha_content'),'rows'=>'3','placeholder'=>false,'tips'=>lang('addon_user_captcha_content_tips')],
            'html_3'               => ['type'=>'html', 'value'=>'<hr>'],
            'word_filter'          => ['type'=>'textarea', 'value'=>config('user.word_filter'),'rows'=>'3'],
            'oauths'               => ['type'=>'textarea', 'value'=>config('user.oauths'),'rows'=>'3'],
            'callback_secret'      => ['type'=>'text', 'value'=>config('user.callback_secret')],
            'callback_domains'     => ['type'=>'textarea', 'value'=>config('user.callback_domains'),'rows'=>'3'],
        ];
        
        //初始化前缀
        foreach($items as $key=>$value){
            $items[$key]['title']  = lang('addon_user_'.$key);
            if(!isset($value['placeholder'])){
                $items[$key]['placeholder'] = lang('addon_user_'.$key.'_placeholder');
            }
        }
        
        //扩展表单字段
        if($customs = model('common/Config','loglic')->metaList('user', 'config')){
            array_push($items,[
                'type'        => 'html',
                'value'       => '<hr>',
            ]);
            $items = array_merge($items, DcFormItems(DcFields($customs, config('user'))));
        }
        
        //加载模板
        $this->assign('items', DcFormItems($items));
        return $this->fetch('user@admin/index');
	}
    
    public function update()
    {
        $status = \daicuo\Op::write(input('post.'),'user', 'config','system',0,'yes');
		if( !$status ){
		    $this->error(lang('fail'));
        }
        $this->success(lang('success'));
	}
    
    private function notice($type='mail')
    {
        $option = [];
        $option['off'] = lang('off');
        foreach(config('notice.'.$type) as $value){
            $option[$value] = lang('notice_'.$value);
        }
        return $option;
    }
}