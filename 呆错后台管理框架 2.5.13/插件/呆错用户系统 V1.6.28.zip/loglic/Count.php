<?php
namespace app\user\loglic;

class Count
{
    public function register()
    {
        return db('user')->count('user_id');
    }
}