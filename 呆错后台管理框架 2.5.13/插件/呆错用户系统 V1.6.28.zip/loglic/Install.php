<?php
namespace app\user\loglic;

class Install
{
    //MYSQL安装回调
    public function mysql()
    {
        \daicuo\Apply::install('user','install');
        
        \daicuo\Op::write([
            'apply_name'    => '呆错用户系统',
            'apply_module'  => 'user',
            'apply_version' => '1.6.28',
        ], 'common', 'config', 'system', 0, 'yes');
        
        model('common/Route','loglic')->index('user/index/index', 'user');
        
        return true;
    }
    
    //批量写入插件初始配置
    public function config()
    {
        model('common/Config','loglic')->unInstall('user');
        
        return model('common/Config','loglic')->install([
            'theme'                   => 'default',
            'theme_wap'               => 'default',
            'edit'                    => true,
            'register_name'           => true,
            'register_email'          => false,
            'register_mobile'         => false,
            'limit_index'             => 60,
            'limit_detail'            => 10,
            'score_register'          => 10,
            'score_invite'            => 0,
            'score_recharge'          => 0,
            'score_group_contributor' => 10,
            'score_group_vip'         => 1000,
            'captcha_email'           => false,
            'captcha_mobile'          => false,
            'captcha_interval'        => 60,
            'captcha_expire'          => 600,
            'captcha_content'         => '【[siteName]】你的验证码为：[captcha]，请勿泄露于他人，[minute]分钟内有效。',
        ],'user');
    }
    
    //批量定义语言包
    public function lang()
    {
        return model('common/Lang','loglic')->install([
            'user_login_index_title'           => '密码登录',
            'user_login_index_keywords'        => '用户名密码登录',
            'user_login_index_description'     => '已注册的手机、邮箱、帐号请直接登录',
            'user_register_index_title'        => '用户注册',
            'user_register_index_keywords'     => '免费注册,邮件地址注册,手机号注册',
            'user_register_index_description'  => '未注册帐号请先注册后再登录',
            'user_account_index_title'         => '验证码登录',
            'user_account_index_keywords'      => '短信验证码登录,邮件验证码登录',
            'user_account_index_description'   => '未注册的手机号或邮件地址将直接注册并登录',
            'user_account_index_title'         => '验证码登录',
            'user_account_index_keywords'      => '短信验证码登录,邮件验证码登录',
            'user_account_index_description'   => '未注册的手机号或邮件地址将直接注册并登录',
            'user_reset_index_title'           => '通过动态验证码重设密码',
            'user_reset_index_keywords'        => '短信验证码改密,邮件验证码改密',
            'user_reset_index_description'     => '通过手机/邮箱接收到的验证码重设密码',
            'user_index_index_title'           => '用户广场',
            'user_index_index_keywords'        => '推荐用户,人气用户',
            'user_index_index_description'     => '人气值最高的用户',
        ],'user','zh-cn');
    }
    
    //批量写入插件动态字段
    public function field()
    {
        model('common/Field','loglic')->unInstall('user');
        
        config('common.validate_name', false);
        
        return model('common/Field','loglic')->install([
            [
                'op_name'     => 'user_score',
                'op_value'    => json_encode([
                    'type'         => 'number',
                    'relation'     => 'gt',
                    'disabled'     => true,
                    'data-sortable'=> true,
                    'data-visible' => true,
                    'data-filter'  => true,
                ]),
                'op_module'   => 'user',
                'op_controll' => 'detail',
                'op_action'   => 'index',
                'op_order'    => 7,
            ],
            [
                'op_name'     => 'user_pid',
                'op_value'    => json_encode([
                    'type'         => 'text',
                    'relation'     => 'eq',
                    'data-sortable'=> true,
                    'data-visible' => true,
                    'data-filter'  => true,
                ]),
                'op_module'   => 'user',
                'op_controll' => 'detail',
                'op_action'   => 'index',
                'op_order'    => 8,
            ],
            [
                'op_name'     => 'user_tag',
                'op_value'    => json_encode([
                    'type'         => 'text',
                    'relation'     => 'eq',
                    'data-sortable'=> false,
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'user',
                'op_controll' => 'detail',
                'op_action'   => 'index',
                'op_order'    => 9,
            ],
            [
                'op_name'     => 'user_sign',
                'op_value'    => json_encode([
                    'type'         => 'text',
                    'relation'     => 'eq',
                    'data-sortable'=> false,
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'user',
                'op_controll' => 'detail',
                'op_action'   => 'index',
                'op_order'    => 10,
            ],
        ]);
    }
    
    //批量添加路由伪静态
    public function route()
    {
        model('common/Route','loglic')->unInstall('user');
        
        config('common.validate_name', false);
        
        return model('common/Route','loglic')->install([
            [
                'rule'        => 'login$',
                'address'     => 'user/login/index',
                'method'      => '*',
            ],
            [
                'rule'        => 'register$',
                'address'     => 'user/register/index',
                'method'      => '*',
            ],
            [
                'rule'        => 'account$',
                'address'     => 'user/account/index',
                'method'      => '*',
            ],
            [
                'rule'        => 'logout$',
                'address'     => 'user/logout/index',
                'method'      => '*',
            ],
        ],'user');
    }
    
    //批量添加角色（用户组）
    public function role()
    {
        model('common/Role','loglic')->unInstall('user');
        
        config('common.validate_name', false);
        
        return model('common/Role','loglic')->install([
            [
                'op_name'     => 'vip',
                'op_value'    => '贵宾VIP',
                'op_module'   => 'user',
            ]
        ]);
    }
    
    //批量添加权限
    public function auth()
    {
        model('common/Auth','loglic')->unInstall('user');
        
        config('common.validate_name', false);
        
        //权限节点
        $caps = [
            'api/token/update',
            'api/token/refresh',
            'api/token/delete',
            'api/upload/save',
            'api/upload/delete',
        ];
        //默认数据
        $default = [
            'op_name'       => 'vip',
            'op_module'     => 'user',
            'op_controll'   => 'auth',
            'op_action'     => 'front',
            'op_order'      => 0,
            'op_status'     => 'normal',
        ];
        //批量添加数据
        $dataList = [];
        foreach($caps as $key=>$value){
            array_push($dataList, DcArrayArgs(['op_value'=>$value],$default));
        }
        
        //调用接口
        return model('common/Auth','loglic')->install($dataList);
    }
    
    //批量添加后台菜单
    public function menu()
    {
        model('common/Menu','loglic')->unInstall('user');
        
        return model('common/Menu','loglic')->install([
            [
                'term_name'   => '菜单管理',
                'term_slug'   => 'admin/navs/index?parent=user&navs_module=user',
                'term_info'   => 'fa-navicon',
                'term_module' => 'user',
                'term_order'  => 2,
            ],
            [
                'term_name'   => '路由管理',
                'term_slug'   => 'admin/route/index?parent=user&op_module=user',
                'term_info'   => 'fa-wifi',
                'term_module' => 'user',
                'term_order'  => 1,
            ],
            [
                'term_name'   => '语言定义',
                'term_slug'   => 'admin/lang/index?parent=user&op_module=user',
                'term_info'   => 'fa-commenting',
                'term_module' => 'user',
                'term_order'  => -3,
            ],
            [
                'term_name'   => '字段管理',
                'term_slug'   => 'admin/field/index?parent=user&op_module=user',
                'term_info'   => 'fa-cube',
                'term_module' => 'user',
                'term_order'  => -4,
            ],
            [
                'term_name'   => '日志管理',
                'term_slug'   => 'admin/log/index?parent=user&log_module=user',
                'term_info'   => 'fa-image',
                'term_module' => 'user',
                'term_order'  => -5,
            ],
            [
                'term_name'   => '积分奖惩',
                'term_slug'   => 'user/reward/index?parent=user',
                'term_info'   => 'fa-calculator',
                'term_module' => 'user',
                'term_order'  => -6,
            ],
            [
                'term_name'   => '积分日志',
                'term_slug'   => 'admin/log/index?parent=user&log_module=user&log_type=userScore',
                'term_info'   => 'fa-history',
                'term_module' => 'user',
                'term_order'  => -7,
            ],
            [
                'term_name'   => '积分设置',
                'term_slug'   => 'user/score/index?parent=user',
                'term_info'   => 'fa-btc',
                'term_module' => 'user',
                'term_order'  => -8,
            ],
            [
                'term_name'   => '频道设置',
                'term_slug'   => 'user/admin/index?parent=user',
                'term_info'   => 'fa-gear',
                'term_module' => 'user',
                'term_order'  => -9,
            ],
        ],'用户');
    }
    
    //批量添加前台菜单
    public function navs()
    {
        model('common/Navs','loglic')->unInstall('user');
        
        return model('common/Navs','loglic')->install([
            [
                'navs_module'     => 'user',
                'navs_type'       => 'navbar',
                'navs_name'       => '登录',
                'navs_info'       => '已注册帐号请登录',
                'navs_url'        => 'user/login/index',
                'navs_status'     => 'public',
                'navs_active'     => 'userloginindex',
                'navs_target'     => '_self',
                'navs_order'      => 0,
                'navs_parent'     => 0,
            ],
            [
                'navs_module'     => 'user',
                'navs_type'       => 'navbar',
                'navs_name'       => '注册',
                'navs_info'       => '免费注册帐号',
                'navs_url'        => 'user/register/index',
                'navs_status'     => 'public',
                'navs_active'     => 'userregisterindex',
                'navs_target'     => '_self',
                'navs_order'      => 0,
                'navs_parent'     => 0,
            ],
            [
                'navs_module'     => 'user',
                'navs_type'       => 'navbar',
                'navs_name'       => '用户中心',
                'navs_info'       => '用户中心首页',
                'navs_url'        => 'user/center/index',
                'navs_status'     => 'private',
                'navs_active'     => 'usercenterindex',
                'navs_target'     => '_self',
                'navs_order'      => '-98',
                'navs_parent'     => 0,
            ],
            [
                'navs_module'     => 'user',
                'navs_type'       => 'navbar',
                'navs_name'       => '安全退出',
                'navs_info'       => '安全退出已登录帐号',
                'navs_url'        => 'user/logout/index',
                'navs_status'     => 'private',
                'navs_active'     => 'userlogoutindex',
                'navs_target'     => '_self',
                'navs_order'      => '-99',
                'navs_parent'     => 0,
            ],
            //侧边栏
            [
                'navs_module'     => 'user',
                'navs_type'       => 'sitebar',
                'navs_name'       => '用户中心',
                'navs_info'       => '用户中心首页',
                'navs_url'        => 'user/center/index',
                'navs_status'     => 'private',
                'navs_active'     => 'usercenterindex',
                'navs_target'     => '_self',
                'navs_order'      => 99,
                'navs_parent'     => 0,
            ],
            [
                'navs_module'     => 'user',
                'navs_type'       => 'sitebar',
                'navs_name'       => '积分充值',
                'navs_info'       => '充值网站积分',
                'navs_url'        => 'user/recharge/index',
                'navs_status'     => 'private',
                'navs_active'     => 'userrechargeindex',
                'navs_target'     => '_self',
                'navs_order'      => 98,
                'navs_parent'     => 0,
            ],
            [
                'navs_module'     => 'user',
                'navs_type'       => 'sitebar',
                'navs_name'       => '充值记录',
                'navs_info'       => '网站积分充值记录',
                'navs_url'        => 'user/recharge/log',
                'navs_status'     => 'hidden',
                'navs_active'     => 'userrechargelog',
                'navs_target'     => '_self',
                'navs_order'      => 97,
                'navs_parent'     => 0,
            ],
            [
                'navs_module'     => 'user',
                'navs_type'       => 'sitebar',
                'navs_name'       => '帐号升级',
                'navs_info'       => '升级到相应的用户组',
                'navs_url'        => 'user/group/index',
                'navs_status'     => 'private',
                'navs_active'     => 'usergroupindex',
                'navs_target'     => '_self',
                'navs_order'      => 96,
                'navs_parent'     => 0,
            ],
            [
                'navs_module'     => 'user',
                'navs_type'       => 'sitebar',
                'navs_name'       => '积分日志',
                'navs_info'       => '网站积分增减记录',
                'navs_url'        => 'user/score/index',
                'navs_status'     => 'private',
                'navs_active'     => 'userscoreindex',
                'navs_target'     => '_self',
                'navs_order'      => 94,
                'navs_parent'     => 0,
            ],
            [
                'navs_module'     => 'user',
                'navs_type'       => 'sitebar',
                'navs_name'       => '帐号绑定',
                'navs_info'       => '绑定第三方帐号登录',
                'navs_url'        => 'user/oauth/index',
                'navs_status'     => 'hidden',
                'navs_active'     => 'useroauthindex',
                'navs_target'     => '_self',
                'navs_order'      => -96,
                'navs_parent'     => 0,
            ],
            [
                'navs_module'     => 'user',
                'navs_type'       => 'sitebar',
                'navs_name'       => '修改资料',
                'navs_info'       => '修改用户信息',
                'navs_url'        => 'user/edit/index',
                'navs_status'     => 'private',
                'navs_active'     => 'usereditindex',
                'navs_target'     => '_self',
                'navs_order'      => -97,
                'navs_parent'     => 0,
            ],
            [
                'navs_module'     => 'user',
                'navs_type'       => 'sitebar',
                'navs_name'       => '修改密码',
                'navs_info'       => '修改用户密码',
                'navs_url'        => 'user/repwd/index',
                'navs_status'     => 'private',
                'navs_active'     => 'userrepwdindex',
                'navs_target'     => '_self',
                'navs_order'      => -98,
                'navs_parent'     => 0,
            ],
            [
                'navs_module'     => 'user',
                'navs_type'       => 'sitebar',
                'navs_name'       => '安全退出',
                'navs_info'       => '安全退出已登录帐号',
                'navs_url'        => 'user/logout/index',
                'navs_status'     => 'private',
                'navs_active'     => 'userlogoutindex',
                'navs_target'     => '_self',
                'navs_order'      => -99,
                'navs_parent'     => 0,
            ],
        ]);
    }
    
    //批量添加初始用户
    public function user()
    {
        \daicuo\User::delete_all([
            'user_name' => ['in','user1,user2'],
        ]);
        
        config('common.validate_name', false);
        
        config('common.validate_scene', false);
        
        config('common.where_slug_unique', false);
        
        config('custom_fields.user_meta', ['user_capabilities', 'user_caps', 'user_expire', 'user_pid', 'user_score']);

        return \daicuo\User::save_all([
            [
                'user_name'         => 'user1',
                'user_nice_name'    => 'user1',
                'user_pass'         => 'user1',
                'user_email'        => 'user1@daicuo.org',
                'user_mobile'       => '13800138001',
                'user_status'       => 'normal',
                'user_token'        => 'user1',
                'user_expire'       => strtotime("+1 days"),
                'user_module'       => 'user',
                'user_capabilities' => ['subscriber'],
                'user_slug'         => 'userone',
                'user_score'        => 0,
                'user_pid'          => 0,
                'user_create_time'  => '',
                'user_update_time'  => '',
            ],
            [
                'user_name'         => 'user2',
                'user_nice_name'    => 'user2',
                'user_pass'         => 'user2',
                'user_email'        => 'user2@daicuo.org',
                'user_mobile'       => '13800138002',
                'user_status'       => 'normal',
                'user_token'        => 'user2',
                'user_expire'       => strtotime("+1 days"),
                'user_module'       => 'user',
                'user_capabilities' => ['subscriber'],
                'user_slug'         => 'usertwo',
                'user_score'        => 0,
                'user_pid'          => 0,
                'user_create_time'  => '',
                'user_update_time'  => '',
            ],
        ]);
    }
}