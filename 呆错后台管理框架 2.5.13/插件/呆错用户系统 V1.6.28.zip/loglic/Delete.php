<?php
namespace app\user\loglic;

class Delete
{
    public function init()
    {
        //删除VIP权限节点
        db('op')->where(['op_controll'=>'auth','op_name'=>['eq','vip']])->delete();
        //删除配置表
        \daicuo\Op::delete_module('user');
        //删除队列表
        \daicuo\Term::delete_module('user');
        //删除用户表
        \daicuo\User::delete_module('user');
        //返回结果
        return true;
    }
}