<?php
namespace app\user\loglic;

class Remove
{
    public function init()
    {
        model('common/Config','loglic')->unInstall('user');
        model('common/Field','loglic')->unInstall('user');
        model('common/Route','loglic')->unInstall('user');
        model('common/Role','loglic')->unInstall('user');
        model('common/Auth','loglic')->unInstall('user');
        model('common/Navs','loglic')->unInstall('user');
        model('common/Menu','loglic')->unInstall('user');
        return true;
    }
}