<?php
return [
    'user' => [
        'theme'            => 'default',
        'theme_wap'        => 'default',
        'oauth'            => [],//第三方帐号授权列表
        'callback_secret'  => '',//授权临时码密钥
        'callback_domains' => '',//授权回跳域名
        'captcha_interval' => 60,//动态验证码倒计时
        'captcha_expire'   => 600,//动态验证码有效期
    ]
];