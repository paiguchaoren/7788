$(document).ready(function () {
    $.extend(window.daicuo, {
        user : {
            dialog: function($result, $status, $xhr){
                if ($result.code == 1) {
                    window.location.href = $result.data.redirect;
                }else{
                    window.daicuo.bootstrap.dialog($result.msg);
                    window.daicuo.captcha.refresh();
                }
            },
            //验证码登录回调
            account: function($result, $status, $xhr){
                if ($result.code == 1) {
                    if($result.data.action=='notice'){
                        $('#btn-submit').removeAttr('disabled');
                        window.daicuo.user.interval('#btn-captcha');
                    }else{
                        window.location.href = $result.url;
                    }
                }else{
                    window.daicuo.bootstrap.dialog($result.msg);
                    $('.dc-modal').on('hidden.bs.modal', function (event) {
                        window.daicuo.captcha.refresh();
                    });
                    //setTimeout('$(".dc-modal").modal("hide");', 1000);
                }
            },
            //密码重置回调
            reset: function($result, $status, $xhr){
                if ($result.code == 1) {
                    if($result.data.action=='notice'){
                        $('#btn-submit').removeAttr('disabled');
                        window.daicuo.user.interval('#btn-captcha');
                    }else{
                        daicuo.bootstrap.dialog($result.msg);
                        setTimeout(function(){
                            window.location.href = $result.url;
                        }, 1000);
                    }
                }else{
                    window.daicuo.bootstrap.dialog($result.msg);
                    $('.dc-modal').on('hidden.bs.modal', function (event) {
                        window.daicuo.captcha.refresh();
                    });
                }
            },
            //密码重置事件
            resetSubmit: function(){
                $(document).on("click", 'button[data-toggle="submit"]', function(){
                    if($(this).attr('id')=='btn-captcha'){
                        $('input[name="reset_pwd"]').attr('required',false);
                        $('input[name="reset_captcha"]').attr('required',false);
                    }else{
                        $('input[name="reset_pwd"]').attr('required',true);
                        $('input[name="reset_captcha"]').attr('required',true);
                    }
                });
            },
            //邮箱重置/手机重置回调
            center: function($result, $status, $xhr){
                if ($result.code == 1) {
                    if($result.data.action=='notice'){
                        $('#card-footer').text('请输入接收到的6位验证码');
                        window.daicuo.user.interval('#btn-captcha');
                    }else{
                        location.reload();
                    }
                }else{
                    $('#card-footer').text($result.msg);
                }
            },
            //按钮倒计时
            interval: function(selector){
                var second = $(selector).data('second');
                $(selector).addClass('disabled');
                $(selector).text(second+'秒后重发');
                $(selector).attr('type','button');
                var interval = setInterval(function () {
                    second--;
                    $(selector).text(second+'秒后重发');
                    if(second === -1){
                        $(selector).text($(selector).data('tips'));
                        $(selector).removeClass('disabled');
                        $(selector).attr('type','submit');
                        clearInterval(interval);
                    }
                }, 1000);
            }
        }
    }); //extendEnd
    window.daicuo.user.resetSubmit();
    window.daicuo.captcha.init();
    window.daicuo.form.init();
    window.daicuo.ajax.onClick('[data-toggle="get"]');
});