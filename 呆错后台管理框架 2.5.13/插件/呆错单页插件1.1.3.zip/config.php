<?php
return [
    'page' => [
        'theme'     => 'default',
        'theme_wap' => 'default',
        'info_meta' => ['page_up','page_down','page_tpl'],
    ]
];