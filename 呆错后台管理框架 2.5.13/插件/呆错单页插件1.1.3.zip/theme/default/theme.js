window.daicuo.page = {
    init: function(){
        this.imageFluid();
        this.videoFluid();
    },
    imageFluid: function(){
        $('.content img').addClass('d-block img-fluid mx-auto');
    },
    videoFluid: function(){
        $('.dc-player').addClass('embed-responsive embed-responsive-16by9');
    }
};
//主题JS
$(document).ready(function() { 
    //框架脚本初始化
    window.daicuo.init();
    //主题脚本初始化
    window.daicuo.page.init();
});