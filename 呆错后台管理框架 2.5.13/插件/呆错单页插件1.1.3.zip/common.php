<?php
/**
 * 添加一个单页
 * @version 1.0.0 首次引入
 * @param array $post 必需;数组格式,支持的字段列表请参考手册
 * @return mixed 成功时返回obj,失败时null
 */
function pageSave($post=[])
{
    $post = DcArrayArgs($post,[
        'info_module'   => 'page',
        'info_controll' => 'detail',
        'info_action'   => 'index',
        'info_staus'    => 'normal',
        'page_tpl'      => 'index',
    ]);
    
    $slugUnique = ['info_module'=>['eq','page'],'info_controll'=>['eq','detail']];
    
    return model('common/Info','loglic')->write($post, 'page/Common', 'save', $slugUnique);
}

/**
 * 删除一条或多条单页
 * @version 1.0.0 首次引入
 * @param mixed $ids 必需;多个用逗号分隔或使用数组传入(array|string);默认：空 
 * @return array ID作为键名,键值为删除结果(bool)
 */
function pageDelete($ids=[])
{
    return model('common/Info','loglic')->deleteIds($ids);
}

/**
 * 修改一个单页(需传入主键值作为更新条件)
 * @version 1.0.0 首次引入
 * @param array $post 必需;数组格式,支持的字段列表请参考手册 {
 *     @type int $info_id 必需;按ID修改;默认：空
 * }
 * @return mixed 成功时返回obj,失败时null
 */
function pageUpdate($post=[])
{
    $post = DcArrayArgs($post,[
        'info_module'   => 'page',
        'info_controll' => 'detail',
        'info_action'   => 'index',
        'info_tpl'      => 'index',
    ]);
    
    $slugUnique = ['info_module'=>['eq','page'],'info_controll'=>['eq','detail']];
    
    return model('common/Info','loglic')->write($post, 'page/Common', 'update', $slugUnique);
}

/**
 * 按条件查询一条单页
 * @version 1.0.0 首次引入
 * @param array $args 必需;查询条件数组格式 {
 *     @type bool $cache 可选;是否缓存;默认：true
 *     @type string $status 可选;显示状态（normal|hidden）;默认：空
 *     @type mixed $id 可选;内容ID(stirng|array);默认：空
 *     @type mixed $name 可选;内容名称(stirng|array);默认：空
 *     @type mixed $slug 可选;内容别名(stirng|array);默认：空
 *     @type mixed $title 可选;内容别名(stirng|array);默认：空
 *     @type mixed $user_id 可选;用户ID(stirng|array);默认：空
 *     @type array $with 可选;自定义关联查询条件;默认：空
 *     @type array $view 可选;自定义视图查询条件;默认：空
 *     @type array $where 可选;自定义高级查询条件;默认：空
 * }
 * @return array 查询结果
 */
function pageGet($args=[])
{
    $args = DcArrayArgs($args,[
        'cache'    => true,
        'module'   => 'page',
        'with'     => 'info_meta',
    ]);
    
    $args = DcArrayEmpty($args);
    
    return model('common/Info','loglic')->get($args);
}

/**
 * 按条件获取多条单页
 * @version 1.0.0 首次引入
 * @param array $args 必需;查询条件数组格式 {
 *     @type bool $cache 可选;是否缓存;默认：true
 *     @type int $limit 可选;分页大小;默认：0
 *     @type int $page 可选;当前分页;默认：0
 *     @type string $sort 可选;排序字段名;默认：空
 *     @type string $order 可选;排序方式(asc|desc);默认：asc
 *     @type string $status 可选;显示状态（normal|hidden）;默认：空
 *     @type string $result 可选;返回数据格式(array|obj);默认：array
 *     @type array $where 可选;自定义高级查询条件;默认：空
 *     @type array $paginate 可选;自定义高级分页参数;默认：空
 * }
 * @return mixed 查询结果obj|null
 */
function pageSelect($args=[])
{
    $args = DcArrayArgs($args,[
        'cache'    => true,
        'result'   => 'array',
        'module'   => 'page',
        'with'     => 'info_meta',
    ]);
    return model('common/Info','loglic')->select($args);
}

/**
 * 按ID快速获取一条单页
 * @version 1.0.0 首次引入
 * @param int $value 必需;Id值;默认：空
 * @param bool $cache 可选;是否缓存;默认：true
 * @param string $status 可选;数据状态;默认：空
 * @return mixed 查询结果(obj|null)
 */
function pageId($value='', $cache=true, $status='')
{
    if (!$value) {
        return null;
    }
    return pageGet([
        'id'     => $value,
        'cache'  => $cache,
        'status' => $status,
    ]);
}

/**
 * 按SLUG快速获取一条单页
 * @version 1.0.0 首次引入
 * @param int $value 必需;Id值;默认：空
 * @param bool $cache 可选;是否缓存;默认：true
 * @param string $status 可选;数据状态;默认：空
 * @return mixed 查询结果(obj|null)
 */
function pageSlug($value='', $cache=true, $status='')
{
    if (!$value) {
        return null;
    }
    return pageGet([
        'slug'   => $value,
        'cache'  => $cache,
        'status' => $status,
    ]);
}

/**
 * 按NAME快速获取一条内容数据
 * @version 1.0.0 首次引入
 * @param int $value 必需;Id值；默认：空
 * @param bool $cache 可选;是否缓存;默认：true
 * @param string $status 可选;数据状态;默认：空
 * @return mixed 查询结果(obj|null)
 */
function pageName($value='', $cache=true, $status='')
{
    if (!$value) {
        return null;
    }
    return pageGet([
        'name'   => $value,
        'cache'  => $cache,
        'status' => $status,
    ]);
}

/**
 * 单页形式选项
 * @version 1.0.0 首次引入
 * @return array 处理后的数据
 */
function pageTypeOption(){
    return [
        'index' => '标准',
        'image' => '图文',
        'album' => '相册',
        'video' => '视频',
        'auido' => '音频',
        'link'  => '链接',
    ];
}

/**
 * 内容模型计数增加
 * @version 1.0.0 首次引入
 * @param int $id 必需;ID值;默认:空
 * @param string $field 必需;字段值;默认:info_views
 * @param int $numb 可选;步进值;默认:1
 * @param int $time 可选;延迟更新;默认:0
 * @return int 最新值
 */
function pageInfoInc($id=0, $field='info_views', $num=1, $time=0){
    if(!$id){
        return 0;
    }
    return dbUpdateInc('common/Info', ['info_id'=>['eq',$id]], $field, $num, $time);
}

/**
 * 对日期或时间进行格式化
 * @version 1.0.0 首次引入
 * @param string $format 必需;规定时间戳的格式;空
 * @param mixed $timestamp 可选;规定时间戳;空
 * @return string 格式化后的时间
 */
function pageDate($format='Y-m-d', $timestamp='')
{
    if(!is_numeric($timestamp)){
        $timestamp = strtotime($timestamp);
    }
    return date($format, $timestamp);
}

/**
 * 提取HTML代码的图片地址
 * @version 1.0.0 首次引入
 * @param string $content 必需;待提取的正文内容HTML;空
 * @param string $result 可选;array|first|last;默认:array
 * @return mixed array|string 数组或链接
 */
function pageImagePreg($content='',$result='array')
{
    //有后缀
    /*$preg="/<img.*?src=[\'|\"](.*?(?:[\.gif|\.jpg|\.png|\.jpeg|\.?]))[\'|\"].*?[\/]?>/";*/
    $preg = '/(src)=([\"|\']?)([^ \"\'>]+\.(gif|jpg|jpeg|bmp|png|webp))\\2/i';
    preg_match_all($preg, $content, $match);
    $images = $match[3];
    //无后缀
    if(!$images){
        preg_match_all('/<img.*?src=[\'|\"](.*?)[\'|\"].*?[\/]?>/', $content, $match);
        $images = $match[1];
    }
    //返回结果
    if($result == 'first'){
        return current($images);
    }elseif($result == 'last'){
        return end($images);
    }else{
        return $images;
    }
}

/**
 * 按条件获取导航菜单列表
 * @version 1.0.0 首次引入
 * @param array $args 必需;查询条件数组格式 {
 *     @type bool $cache 可选;是否缓存;默认：true
 *     @type string $result 可选;返回状态(array|tree|level);默认：tree
 *     @type string $status 可选;显示状态（normal|hidden）;默认：空
 *     @type string $module 可选;模型名称;默认：空
 *     @type string $controll 可选;控制器名称;默认：空
 *     @type string $action 可选;操作名称(navbar|navs);默认：空
 *     @type int $limit 可选;分页大小;默认：0
 *     @type string $sort 可选;排序字段名;默认：op_order
 *     @type string $order 可选;排序方式(asc|desc);默认：asc
 *     @type array $where 可选;自定义高级查询条件;默认：空
 * }
 * @return mixed 查询结果obj|null
 */
function pageNavbar($args=[])
{
    //依赖导航菜单插件
    if(function_exists('navbarSelect')){
        return navbarSelect($args);
    }
    //默认只查询分类设置为导航栏
    $args = DcArrayArgs($args,[
        'cache'      => true,
        'result'     => 'tree',
        'status'     => 'normal',
        'type'       => 'category',
        'sort'       => 'term_order',
        'order'      => 'desc',
        'meta_key'   => 'term_navbar',
        'meta_value' => 'yes',
    ]);
    //去掉多余条件
    unset($args['action']);
    //字段映射
    $navs = [];
    foreach(DcTermSelect( $args ) as $key=>$value){
        $value['term_link'] = DcUrl($value['term_module'].'/category/index', ['id'=>$value['term_id']], '');
        foreach($value as $key2=>$value2){
            $navs[$key][str_replace('term_','navs_',$key2)] = $value2;
        }
    }
    return $navs;
}

/**
 * 获取单页内部链接
 * @version 1.0.0 首次引入
 * @param array $info 必需;[id,name,slug]；默认:空
 * @param mixed $pageNumber 可选;int|[PAGE];默认:空
 * @return string 生成的内部网址链接
 */
function pageUrl($info, $pageNumber='')
{
    //数据验证
    $field = pageUrlRewrite(config('page.rewrite_detail'));
    if(!$info['info_'.$field]){
        return 'javascript:;';
    }
    //分页参数
    $args = [
        $field => $info['info_'.$field]
    ];
    if($pageNumber){
        $args['pageNumber'] = $pageNumber;
    }
    //链接函数
    return DcUrl('page/detail/index', $args, '');
}

/**
 * 根据伪静态规则关键字返回对应的字段名
 * @version 1.0.0 首次引入
 * @param string $route 必需;伪静态规则名;空
 * @return string 操作名
 */
function pageUrlRewrite($route='')
{
    if( strpos($route,':slug') !== false ){
        return 'slug';
    }elseif( strpos($route,':name') !== false ){
        return 'name';
    }
    return 'id';
}

/**
 * 替换全站搜索引擎关键字
 * @version 1.0.0 首次引入
 * @param string $route 必需;包含待替换的关键字;空
 * @param string $page 可选;页码;空
 * @return string 过滤后的文本
 */
function pageSeo($string='', $page=0)
{
    if(!$string){
        return '欢迎使用呆错开发框架单页插件';
    }
    $page = DcEmpty($page, input('param.pageNumber/d',1) );
    $search = ['[siteName]', '[siteDomain]', '[pageNumber]'];
    $replace = [config('common.site_name'), config('common.site_domain'), $page];
    return str_replace($search, $replace, $string);
}