<?php
namespace app\page\event;

use app\common\controller\Addon;

class Manage extends Addon
{
    public function _initialize()
    {
        parent::_initialize();
    }
    
    //定义表单字段列表
    protected function fields($data=[])
    {
        $fields = model('page/Common','loglic')->fields($data);
        //个性化字段类型
        if($this->query['action'] == 'index'){
            $fields['category_id']['type']        = 'select';
            $fields['category_id']['data-filter'] = true;
            $fields['category_id']['option'][0]   = '---';
        }
        return $fields;
    }
    
    //定义表单初始数据
    protected function formData()
    {
        if( $id = input('id/d',0) ){
            return model('common/Info','loglic')->getId($id, false);
		}
        return [];
    }
    
    //定义表格数据（JSON）
    protected function ajaxJson()
    {
        $args = array();
        $args['cache']   = false;
        $args['limit']   = DcEmpty($this->query['pageSize'], 30);
        $args['page']    = DcEmpty($this->query['pageNumber'], 1);
        $args['sort']    = DcEmpty($this->query['sortName'], 'info_id');
        $args['order']   = DcEmpty($this->query['sortOrder'], 'desc');
        $args['search']  = $this->query['searchText'];
        //查询数据
        $list = pageSelect($args);
        if( is_null($list) ){
            return [];
        }
        return $list;
    }
    
    public function create()
    {
        $this->assign('query', $this->query);
        
        $this->assign('items', $this->formFields('create', $this->fields($this->query)));
        
		return $this->fetch('page@manage/create');
    }
    
    public function save()
    {
        if( !pageSave(input('post.')) ){
            $this->error(\daicuo\Info::getError());
        }
        $this->success(lang('success'));
    }
    
    public function delete()
    {
        pageDelete(input('id/a'));
        
        $this->success(lang('success'));
    }
    
    public function edit()
    {
        if( !$data=$this->formData() ){
            $this->error(lang('empty'));
        }
        
        $this->assign('data', $data);
        
        $this->assign('query', $this->query);
        
        $this->assign('items', $this->formFields('edit', $this->fields($data)));
        
        return $this->fetch('page@manage/edit');
    }
    
    public function update()
    {
        if( !pageUpdate(input('post.'), true) ){
            $this->error(\daicuo\Info::getError());
        }
        $this->success(lang('success'));
    }
    
    public function status()
    {
        if( !$ids = input('post.id/a') ){
            $this->error(lang('errorIds'));
        }
        //批量更新状态
        model('common/Info','loglic')->status($ids, input('request.value/s', 'hidden'));
        //返回结果
        $this->success(lang('success'));
    }
    
    public function preview()
    {
        if( !$info_id = input('id/d',0) ){
            $this->error(lang('mustIn'));
        }
        //去掉后台入口文件
        $url = str_replace($this->request->baseFile(), '', pageUrl(pageId($info_id, false)));
        //跳转至前台
        $this->redirect($url,302);
    }
}