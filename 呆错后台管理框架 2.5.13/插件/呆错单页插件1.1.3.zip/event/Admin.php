<?php
namespace app\page\event;

use app\common\controller\Addon;

class Admin extends Addon
{
    protected $query = [];
	
	public function _initialize()
    {
        $this->query = $this->request->param();
        
		parent::_initialize();
	}
    
	public function index()
    {
        $themes = DcThemeOption('page');
    
        $items  = DcFormItems([
            'theme' => [
                'type'   =>'select', 
                'value'  => config('page.theme'), 
                'option' => $themes,
            ],
            'theme_wap' => [
                'type'   => 'select',
                'value'  => config('page.theme_wap'),
                'option' => $themes,
            ],
            'slug_first' => [
                'type'   => 'select',
                'value'  => config('page.slug_first'),
                'option' => [0=>lang('close'),1=>lang('open')],
            ],
            'rewrite_index' => [
                'type'        => 'text', 
                'value'       => DcEmpty(config('page.rewrite_index'), 'page$'),
                'placeholder' => '',
                'tips'        => 'page$',
            ],
            'rewrite_detail' => [
                'type'        => 'text',
                'value'       => config('page.rewrite_detail'),
                'placeholder' => '',
                'tips'        => '[:id] [:slug] [:name]',
            ],
            'index_title' => [
                'type'        => 'text', 
                'value'       => config('page.index_title'),
                'placeholder' => '',
                'tips'        => '[siteName] [siteDomain] [pageNumber]',
            ],
            'index_keywords' => [
                'type'        => 'text', 
                'value'       => config('page.index_keywords'),
                'placeholder' => '',
                'tips'        => '[siteName] [siteDomain] [pageNumber]',
            ],
            'index_description' => [
                'type'        => 'text', 
                'value'       => config('page.index_description'),
                'placeholder' => '',
                'tips'        => '[siteName] [siteDomain] [pageNumber]',
            ],
        ]);
        
        $this->assign('items', $items);
        
        return $this->fetch('page@admin/index');
	}
    
    public function update()
    {
        $status = \daicuo\Op::write(input('post.'),'page','config','system',0,'yes');
		if( !$status ){
		    $this->error(lang('fail'));
        }
        //处理伪静态路由
        $this->configRoute(input('post.'));
        //返回结果
        $this->success(lang('success'));
	}
    
    private function configRoute($post)
    {
        //批量删除路由伪静态
        \daicuo\Op::delete_all([
            'op_name'     => ['eq','site_route'],
            'op_module'   => ['eq','page'],
            'op_controll' => ['in','index,detail'],
        ]);
        //批量添加路由伪静态
        $result = \daicuo\Route::save_all([
            [
                'rule'        => $post['rewrite_index'],
                'address'     => 'page/index/index',
                'method'      => 'get',
                'op_module'   => 'page',
            ],
            [
                'rule'        => $post['rewrite_detail'],
                'address'     => 'page/detail/index',
                'method'      => 'get',
                'op_module'   => 'page',
            ],
        ]);
        //清理全局缓存
        DcCache('route_all', null);
    }
}