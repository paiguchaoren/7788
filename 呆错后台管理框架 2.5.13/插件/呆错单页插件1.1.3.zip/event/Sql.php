<?php
namespace app\page\event;

class Sql
{
    /**
    * 安装时触发
    * @return bool 只有返回true时才会往下执行
    */
	public function install()
    {
        //批量添加配置
        model('page/Datas','loglic')->insertConfig();
        
        //批量添加配置
        model('page/Datas','loglic')->insertField();

        //批量添加路由
        model('page/Datas','loglic')->insertRoute();
        
        //批量添加后台菜单
        model('page/Datas','loglic')->insertMenu();
        
        //更新缓存
        \think\Cache::clear();
        
        //返回结果
        return true;
	}
    
    /**
    * 升级时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function upgrade()
    {
        //批量添加配置
        model('page/Datas','loglic')->insertField();

        //批量添加路由
        model('page/Datas','loglic')->insertRoute();
        
        //批量添加后台菜单
        model('page/Datas','loglic')->insertMenu();
        
        //更新版本
        \daicuo\Apply::updateStatus('friend', 'enable');
        
        //更新缓存
        \think\Cache::clear();
        
        return true;
    }
    
    /**
    * 卸载时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function remove()
    {
        return $this->unInstall();
    }
    
    /**
    * 删除时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function unInstall()
    {
        //删除插件配置
        \daicuo\Op::delete_module('page');
        //删除插件分类
        \daicuo\Term::delete_module('page');
        //返回结果
        return true;
	}
}