<?php
//插件语言包
return [
    //错误信息
    'error_params'                  => '参数错误',
    'error_empty'                   => '数据为空',
    'error_search_empty'            => '请输入搜索关键字',
    'error_search_rest'             => '请先休息一下',
    'info_id_require'               => '内容ID不存在',
    'info_slug_unique'              => '别名URL已存在',
    'info_referer_unique'           => '来源地址已存在',
    
    //后台管理
    'page_menu_title'                => '单页',
    'page_manage_index'              => '单页管理',
    'page_manage_create'             => '添加单页',
    'page_manage_edit'               => '修改单页',
    'page_admin_index'               => '频道设置',
    
    //后台管理 > 基础配置
    'theme'                         => '模板主题',
    'theme_wap'                     => '移动端主题',
    'slug_first'                    => '别名首字母',
    'page_size'                     => '默认分页大小',
    'rewrite_index'                 => '频道页伪静态',
    'rewrite_detail'                => '内容页伪静态',
    'index_title'                   => '频道页标题',
    'index_keywords'                => '频道页关键字',
    'index_description'             => '频道页描述',
    
    //模型
    'page_type'                     => '类型',
    'page_up'                       => '点赞',
    'page_down'                     => '反对',
    'page_name_require'             => '单页标题必需填写',
    'page_slug_require'             => '单页别名必需填写',
];