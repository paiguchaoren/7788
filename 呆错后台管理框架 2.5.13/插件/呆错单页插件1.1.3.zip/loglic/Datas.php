<?php
namespace app\page\loglic;

class Datas
{
    //批量写入插件初始配置
    public function insertConfig()
    {
        return model('common/Config','loglic')->install([
            'theme'             => 'default',
            'theme_wap'         => 'default',
            'index_title'       => '呆错单页插件',
            'index_keywords'    => '单页系统,单页插件,自定义单页',
            'index_description' => '呆错单页插件是一款基于呆错后台开发框架研发的单页管理系统，被广泛应用于简单的网站展示。',
            'slug_first'        => 1,
            'search_interval'   => 0,
            'page_size'         => 30,
            'rewrite_index'     => 'page$',
            'rewrite_detail'    => 'page/[:slug]',
        ],'page');
    }
    
    //批量添加扩展字段
    public function insertField()
    {
        config('common.validate_name', '');
        
        return model('common/Field','loglic')->install([
            [
                'op_name'     => 'page_up',
                'op_value'    => json_encode([
                    'type'         => 'text',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'page',
                'op_controll' => 'detail',
                'op_action'   => 'index',
            ],
            [
                'op_name'     => 'page_down',
                'op_value'    => json_encode([
                    'type'         => 'text',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'page',
                'op_controll' => 'detail',
                'op_action'   => 'index',
            ],
            [
                'op_name'     => 'page_tpl',
                'op_value'    => json_encode([
                    'type'         => 'text',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'page',
                'op_controll' => 'detail',
                'op_action'   => 'index',
            ]
        ]);
    }
    
    //批量添加路由伪静态
    public function insertRoute()
    {
        config('common.validate_name', '');
        
        return model('common/Route','loglic')->install([
            [
                'rule'        => 'page$',
                'address'     => 'page/index/index',
                'method'      => 'get',
            ],
            [
                'rule'        => 'page/[:slug]',
                'address'     => 'page/detail/index',
                'method'      => 'get',
            ],
        ],'page');
    }
    
    //批量添加后台菜单
    public function insertMenu()
    {
        $result = model('common/Menu','loglic')->install([
            [
                'term_name'   => '单页',
                'term_slug'   => 'page',
                'term_info'   => 'fa-clone',
                'term_module' => 'page',
            ],
        ]);
        
        $result = model('common/Menu','loglic')->install([
            [
                'term_name'   => '基本设置',
                'term_slug'   => 'page/admin/index',
                'term_info'   => 'fa-gear',
                'term_module' => 'page',
                'term_order'  => 9,
            ],
            [
                'term_name'   => '单页管理',
                'term_slug'   => 'page/manage/index',
                'term_info'   => 'fa-list',
                'term_module' => 'page',
                'term_order'  => 8,
            ],
            [
                'term_name'   => '字段管理',
                'term_slug'   => 'admin/field/index?parent=page&op_module=page',
                'term_info'   => 'fa-cube',
                'term_module' => 'page',
                'term_order'  => 7,
            ],
        ],'单页');
    }
    
    //批量添加前台导航
    public function insertNavs()
    {
        return model('common/Navs','loglic')->install([
            [
                'navs_name'       => '申请友链',
                'navs_url'        => 'friend/publish/index',
                'navs_type'       => 'link',
                'navs_module'     => 'friend',
                'navs_active'     => 'friendpublishindex',
                'navs_target'     => '_self',
            ],
        ]);
    }
    
    //批量添加友链
    public function insertFriend()
    {
        config('common.validate_name', '');
        
        config('common.validate_scene', '');
        
        config('common.where_slug_unique', false);
        
        config('custom_fields.info_meta', ['friend_referer','logo_referer']);

        $list = [
            [
                'info_name'      => '呆错开发框架',
                'friend_referer' => 'https://www.daicuo.org',
                'info_order'     => 99,
                'info_module'    => 'friend',
                'info_controll'  => 'detail',
                'info_action'    => 'index',
                'info_staus'     => 'normal',
            ],
            [
                'info_name'      => '飞飞影视系统',
                'friend_referer' => 'https://www.feifeicms.org',
                'info_order'     => 98,
                'info_module'    => 'friend',
                'info_controll'  => 'detail',
                'info_action'    => 'index',
                'info_staus'     => 'normal',
            ],
            [
                'info_name'      => '呆错站长论坛',
                'friend_referer' => 'http://bbs.daicuo.org',
                'info_order'     => 97,
                'info_module'    => 'friend',
                'info_controll'  => 'detail',
                'info_action'    => 'index',
                'info_staus'     => 'normal',
            ],
        ];
        
        foreach($list as $key=>$post){
            \daicuo\Info::save($post, 'info_meta');
        }
        
        return true;
    }
    
    //按插件应用名删除数据
    public function delete()
    {
        //删除插件配置
        \daicuo\Op::delete_module('friend');
    
        //删除插件分类/标签/导航/菜单
        model('common/Term','loglic')->unInstall('friend');
        
        //删除内容数据
        model('common/Info','loglic')->unInstall('friend');
    }
    
}