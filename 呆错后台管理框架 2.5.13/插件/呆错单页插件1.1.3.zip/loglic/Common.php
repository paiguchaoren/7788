<?php
namespace app\page\loglic;

class Common
{
    /**
    * 定义单页模型的字段
    * @version 1.0.0 首次引入
    * @param array $data 可选;初始数据;默认：空
    * @return array 表格列字段属性（DcBuildTable）
    */
    public function fields($data)
    {
        $fields = [
            'html_1' => [
                'order' => 0,
                'type'  => 'html',
                'value' => '<div class="row"><div class="col-12 col-md-9">',
            ],
            'info_id' => [
                'order' => 0,
                'type'  => 'hidden',
                'value' => $data['info_id'],
            ],
            'info_module' => [
                'order' => 0,
                'type'  => 'hidden',
                'value' => 'page',
            ],
            'info_controll' => [
                'order' => 0,
                'type'  => 'hidden',
                'value' => 'detail',
            ],
            'info_action' => [
                'order' => 0,
                'type'  => 'hidden',
                'value' => 'index',
            ],
            'info_user_id' => [
                'order' => 0,
                'type'  => 'hidden',
                'value' => DcUserCurrentGetId(),
            ],
            'info_name' => [
                'order'           => 1,
                'type'            => 'text',
                'value'           => $data['info_name'],
                'data-visible'    => true,
                'data-align'      => 'left',
                'data-class'      => 'text-wrap',
            ],
            'info_slug' => [
                'order'           => 2,
                'type'            => 'text',
                'value'           => $data['info_slug'],
                'data-filter'     => false,
                'data-visible'    => true,
                'data-align'      => 'left',
                'data-width'      => 150,
            ],
            'info_excerpt' => [
                'order'           => 0,
                'type'            => 'text',
                'value'           => $data['info_excerpt'],
            ],
            'info_content' => [
                'order'           => 0,
                'type'            => 'editor',
                'value'           => $data['info_content'],
                'order'           => 31,
                'rows'            => 50,
                'height'          => '50rem',
            ],
            'html_2' => [
                'order'           => 0,
                'type'            => 'html',
                'value'           => '</div><div class="col-12 col-md-3">',
                'order'           => 199,
            ],
            'info_type' => [
                'order'           => 3,
                'type'            => 'select',
                'value'           => DcEmpty($data['info_type'],'index'),
                'option'          => pageTypeOption(),
                'title'           => lang('page_type'),
                'data-title'      => lang('page_type'),
                'data-filter'     => true,
                'data-visible'    => true,
                'data-width'      => '100',
                'data-width-unit' => 'px',
            ],
            'info_status' => [
                'order'           => 0,
                'type'            => 'select',
                'value'           => $data['info_status'],
                'option'          => ['normal'=>lang('normal'),'hidden'=>lang('hidden'),'private'=>lang('private')],
                'data-filter'     => true,
            ],
            'info_status_text' => [
                'order'           => 4,
                'data-title'      => lang('info_status'),
                'data-filter'     => false,
                'data-visible'    => true,
                'data-width'      => 100,
            ],
            'info_order' => [
                'order'           => 510,
                'type'            => 'number',
                'value'           => intval($data['info_order']),
                'data-filter'     => false,
                'data-visible'    => true,
                'data-sortable'   => true,
                'data-width'      => 100,
            ],
            'info_views' => [
                'order'           => 501,
                'type'            => 'number',
                'value'           => intval($data['info_views']),
                'data-filter'     => false,
                'data-visible'    => true,
                'data-sortable'   => true,
                'data-width'      => 100,
            ],
            'info_hits' => [
                'order'           => 502,
                'type'            => 'number',
                'value'           => intval($data['info_hits']),
                'order'           => 241,
                'data-filter'     => false,
                'data-visible'    => true,
                'data-sortable'   => true,
                'data-width'      => 100,
            ],
            'page_up' => [
                'order'           => 5,
                'type'            => 'number',
                'value'           => intval($data['page_up']),
                'title'           => lang('page_up'),
                'data-title'      => lang('page_up'),
                'data-filter'     => false,
                'data-visible'    => true,
                'data-sortable'   => true,
                'data-width'      => 100,
            ],
            'page_down' => [
                'order'           => 6,
                'type'            => 'number',
                'value'           => intval($data['page_down']),
                'title'           => lang('page_down'),
                'data-title'      => lang('page_down'),
                'data-filter'     => false,
                'data-visible'    => true,
                'data-sortable'   => true,
                'data-width'      => 100,
            ],
            'page_tpl' => [
                'order'           => 0,
                'type'            => 'text',
                'value'           => DcEmpty($data['page_tpl'],'index'),
                'title'           => lang('info_tpl'),
            ],
            'info_title' => [
                'order'           => 0,
                'type'            => 'text',
                'value'           => $data['info_title'],
            ],
            'info_keywords' => [
                'order'           => 0,
                'type'            => 'text',
                'value'           => $data['info_keywords'],
            ],
            'info_description' => [
                'order'           => 0,
                'type'            => 'text',
                'value'           => $data['info_description'],
            ],
            'html_3' => [
                'order'           => 0,
                'type'            => 'html',
                'value'           => '</div></div>',
            ]
        ];
        //动态扩展字段（可精确到操作名）
        $customs = model('common/Info','loglic')->metaList('page', 'detail', 'index');
        //过滤初始字段
        foreach($customs as $key=>$value){
            if(in_array($key,config('page.info_meta'))){
                unset($customs[$key]);
            }
        }
        //合并所有字段
        if($customs){
            $fields = DcArrayPush($fields, DcFields($customs, $data), 'info_content');
        }
        //返回所有表单字段
        return $fields;
    }
}