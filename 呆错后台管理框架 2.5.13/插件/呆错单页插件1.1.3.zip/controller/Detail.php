<?php
namespace app\page\controller;

use app\common\controller\Front;

class Detail extends Front
{

    public function _initialize()
    {
        parent::_initialize();
    }
    
    public function index()
    {
        if( isset($this->query['id']) ){
            $info = pageId($this->query['id']);
        }elseif( isset($this->query['slug']) ){
            $info = pageSlug($this->query['slug']);
        }elseif( isset($this->query['name']) ){
            $info = pageName($this->query['name']);
        }else{
            $this->error(lang('mustIn'),'page/index/index');
        }
        //数据判断
        if(!$info){
            $this->error(lang('empty'),'page/index/index');
        }
        //增加人气值
        pageInfoInc($info['info_id'],'info_views');
        //模板名称
        $info['info_type'] = DcEmpty($info['info_type'], 'index');
        //SEO标签
        $info['info_title'] = pageSeo(DcEmpty($info['info_title'],$info['info_name']));
        $info['info_keywords'] = pageSeo(DcEmpty($info['info_keywords'],$info['info_name']));
        $info['info_description'] = pageSeo(DcEmpty($info['info_description'],$info['info_name']));
        //分享链接
        if(DcBool(config('common.app_domain'))){
            $info['page_share'] = pageUrl($info);
        }else{
            $info['page_share'] = $this->site['domain'].pageUrl($info);
        }
        //变量赋值
        $this->assign($info);
        //加载模板
        return $this->fetch(DcEmpty($info['page_tpl'],$info['info_type']));
    }
}