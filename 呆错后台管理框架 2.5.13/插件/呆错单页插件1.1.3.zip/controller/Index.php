<?php
namespace app\page\controller;

use app\common\controller\Front;

class Index extends Front
{
    public function _initialize()
    {
        parent::_initialize();
    }
    
    public function index()
    {
        $info = [];
        $info['path'] = DcUrl('page/index/index',['pageNumber'=>'[PAGE]'],'');
        $info['index_title']       = pageSeo(config('page.index_title'));
        $info['index_keywords']    = pageSeo(config('page.index_keywords'));
        $info['index_description'] = pageSeo(config('page.index_description'));
        $this->assign($info);
        return $this->fetch();
    }
}