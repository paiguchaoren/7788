$(function(){
	daicuo.lazyload.init();
	daicuo.language.init({method:'auto'});
	daicuo.page.init();
});