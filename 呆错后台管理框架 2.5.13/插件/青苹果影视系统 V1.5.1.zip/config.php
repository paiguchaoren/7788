<?php
return [
    'maccms' => [
        'theme'     => 'default_pc',
        'theme_wap' => 'default_wap',
    ]
];