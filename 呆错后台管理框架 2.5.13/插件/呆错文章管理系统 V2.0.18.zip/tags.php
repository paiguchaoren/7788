<?php
return [
    'admin_index_count' => [
        'app\\cms\\behavior\\Hook',
    ],
    'admin_caps_front' => [
        'app\\cms\\behavior\\Hook',
    ],
    'admin_caps_back' => [
        'app\\cms\\behavior\\Hook',
    ]
];