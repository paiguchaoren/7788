<?php
namespace app\cms\behavior;

use think\Controller;

class Hook extends Controller
{
    //后台首页统计
    public function adminIndexCount(&$datas)
    {
        if(config('cms.count_detail')){
            array_push($datas,[
                'id'    => 'detail',
                'title' => 'cms_count_detail',
                'ico'   => 'fa-file-text',
                'color' => 'text-primary',
                'count' => model('cms/Count','loglic')->detail(),
            ]);
        }
        if(config('cms.count_tag')){
            array_push($datas,[
                'id'    => 'tag',
                'title' => 'cms_count_tag',
                'ico'   => 'fa-tags',
                'color' => 'text-warning',
                'count' => model('cms/Count','loglic')->tag(),
            ]);
        }
        if(config('cms.count_type')){
            array_push($datas,[
                'id'    => 'category',
                'title' => 'cms_count_category',
                'ico'   => 'fa-folder-o',
                'color' => 'text-danger',
                'count' => model('cms/Count','loglic')->category(),
            ]);
        }
    }
    
    //前台权限扩展
    public function adminCapsFront(&$caps)
    {
        $caps = array_merge($caps,[
            'cms/data/index',
        ]);
    }
    
    //后台权限扩展
    public function adminCapsBack(&$caps)
    {
        $caps = array_merge($caps,[
            'cms/admin/index',
            'cms/admin/save',
            'cms/admin/delete',
            'cms/collect/index',
            'cms/collect/save',
            'cms/collect/delete',
            'cms/collect/write',
        ]);
    }
}