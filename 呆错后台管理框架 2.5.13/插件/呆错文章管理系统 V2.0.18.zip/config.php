<?php
return ['cms' => [
    //初始模板
    'theme'         => 'default',
    'theme_wap'     => 'default',
    //后台统计
    'count_detail'  => true,
    'count_type'    => true,
    'count_tag'     => true,
    //初始分页数量
    'limit_index'   => 10,
    'limit_search'  => 10,
    'limit_filter'  => 10,
    'limit_tags'    => 60,
    'limit_category'=> 10,
    'limit_tag'     => 10,
    'limit_sitemap' => 100,
    //初始排序字段
    'sort_index'    => 'info_order',
    'sort_type'     => 'detail_id',
    'sort_tag'      => 'detail_id',
    'sort_filter'   => 'info_id',
    'sort_search'   => 'info_views',
    'sort_data'     => 'info_update_time',
    //是否固定查询总数(true|flase|number)
    'total_index'   => false,
    'total_type'    => false,
    'total_tag'     => false,
    'total_filter'  => false,
    'total_search'  => false,
    'total_data'    => false,
    'total_admin'   => false,
    //是否简洁高效分页列表
    'page_start'    => false,
    //导航栏应用限制
    'navs_module'   => 'cms,common,user',
    //初始查询字段
    'field_select'  => 'info_name,info_slug,info_action,info_excerpt,info_update_time,info_create_time,info_views,info_hits',
    //siteMap限制(具体数字)
    'sitemap_max'   => 0,
]];