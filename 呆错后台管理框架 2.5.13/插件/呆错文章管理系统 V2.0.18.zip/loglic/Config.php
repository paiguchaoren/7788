<?php
namespace app\cms\loglic;

class Config
{
    public function fields($data=[])
    {
        $themes = DcThemeOption('cms');

        $fields = [
            'theme' => [
                'type'   =>'select', 
                'value'  => config('cms.theme'), 
                'option' => $themes,
            ],
            'theme_wap' => [
                'type'   => 'select',
                'value'  => config('cms.theme_wap'),
                'option' => $themes,
            ],
            'slug_first' => [
                'type'       => 'select',
                'value'      => config('cms.slug_first'),
                'option'     => [0=>lang('close'),1=>lang('open')],
            ],
            'index_title' => [
                'type'        => 'text', 
                'value'       => config('cms.index_title'),
                'tips'        => '[siteName] [siteDomain] [pageNumber]',
            ],
            'index_keywords' => [
                'type'        => 'text', 
                'value'       => config('cms.index_keywords'),
                'tips'        => '[siteName] [siteDomain] [pageNumber]',
            ],
            'index_description' => [
                'type'        => 'text', 
                'value'       => config('cms.index_description'),
                'tips'        => '[siteName] [siteDomain] [pageNumber]',
            ],
            'baidu_api' => [
                'type'       => 'text',
                'value'      => config('cms.baidu_api'),
                'tips'       => lang('cms_baidu_api_tips'),
            ],
            'search_list' => [
                'type'        => 'text',
                'value'       => config('cms.search_list'),
                'rows'        => 3,
                'tips'        => lang('cms_search_list_tips'),
            ],
            'search_hot' => [
                'type'        => 'text',
                'value'       => config('cms.search_hot'),
                'rows'        => 3,
                'tips'        => lang('cms_search_hot_tips'),
            ],
            'post_pwd' => [
                'type'       => 'text',
                'value'      => config('cms.post_pwd'),
                'tips'       => lang('cms_post_pwd_tips'),
            ],
            'label_strip' => [
                'type'       => 'text',
                'value'      => config('cms.label_strip'),
                'tips'       => lang('cms_label_strip_tips'),
            ],
            'action_name' => [
                'type'       => 'text',
                'value'      => config('cms.action_name'),
                'tips'        => lang('cms_action_name_tips'),
            ],
            'type_option' => [
                'type'       => 'text',
                'value'      => config('cms.type_option'),
                'tips'        => lang('cms_type_option_tips'),
            ],
            'hr_1' => [
                'type'        => 'html',
                'value'       => '<hr>',
            ],
            'limit_index' => [
                'type'        => 'number',
                'value'       => intval(config('cms.limit_index')),
            ],
            'limit_search' => [
                'type'        => 'number',
                'value'       => DcEmpty(config('cms.limit_search'),10),
            ],
            'limit_filter' => [
                'type'        => 'number',
                'value'       => DcEmpty(config('cms.limit_filter'),10),
            ],
            'limit_tags' => [
                'type'        => 'number',
                'value'       => DcEmpty(config('cms.limit_tags'),10),
            ],
            'limit_sitemap' => [
                'type'        => 'number',
                'value'       => DcEmpty(config('cms.limit_sitemap'),10),
            ],
            'limit_category' => [
                'type'        => 'number',
                'value'       => intval(config('cms.limit_category')),
            ],
            'limit_tag' => [
                'type'        => 'number',
                'value'       => intval(config('cms.limit_tag')),
            ],
            'hr_2' => [
                'type'        => 'html',
                'value'       => '<hr>',
            ],
            'white_ip' => [
                'type'        => 'textarea',
                'value'       => config('cms.white_ip'),
                'tips'        => lang('cms_white_ip_tips'),
                'rows'        => 2,
            ],
            'black_ip' => [
                'type'        => 'textarea',
                'value'       => config('cms.black_ip'),
                'tips'        => lang('cms_black_ip_tips'),
                'rows'        => 2,
            ],
            'close_useragent' => [
                'type'        => 'textarea',
                'value'       => config('cms.close_useragent'),
                'tips'        => lang('cms_close_useragent_tips'),
                'rows'        => 2,
            ],
            'request_max' => [
                'type'        => 'number',
                'value'       => intval(config('cms.request_max')),
                'tips'        => lang('cms_request_max_tips'),
            ],
            'search_interval' => [
                'type'        => 'number',
                'value'       => intval(config('cms.search_interval')),
                'tips'        => lang('cms_search_interval_tips'),
            ],
        ];
        foreach($fields as $key=>$value){
            $fields[$key]['title'] = lang('cms_'.$key);
            //$fields[$key]['placeholder'] = '';
        }
        //扩展表单字段（自动加载）
        if($customs = cmsMetaList('config', 'index')){
            $fields['hr'] = [
                'type'        => 'html',
                'value'       => '<hr>',
            ];
            $fields = array_merge($fields, DcFields($customs, config('cms')) );
        }
        //返回结果
        return DcFormItems($fields);
    }
    
    //基础配置按操作名加载
    public function fieldsAction($data=[])
    {
        $action = DcEmpty($data['op_action'],'index');
        
        cmsConfigAction($action);
        
        $fields = [
            'op_action' => [
                'type'        => 'hidden',
                'value'       => $action,
            ],
            'limit_index' => [
                'type'        => 'number',
                'value'       => intval(config('cms.limit_index')),
            ],
            'limit_search' => [
                'type'        => 'number',
                'value'       => DcEmpty(config('cms.limit_search'),10),
            ],
            'limit_filter' => [
                'type'        => 'number',
                'value'       => DcEmpty(config('cms.limit_filter'),10),
            ],
            'limit_tags' => [
                'type'        => 'number',
                'value'       => DcEmpty(config('cms.limit_tags'),10),
            ],
        ];
        foreach($fields as $key=>$value){
            $fields[$key]['title'] = lang('cms_'.$key);
            $fields[$key]['placeholder'] = '';
        }
        //扩展表单字段（手动加载）
        if($customs = cmsMetaList('config', $action)){
            $fields['hr'] = [
                'type'        => 'html',
                'value'       => '<hr>',
            ];
            $fields = array_merge($fields, DcFields($customs, config('cms')) );
        }
        return DcFormItems($fields);
    }
}