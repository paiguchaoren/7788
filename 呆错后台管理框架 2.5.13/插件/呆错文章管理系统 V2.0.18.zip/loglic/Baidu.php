<?php
namespace app\cms\loglic;

class Baidu
{
    public function fields($data=[])
    {
        return DcFormItems([
            'pageSize' => [
                'type'   => 'text', 
                'value'  => '100', 
                'title'  => '每页数量',
            ],
            'start' => [
                'type'   => 'text', 
                'value'  => intval(DcCache('cmsStart')), 
                'title'  => '开始ID',
            ],
        ]);
    }
    
    public function fieldsTag($data=[])
    {
        return DcFormItems([
            'pageSize' => [
                'type'   => 'text', 
                'value'  => '100', 
                'title'  => '每页数量',
            ],
            'startTag' => [
                'type'   => 'text', 
                'value'  => intval(DcCache('startTag')), 
                'title'  => '开始ID',
            ],
        ]);
    }
    
    public function fieldsForm($data=[])
    {
        return DcFormItems([
            'urls' => [
                'type'   => 'textarea', 
                'value'  => implode(chr(13),$data),
                'rows'   => '10',
                'title'  => '每页数量',
                'class_left'  => 'd-none',
                'class_right' => 'col-12',
            ],
        ]);
    }
}