<?php
namespace app\cms\loglic;

class Count
{
    public function category()
    {
        return db('term')->where(['term_module'=>'cms','term_controll'=>'category'])->count('term_id');
    }
    
    public function tag()
    {
        return db('term')->where(['term_module'=>'cms','term_controll'=>'tag'])->count('term_id');
    }
    
    public function views()
    {
        return db('info')->where(['info_module'=>'cms'])->sum('info_views');
    }
    
    public function detail()
    {
        return db('info')->where(['info_module'=>'cms'])->count();
    }
}