<?php
namespace app\cms\loglic;

use app\common\loglic\Update;

class Upgrade extends Update
{
    //更新应用状态
    public function status()
    {
        \daicuo\Apply::updateStatus('cms', 'enable');
        
        return true;
    }
    
    //更新打包信息
    public function pack()
    {
        if(config('common.apply_module') != 'cms'){
            return true;
        }
        
        return \daicuo\Op::write([
            'apply_name'    => '呆错文章管理系统',
            'apply_module'  => 'cms',
            'apply_version' => config('apply.version'),
            'apply_rely'    => '',
        ], 'common', 'config', 'system', 0, 'yes');
    }
    
    //更新后台菜单
    public function menu()
    {
        return true;
    }
    
    //更新前台菜单
    public function navs()
    {
        return true;
    }
    
    //升级框架脚本
    public function frame(){
        return \think\Db::execute("update dc_term set term_action='index' where term_controll='navs';");
    }
}