<?php
namespace app\cms\loglic;

class Remove
{
    //卸载时删除插件配置（不删除分类、标签、内容）
    public function init()
    {
        //删除插件配置表
        \daicuo\Op::delete_module('cms');
        
        //删除后台菜单
        model('common/Menu','loglic')->unInstall('cms');
        
        //删除前台菜单
        model('common/Navs','loglic')->unInstall('cms');
    }
}