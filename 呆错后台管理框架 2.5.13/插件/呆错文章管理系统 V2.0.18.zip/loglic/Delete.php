<?php
namespace app\cms\loglic;

class Delete
{
    //按插件应用名删除数据
    public function init()
    {
        //删除插件配置表
        \daicuo\Op::delete_module('cms');
        
        //删除插件分类/标签/导航
        \daicuo\Term::delete_module('cms');
        
        //删除内容数据
        \daicuo\Info::delete_module('cms');
    }
}