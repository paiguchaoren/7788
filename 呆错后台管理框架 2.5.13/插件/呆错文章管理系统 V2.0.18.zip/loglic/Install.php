<?php
namespace app\cms\loglic;

class Install
{
    //安装mysql版固定回调接口
    public function mysql()
    {
        \daicuo\Apply::install('ckeditor','install');
        
        \daicuo\Apply::install('adsense','install');
        
        \daicuo\Apply::install('friend','install');
        
        \daicuo\Apply::install('cms','install');
        
        $this->testData();
        
        $this->mysqlBack();
        
        return true;
    }
    
    //设置首页路由
    private function mysqlBack()
    {
        //公共
        \daicuo\Op::write([
            'apply_name'    => '呆错文章管理系统',
            'apply_module'  => 'cms',
            'apply_version' => '2.0.18',
            'apply_rely'    => '',
            'site_name'     => '呆错文章管理系统',
            'url_suffix'    => '.html',
        ], 'common', 'config', 'system', 0, 'yes');
        //配置
        \daicuo\Op::write([
            'rewrite_index' => '/',
        ], 'cms', 'config', 'system', 0, 'yes');
        //删除
        db('op')->where([
            'op_name'  => 'site_route',
            'op_value' => ['like','a:5:{s:4:"rule";s:4:"cms$"%'],
        ])->delete();
        //首页
        return model('common/Route','loglic')->index('cms/index/index', 'cms');
    }
    
    //批量添加初始配置
    public function config()
    {
        config('common.validate_name', false);
        
        return model('common/Config','loglic')->install([
            'theme'             => 'default',
            'theme_wap'         => 'default',
            'index_title'       => '呆错文章管理系统',
            'index_keywords'    => '新闻发布系统,文章管理系统,文章系统,文章CMS,新闻CMS',
            'index_description' => '呆错文章系统是一款基于呆错后台开发框架研发的文章管理系统，被广泛应用于搭建博客、行业站、企业站、产品展示等。',
            'slug_first'        => 1,
            'request_max'       => 0,
            'search_interval'   => 0,
            'search_hot'        => '',
            'search_list'       => 'cms/search/baidu,cms/search/bing',
            'action_name'       => 'index',
            'type_option'       => 'image,album,video,auido,link',
            'rewrite_index'     => 'cms$',
            'limit_index'       => 10,
            'limit_category'    => 10,
            'limit_tag'         => 10,
            'limit_search'      => 10,
            'limit_filter'      => 10,
            'limit_sitemap'     => 100,
            'limit_tags'        => 60,
        ],'cms');
    }
    
    //批量定义语言包
    public function lang()
    {
        return model('common/Lang','loglic')->install([
            //前台错误信息
            'cms_error_params'  => '参数错误',
            'cms_error_empty'   => '未查询到相关信息',
            'cms_error_rest'    => '请先休息一下',
            //前台筛选页
            'cms_views'         => '人气',
            'cms_order'         => '权重',
            'cms_update_time'   => '时间',
            'cms_order_desc'    => '倒序',
            'cms_order_asc'     => '正序',
            'cms_type_index'    => '标准',
            'cms_type_image'    => '图文',
            'cms_type_album'    => '相册',
            'cms_type_video'    => '视频',
            'cms_type_auido'    => '音频',
            'cms_type_link'     => '链接',
            //前台TKD
            'cms_categorys_index_title'        => '所有分类标题',
            'cms_categorys_index_keywords'     => '所有分类关键字',
            'cms_categorys_index_description'  => '所有分类描述',
            'cms_tags_index_title'             => '所有标签标题',
            'cms_tags_index_keywords'          => '所有标签关键字',
            'cms_tags_index_description'       => '所有标签描述',
            'cms_search_index_title'           => '搜索页标题-[searchText]',
            'cms_search_index_keywords'        => '搜索页关键字',
            'cms_search_index_description'     => '搜索页描述',
        ],'cms','zh-cn');
    }
    
    //批量添加字段
    public function field()
    {
        config('common.validate_name', false);
        
        return model('common/Field','loglic')->install([
            [
                'op_name'     => 'cms_color',
                'op_value'    => json_encode([
                    'type'         => 'text',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'cms',
                'op_controll' => 'detail',
                'op_action'   => 'default',
            ],
            [
                'op_name'     => 'cms_cover',
                'op_value'    => json_encode([
                    'type'         => 'image',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'cms',
                'op_controll' => 'detail',
                'op_action'   => 'default',
            ],
            [
                'op_name'     => 'cms_slide',
                'op_value'    => json_encode([
                    'type'         => 'image',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'cms',
                'op_controll' => 'detail',
                'op_action'   => 'default',
            ],
            [
                'op_name'     => 'cms_up',
                'op_value'    => json_encode([
                    'type'         => 'number',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'cms',
                'op_controll' => 'detail',
                'op_action'   => 'default',
            ],
            [
                'op_name'     => 'cms_down',
                'op_value'    => json_encode([
                    'type'         => 'number',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'cms',
                'op_controll' => 'detail',
                'op_action'   => 'default',
            ],
            [
                'op_name'     => 'cms_referer',
                'op_value'    => json_encode([
                    'type'         => 'text',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'cms',
                'op_controll' => 'detail',
                'op_action'   => 'default',
            ],
            [
                'op_name'     => 'cms_letter',
                'op_value'    => json_encode([
                    'type'         => 'text',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'cms',
                'op_controll' => 'detail',
                'op_action'   => 'default',
            ],
            [
                'op_name'     => 'cms_tpl',
                'op_value'    => json_encode([
                    'type'         => 'text',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'cms',
                'op_controll' => 'detail',
                'op_action'   => 'default',
            ],
            [
                'op_name'     => 'cms_top',
                'op_value'    => json_encode([
                    'type'         => 'hidden',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'cms',
                'op_controll' => 'detail',
                'op_action'   => 'default',
            ],
            [
                'op_name'     => 'cms_recommend',
                'op_value'    => json_encode([
                    'type'         => 'hidden',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'cms',
                'op_controll' => 'detail',
                'op_action'   => 'default',
            ],
            [
                'op_name'     => 'cms_fast',
                'op_value'    => json_encode([
                    'type'         => 'hidden',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'cms',
                'op_controll' => 'detail',
                'op_action'   => 'default',
            ],
            [
                'op_name'     => 'cms_head',
                'op_value'    => json_encode([
                    'type'         => 'hidden',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'cms',
                'op_controll' => 'detail',
                'op_action'   => 'default',
            ]
        ]);
    }
    
    //批量添加路由
    public function route()
    {
        config('common.validate_name', false);
        
        return model('common/Route','loglic')->install([
            [
                'rule'        => 'cms$',
                'address'     => 'cms/index/index',
                'method'      => '*',
                'op_module'   => 'cms',
                'op_controll' => 'route',
                'op_action'   => 'system',
            ],
        ]);
    }
    
    //批量添加权限
    public function auth()
    {
        //取消验证
        config('common.validate_name', false);
        
        //前台权限
        return model('common/Auth','loglic')->install([
            [
                'op_name'       => 'contributor',
                'op_value'      => 'cms/data/index',
                'op_module'     => 'cms',
                'op_controll'   => 'auth',
                'op_action'     => 'front',
            ]
        ]);
    }
    
    //批量添加后台菜单
    public function menu()
    {
        config('common.validate_name', false);
        
        $result = model('common/Menu','loglic')->install([
            [
                'term_name'   => '文章',
                'term_slug'   => 'cms',
                'term_info'   => 'fa-file-text',
                'term_module' => 'cms',
                'term_order'  => 9,
            ],
        ]);
        
        $result = model('common/Menu','loglic')->install([
            [
                'term_name'   => '文章管理',
                'term_slug'   => 'cms/admin/index',
                'term_info'   => 'fa fa-file-text',
                'term_module' => 'cms',
                'term_order'  => 9,
            ],
            [
                'term_name'   => '采集管理',
                'term_slug'   => 'cms/collect/index',
                'term_info'   => 'fa-cloud',
                'term_module' => 'cms',
                'term_order'  => 8,
            ],
            [
                'term_name'   => '栏目管理',
                'term_slug'   => 'admin/category/index?parent=cms&term_module=cms',
                'term_info'   => 'fa-list',
                'term_module' => 'cms',
                'term_order'  => 7,
            ],
            [
                'term_name'   => '标签管理',
                'term_slug'   => 'admin/tag/index?parent=cms&term_module=cms',
                'term_info'   => 'fa-tags',
                'term_module' => 'cms',
                'term_order'  => 6,
            ],
            [
                'term_name'   => '菜单管理',
                'term_slug'   => 'admin/navs/index?parent=cms&navs_module=cms',
                'term_info'   => 'fa-sitemap',
                'term_module' => 'cms',
                'term_order'  => 5,
            ],
            [
                'term_name'   => 'SEO优化',
                'term_slug'   => 'cms/seo/index',
                'term_info'   => 'fa-anchor',
                'term_module' => 'cms',
                'term_order'  => 4,
            ],
            [
                'term_name'   => '百度推送',
                'term_slug'   => 'cms/baidu/index',
                'term_info'   => 'fa-paw',
                'term_module' => 'cms',
                'term_order'  => 3,
            ],
            [
                'term_name'   => '路由管理',
                'term_slug'   => 'admin/route/index?parent=cms&op_module=cms',
                'term_info'   => 'fa-wifi',
                'term_module' => 'cms',
                'term_order'  => -5,
            ],
            [
                'term_name'   => '字段管理',
                'term_slug'   => 'admin/field/index?parent=cms&op_module=cms',
                'term_info'   => 'fa-cube',
                'term_module' => 'cms',
                'term_order'  => -6,
            ],
            [
                'term_name'   => '语言定义',
                'term_slug'   => 'admin/lang/index?parent=cms&op_module=cms',
                'term_info'   => 'fa-commenting',
                'term_module' => 'cms',
                'term_order'  => -7,
            ],
            [
                'term_name'   => '后台菜单',
                'term_slug'   => 'admin/menu/index?parent=cms&term_module=cms',
                'term_info'   => 'fa-navicon',
                'term_module' => 'cms',
                'term_order'  => -8,
            ],
            [
                'term_name'   => '频道设置',
                'term_slug'   => 'cms/config/index',
                'term_info'   => 'fa-gear',
                'term_module' => 'cms',
                'term_order'  => -9,
            ],
        ],'文章');
        
        return true;
    }
    
    //批量添加前台菜单
    public function navs()
    {
        config('common.validate_name', false);
        
        model('common/Navs','loglic')->install([
            [
                'navs_name'       => '文章首页',
                'navs_url'        => 'cms/index/index',
                'navs_type'       => 'navbar',
                'navs_action'     => 'index',
                'navs_module'     => 'cms',
                'navs_active'     => 'cmsindexindex',
                'navs_target'     => '_self',
                'navs_order'      => 9,
            ],
            [
                'navs_name'       => '返回首页',
                'navs_url'        => 'cms/index/index',
                'navs_type'       => 'bottom',
                'navs_action'     => 'index',
                'navs_module'     => 'cms',
                'navs_active'     => 'cmsindexindex',
                'navs_target'     => '_self',
                'navs_order'      => 7,
            ],
            [
                'navs_name'       => '网站分类',
                'navs_url'        => 'cms/categorys/index',
                'navs_type'       => 'bottom',
                'navs_action'     => 'index',
                'navs_module'     => 'cms',
                'navs_active'     => 'cmscategorysindex',
                'navs_target'     => '_self',
                'navs_order'      => 6,
            ],
            [
                'navs_name'       => '网站标签',
                'navs_url'        => 'cms/tags/index',
                'navs_type'       => 'bottom',
                'navs_action'     => 'index',
                'navs_module'     => 'cms',
                'navs_active'     => 'cmstagsindex',
                'navs_target'     => '_self',
                'navs_order'      => 5,
            ],
            [
                'navs_name'       => '网站地图',
                'navs_url'        => 'cms/page/index',
                'navs_type'       => 'bottom',
                'navs_action'     => 'index',
                'navs_module'     => 'cms',
                'navs_active'     => 'cmspageindex',
                'navs_target'     => '_self',
                'navs_order'      => 4,
            ],
            [
                'navs_name'       => '最近更新',
                'navs_url'        => 'cms/page/news',
                'navs_type'       => 'bottom',
                'navs_action'     => 'index',
                'navs_module'     => 'cms',
                'navs_active'     => 'cmspagenews',
                'navs_target'     => '_self',
                'navs_order'      => 3,
            ],
            [
                'navs_name'       => '人气排行',
                'navs_url'        => 'cms/page/views',
                'navs_type'       => 'bottom',
                'navs_action'     => 'index',
                'navs_module'     => 'cms',
                'navs_active'     => 'cmspageviews',
                'navs_target'     => '_self',
                'navs_order'      => 2,
            ],
            [
                'navs_name'       => '站长推荐',
                'navs_url'        => 'cms/page/recommend',
                'navs_type'       => 'bottom',
                'navs_action'     => 'index',
                'navs_module'     => 'cms',
                'navs_active'     => 'cmspagerecommend',
                'navs_target'     => '_self',
                'navs_order'      => 1,
            ],
            [
                'navs_name'       => 'SiteMap',
                'navs_url'        => 'cms/sitemap/indexs',
                'navs_type'       => 'bottom',
                'navs_action'     => 'index',
                'navs_module'     => 'cms',
                'navs_active'     => 'cmssitemapindex',
                'navs_target'     => '_self',
                'navs_order'      => 0,
            ],
        ]);
        
        return true;
    }
    
    //批量添加初始分类
    public function category()
    {
        config('common.validate_name', false);
        
        model('common/Category','loglic')->install([
            [
                'term_name'       => '分类1',
                'term_slug'       => 'category1',
                'term_type'       => 'navbar',
                'term_module'     => 'cms',
            ],
            [
                'term_name'       => '分类2',
                'term_slug'       => 'category2',
                'term_type'       => 'navbar',
                'term_module'     => 'cms',
            ],
        ]);
        
        return true;
    }
    
    //批量添加初始标签
    public function tag()
    {
        config('common.validate_name', false);
        
        model('common/Tag','loglic')->install([
            [
                'term_name'       => '标签1',
                'term_slug'       => 'tag1',
                'term_module'     => 'cms',
            ],
            [
                'term_name'       => '标签2',
                'term_slug'       => 'tag2',
                'term_module'     => 'cms',
            ],
        ]);
        
        return true;
    }

    //添加采集规则
    public function collect()
    {
        config('common.validate_name', false);
        
        model('cms/Collect','loglic')->write([
            'collect_name'     => '影视评论',
            'collect_url'      => 'http://api.daicuo.cc/yingping/',
            'collect_token'    => '',
            'collect_category' => '',
        ]);
        
        model('cms/Collect','loglic')->write([
            'collect_name'     => '演示数据',
            'collect_url'      => 'http://demo.daicuo.com/index.php',
            'collect_token'    => 'fb05aabf582499263dfc235a82629069',
            'collect_category' => '',
        ]);
        
        return true;
    }
    
    //添加测试数据
    public function testData()
    {
        config('common.validate_scene', false);
        
        config('common.where_slug_unique', false);
        
        config('custom_fields.info_meta', model('common/Info','loglic')->metaKeys('cms','detail','index'));
        
        $data = [];
        $data['info_module']   = 'cms';
        $data['info_controll'] = 'detail';
        $data['info_action']   = 'index';
        $data['info_staus']    = 'normal';
        $data['info_type']     = 'index';
        $data['info_user_id']  = 1;
        $data['info_order']    = 9;
        $data['info_name']     = '欢迎使用呆错文章管理系统';
        $data['info_excerpt']  = '呆错文章系统（DaiCuoCms）是一款免费开源的PHP新闻文章管理系统，被广泛应用于搭建博客、行业站、企业站、产品展示等。';
        $data['info_content']  = '呆错文章系统（DaiCuoCms）是一款免费开源的PHP新闻文章管理系统，被广泛应用于搭建博客、行业站、企业站、产品展示等。';
        $data['term_id']       = model('common/Term','loglic')->nameToId('分类1,分类2', 'cms', 'category', 'yes');
        $data['term_id']       = DcArrayArgs(model('common/Term','loglic')->nameToId('标签1,标签2', 'cms', 'tag', 'yes'), $data['term_id']);
        $data['cms_cover']     = 'https://cdn.daicuo.cc/images/cms/cover.qrcode.png';//封面
        $data['cms_up']        = 9;
        $data['cms_down']      = 0;
        $data['cms_recommend'] = 1;
        $data['cms_top']       = 1;
        $data['cms_letter']    = 'd';
        
        return \daicuo\Info::save($data, 'info_meta,term_map');
    }
}