<?php
namespace app\cms\controller;

use app\common\controller\Front;

class Search extends Front
{
    private $info  = [];
    
    private $items = [];
    
    public function _initialize()
    {
        //请求过滤
        $this->request->filter('trim,strip_tags,htmlspecialchars');
        //post请求
        if( $this->request->isPost() ){
            $this->redirect(DcUrl('cms/search/'.$this->request->action(),['searchText'=>input('post.searchText/s')]),302);
        }
        //请求验证
        if( !cmsRequestCheck($this->request->ip(),$this->request->header('user-agent')) ){
            $this->error(lang('cms_error_rest'), 'cms/index/index');
        }
        //继承上级
        parent::_initialize();
    }
    
    public function index()
    {
        return $this->detail('index');
    }
    
    public function baidu()
    {
        $this->redirect('https://www.baidu.com/s?tn=bds&cl=3&ct=2097152&si='.config('common.site_domain').'&wd='.$this->query['searchText'],302);
    }
    
    public function sogou()
    {
        $this->redirect('https://www.sogou.com/web?query='.$this->query['searchText'],302);
    }
    
    public function toutiao()
    {
        $this->redirect('https://so.toutiao.com/search?mod=website&keyword='.$this->query['searchText'],302);
    }
    
    public function bing()
    {
        $this->redirect('https://cn.bing.com/search?q='.$this->query['searchText'],302);
    }
    
    public function so()
    {
        $this->redirect('https://www.so.com/s?q='.$this->query['searchText'],302);
    }
    
    //空操作
    public function _empty($action='')
    {
        //允许的操作名
        if(!in_array($action,explode(',',config('cms.action_name')))){
            $this->error(lang('cms_error_params'));
        }
        //内容模块独立配置
        cmsConfigAction($action);
        //查询数据
        return $this->detail($action);
    }
    
    //站内搜索
    private function detail($action='index')
    {
        //判断是否有关键词
        if( !$this->query['searchText'] ){
            $this->error(lang('cms_error_params'),'cms/index/index');
        }
        
        //搜索限制验证
        if( !$this->searchCheck() ){
            $this->error(lang('cms_error_rest'), 'cms/index/index');
        }
        
        //地址栏
        $this->info['searchText']    = $this->query['searchText'];
        
        //所有搜索引擎链接
        $this->info['searchList']     = $this->searchList($this->query['searchText']);
        
        //SEO标签
        $this->info['seoTitle']       = cmsSeo(str_replace('[searchText]',$this->info['searchText'],lang('cms_search_'.$action.'_title')),$this->site['page']);
        $this->info['seoKeywords']    = cmsSeo(str_replace('[searchText]',$this->info['searchText'],lang('cms_search_'.$action.'_keywords')),$this->site['page']);
        $this->info['seoDescription'] = cmsSeo(str_replace('[searchText]',$this->info['searchText'],lang('cms_search_'.$action.'_description')),$this->site['page']);
        
        //分页查询参数
        $this->info['sortName']   = config('cms.sort_search');
        $this->info['sortOrder']  = 'desc';
        $this->info['pageNumber'] = $this->site['page'];
        $this->info['pageSize']   = cmsPageSize(config('cms.limit_search'));
        $this->info['pagePath']   = DcUrl('cms/search/'.$action,[
            'searchText' => $this->info['searchText'],
            'pageNumber' => '[PAGE]',
        ]);

        //查询数据
        $this->items = cmsSelect([
            'cache'   => true,
            'status'  =>'normal',
            'action'  => $action,
            'controll'=> 'detail',
            'module'  => 'cms',
            'search'  => $this->info['searchText'],
            'field'   => config('cms.field_select'),
            'simple'  => config('cms.total_search'),
            'start'   => $this->query['pageStart'],
            'sort'    => $this->info['sortName'],
            'order'   => $this->info['sortOrder'],
            'paginate'=> [
                'list_rows' => $this->info['pageSize'],
                'page'      => $this->info['pageNumber'],
                'path'      => $this->info['pagePath'],
            ]
        ]);
        //简洁分页模式（pageStart）
        if(isset($this->items['next_item']) && config('cms.page_start')){
            $this->items['page_list'] = cmsPageList(
                $this->items['next_item'][0]['info_id'],DcUrl('cms/search/'.$action,['searchText'=>$this->info['searchText'],'pageStart'=>'[PAGE]'])
            );
        }

        //变量赋值
        $this->assign($this->info);
        
        //数据列表
        $this->assign($this->items);
    
        //加载模板
        return $this->fetch();
    }
    
    //搜索请求是否合法（搜索间隔时长）
    private function searchCheck()
    {
        //后台验证开关
        $configInterval = intval(config('cms.search_interval'));
        if($configInterval < 1){
            return true;
        }
        //搜索限制白名单
        if( array_intersect(['administrator','edit'], $this->site['user']['user_capabilities']) ){
            return true;
        }
        //客户端唯一标识
        $client = md5($this->request->ip().$this->request->header('user-agent'));
        //几秒内不得再次搜索(缓存标识未过期)
        if( DcCache('search'.$client) ){
            return false;
        }
        DcCache('search'.$client, 1, $configInterval);
        //未超出限制
        return true;
    }
    
    //第三方搜索引擎列表
    private function searchList($searchText='')
    {
        if(!config('cms.search_list')){
            return false;
        }
        $list = [];
        //定义搜索列表
        foreach(explode(',',config('cms.search_list')) as $key=>$name){
            $list[$name] = DcUrl($name,['searchText' => $searchText]);
        }
        //返回结果
        return $list;
    }
}