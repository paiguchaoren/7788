<?php
namespace app\cms\controller;

use app\common\controller\Front;

class Detail extends Front
{

    public function _initialize()
    {
        //请求验证
        if( !cmsRequestCheck($this->request->ip(),$this->request->header('user-agent')) ){
            $this->error(lang('cms_error_rest'), 'cms/index/index');
        }
        // 继承上级
        parent::_initialize();
    }

    public function index()
    {
        //查询数据
        $info = $this->detail();
        //变量赋值
        $this->assign($info);
        //主分类赋值
        $this->assign(current($info['category']));
        //自定义模板
        if($info['cms_tpl']){
            return $this->fetch($info['cms_tpl']);
        }
        //按类型加载
        return $this->fetch(DcEmpty($info['info_type'],'index'));
    }
    
    //空操作
    public function _empty($action='')
    {
        //扩展开关
        if(!config('cms.action_name')){
            $this->error(lang('cms_error_params'));
        }
        //允许的操作名
        if(!in_array($action,explode(',',config('cms.action_name')))){
            $this->error(lang('cms_error_params'));
        }
        //查询数据
        $info = $this->detail();
        //变量赋值
        $this->assign($info);
        //主分类赋值
        $this->assign(current($info['category']));
        //自定义模板
        if($info['cms_tpl']){
            return $this->fetch($info['cms_tpl']);
        }
        //默认加载
        return $this->fetch();
    }
    
    //内容详情
    private function detail()
    {
        if( isset($this->query['id']) ){
            $info = cmsGetId($this->query['id']);
        }elseif( isset($this->query['slug']) ){
            $info = cmsGetSlug($this->query['slug'], true, 'normal', $this->site['action']);
        }elseif( isset($this->query['name']) ){
            $info = cmsGetName($this->query['name'], true, 'normal', $this->site['action']);
        }else{
            $this->error(lang('cms_error_params'),'cms/index/index');
        }
        //数据判断
        if(!$info){
            $this->error(lang('cms_error_empty'),'cms/index/index');
        }
        //SEO标签
        $info['seoTitle'] = cmsSeo(DcEmpty($info['info_title'],$info['info_name']));
        $info['seoKeywords'] = cmsSeo(DcEmpty($info['info_keywords'],$info['info_name']));
        $info['seoDescription'] = cmsSeo(DcEmpty($info['info_description'],cmsSubstr($info['info_excerpt'],0,100)));
        //分享链接
        if(DcBool(config('common.app_domain'))){
            $info['info_share_url'] = cmsUrlDetail($info);
        }else{
            $info['info_share_url'] = $this->site['domain'].cmsUrlDetail($info);
        }
        //增加人气值
        cmsInfoInc($info['info_id'],'info_views');
        //返回结果
        return $info;
    }
}