<?php
namespace app\cms\controller;

use app\common\controller\Front;

class Category extends Front
{
    private $items = [];
    
    public function _initialize()
    {
        //请求验证
        if( !cmsRequestCheck($this->request->ip(),$this->request->header('user-agent')) ){
            $this->error(lang('cms_error_rest'), 'cms/index/index');
        }
        parent::_initialize();
    }
    
    public function index()
    {
        //查询数据
        $term = $this->detail();
        //变量赋值
        $this->assign($term);
        //数据列表
        $this->assign($this->items);
        //自定义模板
        if($term['term_tpl']){
            return $this->fetch($term['term_tpl']);
        }
        //默认加载
        return $this->fetch();
    }
    
    //空操作
    public function _empty($action='')
    {
        //允许的操作名
        if(!in_array($action,explode(',',config('cms.action_name')))){
            $this->error(lang('cms_error_params'));
        }
        //查询数据
        $term = $this->detail();
        //变量赋值
        $this->assign($term);
        //数据列表
        $this->assign($this->items);
        //自定义模板
        if($term['term_tpl']){
            return $this->fetch($term['term_tpl']);
        }
        //默认加载
        return $this->fetch();
    }
    
    private function detail()
    {
        if( isset($this->query['id']) ){
            $term = cmsCategoryId($this->query['id']);
        }elseif( isset($this->query['slug']) ){
            $term= cmsCategorySlug($this->query['slug'],true,'normal',$this->site['action']);
        }elseif( isset($this->query['name']) ){
            $term = cmsCategoryName($this->query['name'],true,'normal',$this->site['action']);
        }else{
            $this->error(lang('cms_error_params'),'cms/index/index');
        }
        //数据为空
        if(!$term){
            $this->error(lang('cms_error_empty'),'cms/index/index');
        }
        //分页路径
        $term['pagePath']       = cmsUrlCategory($term,'[PAGE]');
        //地址栏
        $term['pageSize']       = intval(config('cms.limit_category'));
        $term['pageNumber']     = $this->site['page'];
        $term['sortName']       = config('cms.sort_type');
        $term['sortOrder']      = 'desc';
        //子分类
        $term['term_ids']       = DcTermSubIds($term['term_id'],'category','array');
        //SEO标签
        $term['seoTitle']       = cmsSeo(DcEmpty($term['term_title'],$term['term_name']),$this->site['page']);
        $term['seoKeywords']    = cmsSeo(DcEmpty($term['term_keywords'],$term['term_name']),$this->site['page']);
        $term['seoDescription'] = cmsSeo(DcEmpty($term['term_description'],$term['term_name']),$this->site['page']);
        //自定义分页
        if(is_numeric($term['term_limit'])){
            $term['pageSize'] = $term['term_limit'];
        }
        //数据列表
        if($term['pageSize']){
            $this->items = cmsSelect([
                'cache'   => true,
                'term_id' => $term['term_id'],
                'start'   => $this->query['pageStart'],
                'status'  => 'normal',
                'action'  => $this->site['action'],
                'controll'=> 'detail',
                'module'  => 'cms',
                'field'   => config('cms.field_select'),
                'simple'  => config('cms.total_type'),
                'sort'    => $term['sortName'],
                'order'   => $term['sortOrder'],
                'paginate'=> [
                    'list_rows' => $term['pageSize'],
                    'page'      => $term['pageNumber'],
                    'path'      => $term['pagePath'],
                ]
            ]);
            //简洁分页模式（pageStart）
            if(isset($this->items['next_item']) && config('cms.page_start')){
                $this->items['page_list'] = cmsPageList($this->items['next_item'][0]['info_id'],$term['pagePath']);
            }
        }
        //返回结果
        return $term;
    }
}