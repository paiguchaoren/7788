<?php
namespace app\cms\controller;

use app\common\controller\Front;

class Categorys extends Front
{

    public function _initialize()
    {
        parent::_initialize();
    }
    
    public function index()
    {
        return $this->detail();
    }
    
    public function _empty($action='')
    {
        //允许的操作名
        if(!in_array($action,explode(',',config('cms.action_name')))){
            $this->error(lang('cms_error_params'));
        }
        //默认加载
        return $this->detail($action);
    }
    
    private function detail($action='index')
    {
        //变量赋值
        $this->assign([
            'seoTitle'       => cmsSeo(lang('cms_categorys_'.$action.'_title')),
            'seoKeywords'    => cmsSeo(lang('cms_categorys_'.$action.'_keywords')),
            'seoDescription' => cmsSeo(lang('cms_categorys_'.$action.'_description')),
        ]);
        //加载模板
        return $this->fetch();
    }
}