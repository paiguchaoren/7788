<?php
namespace app\cms\controller;

use app\common\controller\Front;

class Index extends Front
{
    private $info = [];
    
    private $items = [];
    
    public function _initialize()
    {
        parent::_initialize();
    }
    
    public function index()
    {
        $this->info['seoTitle']       = cmsSeo(config('cms.index_title'),$this->site['page']);
        $this->info['seoKeywords']    = cmsSeo(config('cms.index_keywords'),$this->site['page']);
        $this->info['seoDescription'] = cmsSeo(config('cms.index_description'),$this->site['page']);
        //公共操作
        $this->common('index');
        //变量赋值
        $this->assign($this->info);
        //分页列表
        $this->assign($this->items);
        //加载模板
        return $this->fetch();
    }
    
    //空操作
    public function _empty($action='')
    {
        //允许的操作名
        if(!in_array($action,explode(',',config('cms.action_name')))){
            $this->error(lang('cms_error_params'));
        }
        //加载内容模块独立配置
        cmsConfigAction($action);
        //TKD
        $this->info['seoTitle']       = cmsSeo(lang('cms_index_'.$action.'_title'),$this->site['page']);
        $this->info['seoKeywords']    = cmsSeo(lang('cms_index_'.$action.'_keywords'),$this->site['page']);
        $this->info['seoDescription'] = cmsSeo(lang('cms_index_'.$action.'_description'),$this->site['page']);
        //公共操作
        $this->common($action);
        //变量赋值
        $this->assign($this->info);
        //分页列表
        $this->assign($this->items);
        //加载模板
        return $this->fetch();
    }
    
    //公共操作
    private function common($action='index')
    {
        //公共参数
        $this->info['pageNumber']     = $this->site['page'];
        $this->info['pagePath']       = DcUrl('cms/index/'.$action,['pageNumber'=>'[PAGE]']);
        $this->info['pageSize']       = intval(config('cms.limit_index'));
        //分页查询
        if(!$this->info['pageSize']){
            return false;
        }
        $this->items = cmsSelect([
            'cache'    => true,
            'status'   => 'normal',
            'action'   => $action,
            'controll' => 'detail',
            'module'   => 'cms',
            'field'    => config('cms.field_select'),
            'simple'   => config('cms.total_index'),
            'start'    => $this->query['pageStart'],
            'sort'     => config('cms.sort_index'),
            'order'    => 'desc',
            'paginate' => [
                'list_rows' => $this->info['pageSize'],
                'page'      => $this->info['pageNumber'],
                'path'      => $this->info['pagePath'],
            ]
        ]);
        //简洁分页模式（pageStart）
        if(isset($this->items['next_item']) && config('cms.page_start')){
            $this->items['page_list'] = cmsPageList($this->items['next_item'][0]['info_id'],DcUrl('cms/index/'.$action,['pageStart'=>'[PAGE]']));
        }
        return true;
    }
}