<?php
namespace app\cms\controller;

use app\common\controller\Front;

class Sitemap extends Front
{
    private $limit = 10;
    
    private $pages = [];
    
    public function _initialize()
    {
        //请求验证
        if( !cmsRequestCheck($this->request->ip(),$this->request->header('user-agent')) ){
            $this->error(lang('cms_error_rest'), 'cms/index/index');
        }
        //继承上级
        parent::_initialize();
        //每页数量
        $this->limit = DcEmpty(config('cms.limit_sitemap'), 100);
    }
    
    //最新N条
    public function last()
    {
        $args = [];
        $args['cache']    = true;
        $args['status']   = 'normal';
        $args['action']   = 'index';
        $args['controll'] = 'detail';
        $args['module']   = 'cms';
        $args['field']    = 'info_id,info_slug,info_name,info_action';
        $args['with']     = 'term';
        $args['limit']    = $this->limit;
        $args['page']     = false;
        $args['sort']     = 'info_id';
        $args['order']    = 'desc';
        $args['fetchSql'] = false;
        $this->text(cmsSelect($args));
    }
    
    //limit偏移分页
    public function index()
    {
        $args = [];
        $args['cache']    = true;
        $args['status']   = 'normal';
        $args['action']   = 'index';
        $args['controll'] = 'detail';
        $args['module']   = 'cms';
        $args['field']    = 'info_id,info_slug,info_name,info_action';
        $args['with']     = 'term';
        $args['limit']    = false;
        $args['page']     = $this->site['page'].','.$this->limit;
        $args['sort']     = 'info_id';
        $args['order']    = 'asc';
        //$args['sort']   = false;
        //$args['order']  = false;
        $args['fetchSql'] = false;
        if(config('cms.sitemap_max')){
            $args['id']   = ['elt',config('cms.sitemap_max')];
        }
        $this->text(cmsSelect($args));
    }
    
    //limit分页列表
    public function indexs()
    {
        $args = [
            'info_module'   => 'cms',
            'info_controll' => 'detail',
            'info_action'   => 'index',
            'info_status'   => 'normal',
        ];
        if(config('cms.sitemap_max')){
            $args['info_id'] = ['elt',config('cms.sitemap_max')];
        }
        $count = db('info')->where($args)->count();
        if($lastPage = ceil($count/$this->limit)){
            if(input('result/s')=='txt'){
                for($i=1;$i<=$lastPage;$i++){
                    echo $this->request->root(true).DcUrl('cms/sitemap/index',['pageNumber'=>$i])."\n";
                }
            }else{
                for($i=1;$i<=$lastPage;$i++){
                    echo('<a href="'.DcUrl('cms/sitemap/index',['pageNumber'=>$i]).'">'.$i.'</a> ');
                }
            }
        }
    }
    
    //startId分页列表
    public function start()
    {
        if(!config('cms.sitemap_max')){
            exit();
        }
        $args = [];
        $args['cache']    = true;
        $args['status']   = 'normal';
        $args['action']   = 'index';
        $args['controll'] = 'detail';
        $args['module']   = 'cms';
        $args['field']    = 'info_id,info_slug,info_name,info_action';
        $args['with']     = 'term';
        $args['start']    = $this->query['pageStart'];
        $args['limit']    = $this->limit;
        $args['page']     = false;
        $args['sort']     = 'info_id';
        $args['order']    = 'asc';
        $args['fetchSql'] = false;
        config('cms.page_start',true);
        $this->text(cmsSelect($args));
    }
    
    //sitemap列表
    public function starts()
    {
        if(!config('cms.sitemap_max')){
            exit();
        }
        $ids = $this->startIds(['info_module'=>'cms','info_controll'=>'detail','info_action'=>'index','info_status'=>'normal'],$this->limit);
        if(input('result/s')=='txt'){
            foreach($ids as $key=>$value)
            {
                echo $this->request->root(true).DcUrl('cms/sitemap/start',['pageStart'=>$value])."\n";
            }
        }else{
            foreach($ids as $key=>$value)
            {
                echo('<a href="'.DcUrl('cms/sitemap/start',['pageStart'=>$value]).'">'.($key+1).'</a> ');
            }
        }
    }
    
    private function startIds($where=[], $limit=100, $field='info_id', $order='asc')
    {
        $result = db('info')->cache(true)->field('info_id')->where($where)->chunk($limit,function($datas){
            array_push($this->pages,current(min($datas)));
        }, $field, $order);
        
        return $this->pages;
    }
    
    private function text($list=[])
    {
        $result = [];
        foreach($list as $key=>$value){
            array_push($result,$this->request->root(true).cmsUrlDetail([
                'info_id'       => $value['info_id'],
                'info_slug'     => $value['info_slug'],
                'info_name'     => $value['info_name'],
                'info_action'   => $value['info_action'],
                'category_id'   => $value['category_id'],
                'category_slug' => $value['category_slug'],
                'category_name' => $value['category_name'],
            ]));
        }
        unset($list);
        header('Content-Type: text/plain');
        echo implode("\n",$result);
    }
}