<?php
namespace app\cms\controller;

use app\common\controller\Front;

class Tags extends Front
{
    private $info = [];
    
    private $items = [];
    
    public function _initialize()
    {
        parent::_initialize();
    }
    
    public function index()
    {
        return $this->common('index');
    }
    
    public function _empty($action='')
    {
        //允许的操作名
        if(!in_array($action,explode(',',config('cms.action_name')))){
            $this->error(lang('cms_error_params'));
        }
        //内容模块独立配置
        cmsConfigAction($action);
        //默认加载
        return $this->common($action);
    }
    
    private function common($action='index')
    {
        $this->info['seoTitle']       = cmsSeo(lang('cms_tags_'.$action.'_title'),$this->site['page']);
        $this->info['seoKeywords']    = cmsSeo(lang('cms_tags_'.$action.'_keywords'),$this->site['page']);
        $this->info['seoDescription'] = cmsSeo(lang('cms_tags_'.$action.'_description'),$this->site['page']);
        $this->info['pagePath']       = DcUrl('cms/tags/'.$action,['pageNumber'=>'[PAGE]']);
        $this->info['pageNumber']     = $this->site['page'];
        $this->info['pageSize']       = cmsPageSize(config('cms.limit_tags'));
        $this->info['sortName']       = 'term_order desc,term_count';
        $this->info['sortOrder']      = 'desc';
        //分页列表
        $this->item = cmsTagSelect([
            'cache'   => true,
            'status'  => 'normal',
            'action'  => $action,
            'sort'    => $this->info['sortName'],
            'order'   => $this->info['sortOrder'],
            'limit'   => $this->info['pageSize'],
            'page'    => $this->site['page'],
        ]);
        //变量赋值
        $this->assign($this->info);
        //分页赋值
        $this->assign($this->item);
        //加载模板
        return $this->fetch();
    }
}