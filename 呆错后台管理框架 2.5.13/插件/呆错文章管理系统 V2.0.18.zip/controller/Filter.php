<?php
namespace app\cms\controller;

use app\common\controller\Front;

class Filter extends Front
{
    private $items = [];
    
    private $info  = [];
    
    //继承上级
    public function _initialize()
    {
        //请求验证
        if( !cmsRequestCheck($this->request->ip(),$this->request->header('user-agent')) ){
            $this->error(lang('cms_error_rest'), 'cms/index/index');
        }
        //请求过滤
        $this->request->filter('trim,strip_tags,htmlspecialchars');
        //继承上级
        parent::_initialize();
    }
    
    //按条件筛选页
    public function index()
    {
        return $this->common('index');
    }

    //空操作
    public function _empty($action='')
    {
        //允许的操作名
        if(!in_array($action,explode(',',config('cms.action_name')))){
            $this->error(lang('cms_error_params'));
        }
        //内容模块独立配置
        cmsConfigAction($action);
        //查询数据
        return $this->common($action);
    }
    
    //公共操作
    private function common($action='index')
    {
        //过滤URL空值
        $this->query = DcArrayEmpty($this->query);
        //扩展字段列表
        $fieldsMeta  = DcArrayFilter($this->query, cmsMetaKeys('detail', $action));
        //筛选初始参数
        $this->info['term_id']    = intval($this->query['term_id']);
        $this->info['info_type']  = $this->cmsType($this->query['info_type']);
        $this->info['sortName']   = $this->sortName($this->query['sortName'], config('cms.sort_filter'));
        $this->info['sortOrder']  = $this->sortOrder($this->query['sortOrder'], 'desc');
        //定义筛选初始变量
        $this->info['pageFilter'] = DcArrayEmpty(DcArrayArgs($fieldsMeta,$this->info));
        //定义分页PATH变量
        $this->info['pageNumber'] = $this->site['page'];
        $this->info['pagePath']   = DcUrl('cms/filter/'.$action,array_merge($this->info['pageFilter'],['pageNumber'=>'[PAGE]']));
        $this->info['pageSize']   = cmsPageSize(DcEmpty($this->query['pageSize'],config('cms.limit_filter')));
        //定义重置条件变量
        $this->info['pageReset']  = DcUrl('cms/filter/'.$action,[
            'sortName'   => 'info_id',
            'sortOrder'  => 'desc',
        ]);
        //定义页码列表
        $this->info['pageSizes'] = [
            '10'  => 10,
            '20'  => 20,
            '30'  => 30,
            '50'  => 50,
            '100' => 100,
        ];
        //定义排序字段
        $this->info['sortNames'] = [
            'info_id'          => 'ID',
            'info_views'       => lang('cms_views'),
            'info_update_time' => lang('cms_update_time'),
            'info_order'       => lang('cms_order'),
            'cms_up'           => lang('cms_up'),
        ];
        //定义排序方式
        $this->info['sortOrders'] = [
            'desc' => lang('cms_order_desc'),
            'asc'  => lang('cms_order_asc'),
        ];
        //定义类型列表
        $this->info['types'] = cmsTypeOption();
        //定义分类列表
        $terms = cmsCategorySelect([
            'cache'    => true,
            'status'   => 'normal',
            'result'   => 'array',
            'field'    => 'term_id,term_slug,term_name,term_action',
            'with'     => false,
            'limit'    => 0,
            'page'     => 0,
            'sort'     => 'term_count',
            'order'    => 'desc',
            'action'   => $action,
        ]);
        foreach($terms as $key=>$value){
            $this->info['termIds'][$value['term_id']] = $value['term_name'];
            $this->info['termSlugs'][$value['term_slug']] = $value['term_name'];
        }
        unset($terms);
        //地址栏参数
        $this->info['query'] = $this->query;
        
        //分页查询条件
        $args = [];
        $args['cache']      = true;
        $args['status']     = 'normal';
        $args['action']     = $action;
        $args['controll']   = 'detail';
        $args['module']     = 'cms';
        $args['with']       = 'info_meta,term';
        $args['field']      = config('cms.field_select');
        $args['simple']     = config('cms.total_filter');
        $args['start']      = $this->query['pageStart'];
        $args['sort']       = $this->info['sortName'];
        $args['order']      = $this->info['sortOrder'];
        $args['paginate']   = [
            'list_rows' => $this->info['pageSize'],
            'page'      => $this->info['pageNumber'],
            'path'      => $this->info['pagePath'],
        ];
        //按META字段条件筛选
        $args['meta_query'] = cmsMetaQuery($this->query);
        //按META字段排序
        if( !in_array($args['sort'], model('common/Attr','loglic')->infoSort()) ){
            $args['meta_key'] = $args['sort'];
            $args['sort']     = 'meta_value_num';
        }
        //文章内型限制
        if($this->info['info_type']){
            $args['type'] = ['eq',$this->info['info_type']];
        }
        //分类ID限制
        if($this->info['term_id']){
            $args['term_id'] = ['eq',intval($this->info['term_id'])];
        }
        //数据查询
        $this->items = cmsSelect($args);
        //简洁分页模式（pageStart）
        if(isset($this->items['next_item']) && config('cms.page_start')){
            $this->items['page_list'] = cmsPageList(
                $this->items['next_item'][0]['info_id'], DcUrl('cms/filter/'.$action, array_merge($this->info['pageFilter'],['pageStart'=>'[PAGE]']))
            );
        }
        //变量赋值
        $this->assign($this->info);
        //数据列表
        $this->assign($this->items);
        //默认加载
        return $this->fetch();
    }
    
    //文章形式
    private function cmsType($infoType='')
    {
        if( in_array($infoType,array_keys(cmsTypeOption())) ){
            return $infoType;
        }
        return '';
    }
    
    //排序字段
    private function sortName($sortName='',$sortDefault='info_update_time')
    {
        if( in_array($sortName,['cms_up','cms_down','info_id','info_order','info_views','info_hits','info_create_time','info_update_time']) ){
            return $sortName;
        }
        return $sortDefault;
    }
    
    //排序方式
    private function sortOrder($sortOrder='',$sortDefault='desc')
    {
        if( in_array($sortOrder,['desc','asc']) ){
            return $sortOrder;
        }
        return $sortDefault;
    }
}