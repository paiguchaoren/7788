<?php
namespace app\cms\event;

use app\common\controller\Addon;

class Config extends Addon
{
	public function _initialize()
    {
		parent::_initialize();
	}

	public function index()
    {
        $this->assign('items', model('cms/Config','loglic')->fields($this->query));
        
        $this->assign('query', $this->query);
        
        return $this->fetch('cms@config/index');
	}
    
    public function write()
    {
		if( !\daicuo\Op::write(input('post.'), 'cms', 'config', 'system', 0, 'yes') ){
		    $this->error(lang('fail'));
        }
        $this->success(lang('success'));
	}
    
    public function create()
    {
        $this->assign('items', model('cms/Config','loglic')->fieldsAction($this->query));
        
        $this->assign('query', $this->query);
        
        return $this->fetch('cms@config/create');
	}
    
    public function save()
    {
        //接收数据
        $post = input('post.');
        //操作名
        $action = DcEmpty($post['op_action'],'index');
        unset($post['op_action']);
        //保存配置
		if(!\daicuo\Op::write($post, 'cms', 'config', $action, 0, 'no')){
		    $this->error(lang('fail'));
        }
        $this->success(lang('success'));
	}
}