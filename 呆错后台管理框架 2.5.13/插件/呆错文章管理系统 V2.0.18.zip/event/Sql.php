<?php
namespace app\cms\event;

class Sql
{
    /**
    * 安装时触发
    * @return bool 只有返回true时才会往下执行
    */
	public function install()
    {
        //初始配置
        model('cms/Install','loglic')->config();
        
        //初始语言
        model('cms/Install','loglic')->lang();
        
        //初始字段
        model('cms/Install','loglic')->field();
        
        //初始路由
        model('cms/Install','loglic')->route();
        
        //初始权限
        model('cms/Install','loglic')->auth();
        
        //采集规则
        model('cms/Install','loglic')->collect();
        
        //后台菜单
        model('cms/Install','loglic')->menu();
        
        //前台菜单
        model('cms/Install','loglic')->navs();
        
        //初始分类
        model('cms/Install','loglic')->category();
        
        //初始标签
        model('cms/Install','loglic')->tag();
        
        //清空缓存
        \think\Cache::clear();
        
        //返回结果
        return true;
	}
    
    /**
    * 升级时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function upgrade()
    {
        //升级框架脚本
        model('cms/Upgrade','loglic')->frame();
        
        //更新基础信息
        model('cms/Upgrade','loglic')->status();

        //更新打包配置
        model('cms/Upgrade','loglic')->pack();
        
        //清空缓存
        \think\Cache::clear();

        return true;
    }
    
    /**
    * 卸载时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function remove()
    {
        model('cms/Remove','loglic')->init();
        
        return true;
    }
    
    /**
    * 删除时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function unInstall()
    {
        model('cms/Delete','loglic')->init();
        return true;
	}
}