<?php
namespace app\tuchuang\controller;

use app\common\controller\Front;

class User extends Front
{
    protected $auth = [
         'check'       => true,
         'none_login'  => '',
         'none_right'  => '*',
         'error_login' => 'user/login/index',
         'error_right' => '',
    ];
    
	public function _initialize()
    {
        if(!function_exists('attachmentSave')){
            $this->error('请先安装呆错附件管理插件');
        }
		parent::_initialize();
	}
    
	public function index()
    {
        //查询数据
        $list = attachmentSelect([
            'limit'     => 20,
            'page'      => $this->site['page'],
            'sort'      => 'info_id',
            'order'     => 'desc',
            'with'      => false,
            'field'     => 'info_name,info_slug,info_type,info_excerpt',
            'user_id'   => $this->site['user']['user_id'],
            'mime_type' => ['in',config('tuchuang.mime_type')]
        ]);
        $this->assign($list);
        //分享前缀
        if(config('common.upload_cdn')){
            $this->assign('imgCdn', config('common.upload_cdn'));
        }else{
            $this->assign('imgCdn', $this->request->root(true));
        }
        //翻页
        $this->assign('pagePath', DcUrl('tuchuang/user/index',['pageNumber'=>'[PAGE]']));
        //记忆回跳
        redirect('tuchuang/user')->remember();
        //加载模板
		return $this->fetch();
	}
    
    public function delete()
    {
        $infoId = input('get.id/d',0);
        $info = attachmentGet([
            'cache'   => false,
            'field'   => 'info_user_id',
            'with'    => false,
            'user_id' => $this->site['user']['user_id'],
            'id'      => ['eq',$infoId],
        ]);
        if($info){
            attachmentDelete($infoId);
        }
        return redirect()->restore();
    }
}