<?php
/*
** 插件基础信息
*/
return [
    //插件唯一标识
    'module'   => 'tuchuang',
    //插件名称
    'name'     => '呆错图床',
    //插件描述
    'info'     => '呆错图床系统是一款免费的PHP图床程序，核心功能是提供图片外链服务、图床API服务、图片CDN加速与破解防盗链。',
    //插件版本
    'version'  => '1.6.1',
    //依赖数据库
    'datatype' => ['sqlite', 'mysql'],
    //依赖插件版本
    'rely'     => [
        'daicuo' => '2.0.15',
    ],
];