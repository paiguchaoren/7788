<?php
/**
 * DES加密
 */
function imgDesEncode($str){
    $key = DcEmpty(config('common.site_secret'), 'DaiCuoTuChuang');
    //加密参数
    $array = [];
    $array['url']  = $str;
    $array['time'] = time();
    //加密结果
    return openssl_encrypt(http_build_query($array), 'DES-ECB', $key, 0);
}
/**
 * DES解密
 */
function imgDesDecode($str){
    
    $str = str_replace(['%20',' '], '+', $str);
    
    $key = DcEmpty(config('common.site_secret'), 'DaiCuoTuChuang');
    //还原加密参数
    parse_str( openssl_decrypt($str, 'DES-ECB', $key, 0), $array);
    //是否设置有效期
    $expire = intval(config('tuchuang.des_length'));
    if($expire){
        if( (time() - $array['time']) > $expire){
            return false;//已超时
        }
    }
    //返回原始地址
    return $array['url'];
}

/**
 * 获取文件的mimetype类型
 * @version 1.3.0 首次引入
 * @param string $fileName 必需;文件完整路径;默认：空
 * @return string 类型
 */
function imgMimeType($fileName=''){
    $finfo    = finfo_open(FILEINFO_MIME_TYPE);
    $mimetype = finfo_file($finfo, $fileName);
    finfo_close($finfo);
    return $mimetype;
}

/**
 * 将文件信息保存至数据库
 * @version 1.4.1 首次引入
 * @param int $userId 必需;文件完整路径;默认：空
 * @param string $infoSlug 必需;md5值;默认：空
 * @param string $mimeType 必需;文件类型;默认：空
 * @param string $fileSize 必需;文件大小;默认：空
 * @param string $oldName 必需;原文件名;默认：空
 * @return int 自增ID
 */
function imgInfoInsert($userId='', $infoSlug='', $mimeType='image/png', $fileSize=0, $oldName='')
{
    if(!function_exists('attachmentSave')){
        return 0;
    }
    $data = [];
    $data['info_parent']      = 0;//内容ID
    $data['info_name']        = $infoSlug;//保存文件名
    $data['info_slug']        = DcEmpty($infoSlug,uniqid());//sha1/md5
    $data['info_excerpt']     = substr($infoSlug,0,4).'/'.$infoSlug;//保存路径
    $data['info_type']        = imgMimeToExt($mimeType);//后缀
    $data['info_order']       = intval($fileSize);//文件大小字节
    $data['info_mime_type']   = $mimeType;//文件类型
    $data['info_user_id']     = intval($userId);//所属用户
    $data['info_title']       = $oldName;//原始文件名
    $data['attachment_score'] = 0;//附件积分
    return attachmentSave($data);
}

/**
 * 图片的contentType转后缀
 * @version 1.4.1 首次引入
 * @param string $mimeType 必需;mimetype类型;默认：image/png
 * @return string 后缀名
 */
function imgMimeToExt($mimeType='image/png')
{
    $result = [
        'image/png'         => '.png',
        'image/jpeg'        => '.jpeg',
        'image/jpg'         => '.jpg',
        'image/pjepg'       => '.jfif',
        'image/gif'         => '.gif',
        'image/x-png'       => '.png',
        'image/x-icon'      => '.ico',
        'image/webp'        => '.webp',
        'application/x-bmp' => '.bmp',
        'text/xml'          => '.svg',
        'text/plain'        => '.svg',
    ];
    return DcEmpty($result[$mimeType],'.png');
}