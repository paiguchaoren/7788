<?php
return [
    'admin_caps_front' => [
        'app\\tuchuang\\behavior\\Hook',
    ],
];