<?php
return [
    'tuchuang' => [
        'theme'     => 'default',
        'theme_wap' => 'default',
        'mime_type' => [
            'image/png',
            'image/jpeg',
            'image/jpg',
            'image/pjepg',
            'image/gif',
            'image/x-png',
            'image/x-icon',
            'image/webp',
            'application/x-bmp',
            'text/xml',
            'text/plain',
        ],
    ]
];