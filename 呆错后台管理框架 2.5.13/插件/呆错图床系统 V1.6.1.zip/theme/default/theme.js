var uploadSuccess = function(uploader, file, responseObject){
    $('#alert').removeClass('d-none');
    $('#alert #shareUrl').html(file.responseTp.data.url);
    //$('#group-upload').remove();
}
var uploadFail = function(uploader, data){
    daicuo.bootstrap.dialog(data.msg);
}
var uploadComplete = function(uploader, files){
    return false;
}
var imageChange = function($json, $status, $xhr, $callBack){
    if($json.code == 1){
        $('#alert').removeClass('d-none');
        $('#alert #shareUrl').html($json.data.url);
    }else{
        daicuo.bootstrap.dialog($json.msg);
    }
}
window.daicuo.tuchuang = {
    init: function(){
        this.json();
        this.copy();
        this.preview();
    },
    json: function(){
        if($('#json').length){
            $('#json').html(JSON.stringify(JSON.parse($('#json').text()), null, 4));
        }
    },
    copy: function(){
        if(!$('.btn-copy').length){
            return false;
        }
        $.getScript("https://lib.baomitu.com/clipboard.js/2.0.1/clipboard.min.js", function(){
            var clipboard = new ClipboardJS(".btn-copy",{
                text: function(trigger){
                    var target = $(trigger).data('target');
                    return $(target).text();
                }
            });
            clipboard.on("success",function(e){
                e.clearSelection();
                daicuo.bootstrap.dialog('复制成功');
                setTimeout('$(".dc-modal").modal("hide");', 1000);
                //clipboard.destroy();
            });
            clipboard.on("error",function(e){
                daicuo.bootstrap.dialog('复制失败');
            });
        });
    },
    preview: function(){
        $(document).on("click", '.btn-preview', function() {
            var target = $(this).data('target');
            daicuo.bootstrap.preview('<img class="img-fluid w-100" src="'+$(target).attr('src')+'" alt="'+$(target).attr('alt')+'"/>');
        });
    }
}
$(document).ready(function () {
    window.daicuo.ajax.init();
    window.daicuo.form.init();
    window.daicuo.upload.init();
    window.daicuo.tuchuang.init();
});