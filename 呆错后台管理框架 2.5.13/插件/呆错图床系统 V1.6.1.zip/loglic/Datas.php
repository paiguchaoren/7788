<?php
namespace app\tuchuang\loglic;

class Datas
{
    //配置
    public function insertConfig()
    {
        config('common.validate_name', false);
        
        return model('common/Config','loglic')->install([
            'site_name'       => '呆错免费图床',
            'site_title'      => '呆错图床系统',
            'site_keywords'   => '免费图床程序,专业图片外链,免费图床API',
            'site_description'=> '呆错图床系统是一款免费的PHP图床程序，核心功能是提供图片外链服务、图床API服务、图片CDN加速与破解防盗链。',
            'theme'           => 'default',
            'theme_wap'       => 'default',
            'link_default'    => 'https://cdn.daicuo.cc/images/gzh/dc_01.jpg',
            'link_encode'     => 'imgDesEncode',
            'link_decode'     => 'imgDesDecode',
            'des_length'      => 86400,
            'cache_time'      => 0,
            'parse_action'    => 'daicuo',
        ],'tuchuang');
    }
    
    //伪静态
    public function insertRoute()
    {
        config('common.validate_name', false);
        
        return model('common/Route','loglic')->install([
            [
                'rule'    => 'tuchuang$',
                'address' => 'tuchuang/index/index',
                'method'  => 'get',
            ]
        ],'tuchuang');
    }
    
    //权限
    public function insertAuth()
    {
        //取消验证
        config('common.validate_name', false);
        
        //权限节点
        $caps = [
            'tuchuang/apis/change',
            'tuchuang/apis/parse',
            'tuchuang/apis/upload',
        ];
        
        //默认数据
        $default = [
            'op_name'       => 'vip',
            'op_module'     => 'tuchuang',
            'op_controll'   => 'auth',
            'op_action'     => 'front',
        ];
        
        //批量添加数据
        $dataList = [];
        foreach($caps as $key=>$value){
            array_push($dataList, DcArrayArgs(['op_value'=>$value],$default));
        }

        //调用接口
        return model('common/Auth','loglic')->install($dataList);
    }
    
    //后台菜单
    public function insertMenu()
    {
        return model('common/Menu','loglic')->install([
            [
                'term_name'   => '图床设置',
                'term_slug'   => 'tuchuang/admin/index?parent=config',
                'term_info'   => 'fa-image',
                'term_module' => 'tuchuang',
            ],
        ],'设置');
    }
    
    //前台导航
    public function insertNavs()
    {
        return model('common/Navs','loglic')->install([
            //导航栏
            [
                'navs_name'       => '图床首页',
                'navs_url'        => 'tuchuang/index/index',
                'navs_status'     => 'normal',
                'navs_type'       => 'navbar',
                'navs_module'     => 'common',
                'navs_active'     => 'tuchuangindex',
                'navs_target'     => '_self',
                'navs_order'      => 9,
            ],
            [
                'navs_name'       => '图床文档',
                'navs_url'        => 'https://www.daicuo.org/product/tuchuang/help',
                'navs_status'     => 'normal',
                'navs_type'       => 'navbar',
                'navs_module'     => 'tuchuang',
                'navs_active'     => 'tuchuanghelp',
                'navs_target'     => '_blank',
                'navs_order'      => 8,
            ],
            //侧边栏
            [
                'navs_type'       => 'sitebar',
                'navs_name'       => '我的图片',
                'navs_info'       => '我的图床',
                'navs_url'        => 'tuchuang/user/index',
                'navs_status'     => 'private',
                'navs_active'     => 'tuchuanguserindex',
                'navs_target'     => '_self',
                'navs_order'      => 9,
                'navs_parent'     => 0,
                'navs_module'     => 'tuchuang',
            ],
        ]);
    }
    
    //分类
    public function insertCategory()
    {
        return true;
    }
    
    //字段
    public function insertField()
    {
        return true;
    }
    
    //删除基础配置
    public function remove()
    {
        //应用配置（路由、配置、权限、字段、采集规则）
        model('common/Config','loglic')->unInstall('tuchuang');
        //后台菜单
        model('common/Menu','loglic')->unInstall('tuchuang');
        //前台导航
        model('common/Navs','loglic')->unInstall('tuchuang');
        //返回结果
        return true;
    }
    
    //删除数据内容
    public function delete()
    {
        return true;
    }
    
    //更新应用状态
    public function updateStatus()
    {
        \daicuo\Apply::updateStatus('tuchuang', 'enable');
        
        return true;
    }
    
    //更新应用打包信息
    public function updatePack()
    {
        if(config('common.apply_module') == 'tuchuang'){
            \daicuo\Op::write([
                'apply_name'    => '呆错图床系统',
                'apply_module'  => 'tuchuang',
                'apply_version' => '1.5.10',
                'apply_rely'    => '',
            ], 'common', 'config', 'system', 0, 'yes');
        }
        
        return true;
    }
    
    //更新应用配置
    public function updateConfig()
    {
        return true;
    }
    
    //更新应用分类
    public function updateCategory()
    {
        return true;
    }
    
    //更新应用菜单
    public function updateNavs()
    {
        return true;
    }
}