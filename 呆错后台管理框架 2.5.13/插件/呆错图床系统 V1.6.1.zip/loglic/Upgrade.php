<?php
namespace app\daohang\loglic;

use app\common\loglic\Update;

class Upgrade extends Update
{
    //在线升级回调
    public function init()
    {
        return true;
    }
}