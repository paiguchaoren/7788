<?php
namespace app\tuchuang\loglic;

class Install
{
    //一键安装回调
    public function mysql()
    {
        \daicuo\Apply::install('user','install');
        
        \daicuo\Apply::install('attachment','install');
        
        \daicuo\Apply::install('tuchuang','install');
        
        model('tuchuang/Datas','loglic')->updatePack();
        
        $this->rewriteIndex();
        
        return true;
    }
    
    //设置首页路由
    private function rewriteIndex()
    {
        //公共
        \daicuo\Op::write([
            'site_name'  => '呆错图床系统',
            'url_suffix' => '.html',
        ], 'common', 'config', 'system', 0, 'yes');
        //配置
        \daicuo\Op::write([
            'rewrite_index' => '/',
        ], 'tuchuang', 'config', 'system', 0, 'yes');
        //删除
        db('op')->where([
            'op_name'  => 'site_route',
            'op_value' => ['like','a:5:{s:4:"rule";s:9:"tuchuang$"%'],
        ])->delete();
        //首页
        return model('common/Route','loglic')->index('tuchuang/index/index', 'tuchuang');
    }
}