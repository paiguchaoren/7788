<?php
namespace app\tuchuang\behavior;

use think\Controller;

class Hook extends Controller
{
    //前台权限扩展
    public function adminCapsFront(&$caps)
    {
        $caps = array_merge($caps,[
            'tuchuang/apis/upload',
            'tuchuang/apis/change',
            'tuchuang/apis/parse',
        ]);
    }
}