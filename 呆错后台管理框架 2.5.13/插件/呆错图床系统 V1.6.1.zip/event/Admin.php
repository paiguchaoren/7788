<?php
namespace app\tuchuang\event;

use think\Controller;

class Admin extends Controller
{
	
	public function _initialize()
    {
		parent::_initialize();
	}

	public function index()
    {
        $themes = array();
        foreach( glob_basename('apps/tuchuang/theme/') as $value){
            $themes[$value] = $value;
        }
        $items = [
            'theme' => [
                'type'        => 'select',
                'value'       => config('tuchuang.theme'),
                'option'      => $themes,
            ],
            'theme_wap' => [
                'type'        => 'select',
                'value'       => config('tuchuang.theme_wap'),
                'option'      => $themes,
            ],
            'site_name' => [
                'type'        => 'text',
                'value'       => config('tuchuang.site_name'),
                'title'       => lang('tc_site_name'),
                'placeholder' => lang('tc_site_name_tips'),
            ],
            'site_title' => [
                'type'        => 'text',
                'value'       => config('tuchuang.site_title'),
                'title'       => lang('tc_site_title'),
                'placeholder' => lang('tc_site_title_tips'),
            ],
            'site_keywords' => [
                'type'        => 'text',
                'value'       => config('tuchuang.site_keywords'),
                'title'       => lang('tc_site_keywords'),
                'placeholder' => lang('tc_site_keywords_tips'),
            ],
            'site_description' => [
                'type'        => 'text',
                'value'       => config('tuchuang.site_description'),
                'title'       => lang('tc_site_description'),
                'placeholder' => lang('tc_site_description_tips'),
            ],
            'link_default' => [
                'type'        => 'text',
                'value'       => config('tuchuang.link_default'),
                'title'       => lang('tc_link_default'),
                'placeholder' => lang('tc_link_default_tips'),
            ],
            'cache_time' => [
                'type'        => 'text',
                'value'       => config('tuchuang.cache_time'),
                'title'       => lang('tc_cache_time'),
                'placeholder' => lang('tc_cache_time_tips'),
            ],
            'parse_action' => [
                'type'        => 'text',
                'value'       => config('tuchuang.parse_action'),
                'title'       => lang('tc_parse_action'),
                'placeholder' => lang('tc_parse_action_tips'),
            ],
            'html_1' => [
                'type'        => 'html',
                'value'       => '<hr>',
            ],
            'link_encode' => [
                'type'        => 'text',
                'value'       => config('tuchuang.link_encode'),
                'title'       => lang('tc_link_encode'),
                'placeholder' => lang('tc_link_encode_tips'),
            ],
            'link_decode' => [
                'type'        => 'text',
                'value'       => config('tuchuang.link_decode'),
                'title'       => lang('tc_link_decode'),
                'placeholder' => lang('tc_link_decode_tips'),
            ],
            'des_length' => [
                'type'        => 'text',
                'value'       => config('tuchuang.des_length'),
                'title'       => lang('tc_des_length'),
                'placeholder' => lang('tc_des_length_tips'),
            ],
            'html_2' => [
                'type'        => 'html',
                'value'       => '<hr>',
            ],
            'link_referer' => [
                'type'        => 'textarea',
                'value'       => config('tuchuang.link_referer'),
                'rows'        => 3,
                'title'       => lang('tc_link_referer'),
                'placeholder' => lang('tc_link_referer_tips'),
            ],
            'link_domain' => [
                'type'        => 'textarea',
                'value'       => config('tuchuang.link_domain'),
                'rows'        => 3,
                'title'       => lang('tc_link_domain'),
                'placeholder' => lang('tc_link_domain_tips'),
            ],
        ];
        
        $this->assign('items', DcFormItems($items));
        
        return $this->fetch('tuchuang@admin/index');
	}
    
    public function update()
    {
        $status = \daicuo\Op::write(input('post.'),'tuchuang','config','system',0,'yes');
		if( !$status ){
		    $this->error(lang('fail'));
        }
        $this->success(lang('success'));
	}
}