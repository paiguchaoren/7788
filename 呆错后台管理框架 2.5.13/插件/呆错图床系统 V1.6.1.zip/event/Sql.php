<?php
namespace app\tuchuang\event;

class Sql
{
    /**
    * 安装时触发
    * @return bool 只有返回true时才会往下执行
    */
	public function install()
    {
        //配置
        model('tuchuang/Datas','loglic')->insertConfig();
        
        //路由
        model('tuchuang/Datas','loglic')->insertRoute();
        
        //前台权限
        model('tuchuang/Datas','loglic')->insertAuth();
        
        //后台菜单
        model('tuchuang/Datas','loglic')->insertMenu();
        
        //前台导航
        model('tuchuang/Datas','loglic')->insertNavs();
        
        //应用打包
        model('tuchuang/Datas','loglic')->updatePack();
        
        //清空缓存
        \think\Cache::clear();
        
        //返回结果
        return true;
	}
    
    /**
    * 升级时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function upgrade()
    {
        //更新基础信息
        model('tuchuang/Datas','loglic')->updateStatus();
        
        //更新打包配置
        model('tuchuang/Datas','loglic')->updatePack();
        
        //清空缓存
        \think\Cache::clear();
        
        //返回结果
        return true;
	}
    
    /**
    * 卸载时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function remove()
    {
        return model('tuchuang/Datas','loglic')->remove();
	}
    
    /**
    * 删除时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function unInstall()
    {
        return model('thchuang/Datas','loglic')->delete();
	}
}