<?php
/**
 * 安全输出Ckeditor编辑器
 * @version 1.3.1 判断去除xss函数
 * @version 1.0.0 首次引入
 * @param string $string 待过滤的字符串
 * @return string 处理后的字符串
 */
function ckeditorParse($string=''){
    if(function_exists('htmlPurifier')){
        return htmlPurifier($string);
    }
    return remove_xss($string);
}

/**
 * 字符串截取
 * @version 1.0.0 首次引入
 * @param string $string 必需;待截取的字符串
 * @param int $start 必需;起始位置;默认：0
 * @param int $length 必需;截取长度;默认：420
 * @param bool $suffix 可选;超出长度是否以...显示;默认：true
 * @param string $charset 可选;字符编码;默认：utf-8
 * @return string $string 截取后的字符串
 */
function ckeditorSubstr($string, $start=0, $length=420, $suffix=true, $charset="UTF-8"){
    $string = htmlspecialchars(ckeditorTrim($string));
    return DcSubstr($string, $start, $length, $suffix, $charset);
}

/**
 * 过滤连续空白
 * @version 1.0.0 首次引入
 * @param string $str 待过滤的字符串
 * @return string 处理后的字符串
 */
function ckeditorTrim($str=''){
    $str = str_replace("　",' ',str_replace("&nbsp;",' ',trim($str)));
    $str = preg_replace('#\s+#', ' ', $str);
    return $str;
}