$(document).ready(function () {
    window.daicuo.init();
});