﻿CKEDITOR.plugins.add('dcimage', {
    onLoad: function(editor){
        //alert('页面加载完成');
    },
    init: function (editor) {
        //editor.addContentsCss(this.path + "styles/easyimage.css");
        editor.ui.addButton('dcimage',{
            // 鼠标移到按钮提示文字
            label: '插入图片',
            // 命令
            command: 'dcimage',
            // 图标
            icon: this.path + 'image.svg',
            // 添加点击事件   
            click: function(){
                //alert($('.cke_button__dcimage').html());
            }
        });
	},
    beforeInit: function(editor){
        //alert('初始化前');
    },
    afterInit: function(editor) {
        editor.on('dataReady', function(evt) { 
            daicuo.upload.ajaxLoad(function(){
                daicuo.upload.start({
                    element: '.cke_button__dcimage',
                    multiple: true,
                    mimeTypes: 'image/*',
                    onSuccess: function(up, file, xhr){
                        if(file.responseTp.data.water){
                           var insertHtml = '<img class="img-fluid" alt="'+file.responseTp.data.old_name+'" src="'+file.responseTp.data.water+'" />'; 
                        }else{
                            var insertHtml = '<img class="img-fluid" alt="'+file.responseTp.data.old_name+'" src="'+file.responseTp.data.url+'" />';
                        }
                        editor.insertHtml(insertHtml);
                    }
                });
            });
        });
    }
});
CKEDITOR.addCss('img.img-fluid{max-width:50%;}');