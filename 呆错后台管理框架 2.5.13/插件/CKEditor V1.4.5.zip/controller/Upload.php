<?php
namespace app\ckeditor\controller;

use app\common\controller\Front;

class Upload extends Front
{
    public function _initialize()
    {
        $this->request->filter('trim,strip_tags,htmlspecialchars');
        
        parent::_initialize();
    }
    
    public function index()
    {
        return $this->fetch();
    }
}