<?php
return [
    //插件唯一标识
    'module'   => 'purifier',
    //插件名称
    'name'     => 'HtmlPurifier',
    //插件描述
    'info'     => 'HTMLPurifier是基于PHP编写的富文本HTML过滤器，使用了白名单过滤机制，只有被设置允许的才会通过检验。',
    //插件版本
    'version'  => '1.0.2',
    //依赖数据库
    'datatype' => ['sqlite', 'mysql'],
    //依赖插件版本
    'rely'     => [
        'daicuo' => '2.2.8',
    ],
];