<?php
return [
    'purifier' => [
        // 设置允许使用的HTML标签
        'htmlAllowed' => 'h1,h2,h3,h4,h5,table,td,th,tr,dl,dd,dt,font,u,p,b,strong,small,i,em,sub,sup,center,pre,code,embed,ul,ol,li,br,hr,s,span[style],img[width|height|alt|src|id|class],div[data-url],a[href|title|id|name|class|data-url],video[src|type|width|height|poster|preload|autoplay|controls|class],audio[src|width|height|poster|preload|autoplay|controls|class],source[src|type|media|class]',
        // 设置允许出现的CSS样式属性
        'cssAllowedProperties' => 'font,font-size,font-weight,font-style,font-family,text-decoration,padding-left,color,background-color,text-align',
    ]
];