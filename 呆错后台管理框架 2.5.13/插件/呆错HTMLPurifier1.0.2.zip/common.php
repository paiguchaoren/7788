<?php
//http://htmlpurifier.org/docs/enduser-customize.html
/**
 * 安全输出过滤后的HTML代码
 * @version 1.0.0 首次引入
 * @param string $string 待过滤的字符串
 * @return string 处理后的字符串
 */
function htmlPurifier($string=''){
    // 手动加载
    require_once './apps/purifier/vendor/htmlpurifier/HTMLPurifier.auto.php';
    // 创建配置对象
    $config = HTMLPurifier_Config::createDefault();
    // 设置编码
    $config->set('Core.Encoding', 'UTF-8');
    // 设置缓存
    $config->set('Cache.SerializerPath', RUNTIME_PATH);
    //$config->set('Cache.DefinitionImpl', null); 
    // 设置权限
    $config->set('Cache.SerializerPermissions', 0775);
    // 设置允许使用的HTML标签
    $config->set('HTML.Allowed', config('purifier.htmlAllowed'));//embed,video,source,audio,
    // 设置允许出现的CSS样式属性
    $config->set('CSS.AllowedProperties', config('purifier.cssAllowedProperties'));
    // 让文本自动添加段落标签
    $config->set('AutoFormat.AutoParagraph', true);
    // 清除空标签
    $config->set('AutoFormat.RemoveEmpty', true);
    // 设置a标签上是否允许使用target="_blank"
    $config->set('HTML.TargetBlank', true);
    // 设置允许打开的方式
    $config->set('Attr.AllowedFrameTargets', array('_blank', '_self', '_parent', '_top'));
    //增加自定义元素与属性
    $def = $config->getHTMLDefinition(true);
    //自定义元素
    $def->addElement('video', 'Block', 'Flow', 'Common', array(
        'src' => 'URI',
        'type' => 'Text',
        'width' => 'Length',
        'height' => 'Length',
        'poster' => 'URI',
        'preload' => 'Enum#auto,metadata,none',
        'autoplay' => 'Bool',
        'controls' => 'Bool',
    ));
    $def->addElement('audio', 'Block', 'Flow', 'Common', array(
        'src' => 'URI',
        'width' => 'Length',
        'height' => 'Length',
        'loop' => 'Bool',
        'preload' => 'Enum#auto,metadata,none',
        'autoplay' => 'Bool',
        'controls' => 'Bool',
    ));
    $def->addElement('source', 'Block', 'Flow', 'Common', array(
        'src' => 'URI',
        'type' => 'Text',
        'media' => 'Text',
    ));
    //自定义属性
    $def->addAttribute('a', 'data-url', 'Text');
    $def->addAttribute('div', 'data-url', 'Text');
    // 使用配置生成过滤用的对象
    $obj = new HTMLPurifier($config);
    // 过滤字符串
    return $obj->purify($string);
}