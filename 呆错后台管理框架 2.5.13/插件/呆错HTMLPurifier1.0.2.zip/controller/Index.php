<?php
namespace app\purifier\controller;

use app\common\controller\Front;

class Index extends Front
{

	public function _initialize()
    {
		parent::_initialize();
	}

	public function index()
    {
        return '<a href="https://www.daicuo.org/store/purifier" target="_blank">使用方法</a>';
	}
}