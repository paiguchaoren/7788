<?php
namespace daicuo;

class Log 
{
    protected static $error = 'error';
    
    //获取错误信息
    public static function getError()
    {
        return self::$error;
    }
    
    /**
     * 按模块名删除整个模块的数据
     * @param string $module 必需;应用名;默认：空
     * @return int 影响条数
     */
    public static function delete_module($module='')
    {
        $where = array();
        $where['log_module'] = ['eq', $module];
        return dbDelete('op', $where);
    }
    
    /**
     * 创建一条记录
     * @param array $where 删除条件
     * @return int 返回操作记录
     */
    public static function save($data=[])
    {
        return DcDbSave('common/Log', $data);
    }
    
    /**
     * 按条件删除一条记录
     * @param array $where 删除条件
     * @return int 返回操作记录
     */
    public static function delete($where=[])
    {
        return DcDbDelete('common/Log', $where);
    }
    
    /**
     * 修改一条日志
     * @param array $where 修改条件
     * @param array $data 写入数据（一维数组） 
     * @return mixed array|null
     */
    public static function update($where=[], $data=[])
    {
        unset($data['log_create_time']);
        return DcArrayResult( DcDbUpdate('common/Log', $where, $data) );
    }
    
    /**
     * 按条件查询一条日志
     * @param array $args 查询参数
     * @return mixed array|null
     */
    public static function get($args=[])
    {
        //格式验证
        if(!is_array($args)){
            return null;
        }
        //初始参数
        $args = DcArrayArgs($args, [
            'cache'     => true,
            'field'     => '',
            'fetchSql'  => false,
            'where'     => '',
            'with'      => '',//log_user,log_info
        ]);
        //返回结果
        return DcArrayResult( DcDbFind('common/Log', $args) );
    }
    
    /**
     * 按条件查询多条日志
     * @param array $args 查询条件（一维数组）
     * @return mixed array|null
     */
    public static function all($args=[])
    {
        //格式验证
        if(!is_array($args)){
            return null;
        }
        //分页处理
        if($args['limit'] && $args['page']){
            $args['paginate'] = [
                'list_rows' => $args['limit'],
                'page' => $args['page'],
            ];
            unset($args['limit']);
            unset($args['page']);
        }
        //参数初始化
        $args = array_merge([
            'cache'     => true,
            'field'     => '',
            'fetchSql'  => false,
            'sort'      => 'log_id',
            'order'     => 'desc',
            'paginate'  => '',
            'where'     => '',
            'with'      => '',//log_user,log_info
        ], $args);
        //查询数据
        return DcArrayResult( DcDbSelect('common/Log', $args) );
    }
}