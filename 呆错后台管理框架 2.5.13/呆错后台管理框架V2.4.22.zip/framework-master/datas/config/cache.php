<?php
return array (
  'type' => 'File',
  'prefix' => 'dev',
  'path' => './datas/cache/',
  'db' => './datas/db/#cache.db3',
  'host' => '127.0.0.1',
  'port' => '6379',
  'expire' => 0,
  'expire_detail' => '',
  'expire_item' => '',
);
?>