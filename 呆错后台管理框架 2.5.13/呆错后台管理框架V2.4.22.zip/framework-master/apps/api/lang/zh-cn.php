<?php
return [
    'token_none'     => '请先换取用户Token',
    'token_get'      => '获取TOKEN',
    'secret_error'   => '密钥错误',
];