$(document).ready(function () {
    window.daicuo.captcha.init();
});