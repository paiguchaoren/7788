<?php
namespace app\api\controller;

use app\common\controller\Api;

class Nav extends Api
{
    protected $auth = [
         'check'       => true,
         'none_login'  => [],
         'none_right'  => [],
         'error_login' => 'api/token/index',
         'error_right' => 'api/token/index',
    ];
    
	public function _initialize()
    {
		parent::_initialize();
	}
    
    /**
     * 按模型名获取菜单列表
     * @version 2.4.3 首次引入
     * @param string $module 必需;应用名;默认:common
     * @param string $type 可选;类别;默认:index
     * @return json
     */
	public function index()
    {
        $result = model('common/Navs','loglic')->select([
            'with'   => 'term_meta',
            'module' => input('module/s','common'),
            'type'   => input('type/s','navbar'),
            'sort'   => 'term_order',
            'order'  => 'desc',
        ]);
        $this->success(lang('success'), $result);
	}
    
    /**
     * 按ID获取菜单详情
     * @version 2.4.3 首次引入
     * @param array $id 必需;数组格式;默认:空
     * @return json
     */
    public function detail()
    {
        $result = model('common/Navs','loglic')->get([
            'with'   => 'term_meta',
            'id'     => input('id/d',0),
        ]);
        $this->success(lang('success'), $result);
	}
}