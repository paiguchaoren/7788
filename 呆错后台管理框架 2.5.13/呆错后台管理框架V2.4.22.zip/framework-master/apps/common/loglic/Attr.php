<?php
namespace app\common\loglic;

class Attr
{
    //状态属性
    public function status()
    {
        return [
            'normal'  => lang('normal'),
            'hidden'  => lang('hidden'),
            'private' => lang('private'),
            'public'  => lang('public'),
            'verify'  => lang('verify'),
        ];
    }
    
    //状态属性
    public function statusOption()
    {
        return [
            'normal'  => lang('normal'),
            'hidden'  => lang('hidden'),
            'private' => lang('private'),
            'verify'  => lang('verify'),
        ];
    }
    
    //打开方式
    public function target()
    {
        return [
            '_self'   => lang('target_self'),
            '_blank'  => lang('target_blank'),
            '_parent' => lang('target_parent'),
            '_top'    => lang('target_top'),
            '_new'    => lang('target_new')
        ];
    }
    
    //分类属性
    public function categoryType()
    {
        return $this->optionLang(config('common.type_category'),'common');
    }
    
    //标签属性
    public function tagType()
    {
        return $this->optionLang(config('common.type_tag'),'common');
    }
    
    //导航属性
    public function navsType()
    {
        return $this->optionLang(config('common.type_nav'));
    }
    
    //属性对应语言包
    public function optionLang($config=[], $firstKey='', $firstValue='---')
    {
        $key   = explode(',',$config);
        $value = array_map(lang, $key);
        if($firstKey){
            return array_merge([$firstKey=>$firstValue], array_combine($key,$value));
        }
        return array_combine($key,$value);
    }
    
    //排序字段term表
    public function termSort()
    {
        return [
            'term_id',
            'term_parent',
            'term_order',
            'term_count',
            'term_name',
            'term_slug',
        ];
    }
    
    //排序字段info表
    public function infoSort()
    {
        return [
            'info_id',
            'info_order',
            'info_views',
            'info_hits',
            'info_parent',
            'info_slug',
            'info_create_time',
            'info_update_time',
        ];
    }
    
    //排序字段user表
    public function userSort()
    {
        return [
            'user_id',
            'user_order',
            'user_mobile',
            'user_views',
            'user_hits',
            'user_slug',
            'user_create_time',
            'user_update_time',
        ];
    }
}