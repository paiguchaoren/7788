<?php
namespace app\admin\loglic;

class Navs
{
    public function fields($data)
    {
        $module   = DcEmpty($data['navs_module'],'index');
        $controll = 'navs';
        $action   = DcEmpty($data['navs_action'],'index');
        $fields = [
            'navs_id' => [
                'order'           => 1,
                'type'            => 'hidden',
                'value'           => $data['navs_id'],
                'data-filter'     => false,
                'data-visible'    => true,
                'data-width'      => 60,
                'data-width-unit' => 'px',
                'data-sortable'   => true,
                'data-sort-name'  => 'navs_id',
                'data-order'      => 'asc',
            ],
            'navs_parent' => [
                'order'           => 7,
                'type'            => 'select',
                'value'           => $data['navs_parent'],
                'option'          => DcTermOption(['module'=>$data['navs_module'],'controll'=>$controll]),
                'class'           => 'form-group col-md-3',
                'data-filter'     => true,
                'data-visible'    => true,
                'data-width'      => 100,
            ],
            'navs_status' => [
                'order'           => 0,
                'type'            => 'select',
                'value'           => DcEmpty($data['navs_status'],'normal'),
                'option'          => model('common/Attr','loglic')->status(),
                'class'           => 'form-group col-md-3',
                'data-filter'     => true,
                'data-visible'    => false,
            ],
            'navs_status_text' => [
                'order'           => 8,
                'data-title'      => lang('navs_status'),
                'data-visible'    => true,
                'data-width'      => 100,
            ],
            'navs_type' => [
                'order'           => 9,
                'type'            => 'select',
                'option'          => model('common/Attr','loglic')->navsType(),
                'value'           => $data['navs_type'],
                'class'           => 'form-group col-md-3',
                'data-filter'     => true,
                'data-visible'    => true,
                'data-width'      => 100,
            ],
            'navs_target' => [
                'order'           => 10,
                'type'            => 'select',
                'option'          => model('common/Attr','loglic')->target(),
                'value'           => $data['navs_target'],
                'class'           => 'form-group col-md-3',
                'data-filter'     => false,
                'data-visible'    => true,
                'data-width'      => 100,
                'data-value'      => '',
            ],
            'navs_name' => [
                'order'           => 3,
                'type'            => 'text',
                'value'           => $data['navs_name'],
                'required'        => true,
                'data-filter'     => false,
                'data-visible'    => true,
                'data-align'      => 'left',
            ],
            'navs_url' => [
                'order'           => 4,
                'type'            => 'text',
                'value'           => $data['navs_url'],
                'data-filter'     => false,
                'data-visible'    => true,
                'data-align'      => 'left',
            ],
            'navs_active' => [
                'order'           => 5,
                'type'            => 'text',
                'value'           => $data['navs_active'],
                'data-visible'    => true,
                'data-width'      => 100,
            ],
            'navs_ico' => [
                'order'           => 6,
                'type'            => 'text',
                'value'           => $data['navs_ico'],
                'data-visible'    => true,
                'data-width'      => 100,
            ],
            'navs_image' => [
                'order'           => 0,
                'type'            => 'image',
                'multiple'        => false,
                'value'           => $data['navs_image'],
            ],
            'navs_info' => [
                'order'           => 0,
                'type'            => 'text',
                'value'           => $data['navs_info'],
            ],
            'navs_order' => [
                'order'           => 11,
                'type'            => 'number',
                'value'           => intval($data['navs_order']),
                'data-filter'     => false,
                'data-visible'    => true,
                'data-width'      => 100,
                'data-sortable'   => true,
            ],
            'navs_action' => [
                'order'           => 97,
                'type'            => 'text',
                'value'           => $action,
                'data-filter'     => true,
                'data-visible'    => true,
                'data-width'      => 100,
                'data-value'      => $action,
            ],
            'navs_controll' => [
                'order'           => 98,
                'type'            => 'text',
                'value'           => 'navs',
                'disabled'        => true,
                'data-filter'     => false,
                'data-visible'    => true,
                'data-width'      => 100,
            ],
            'navs_module' => [
                'order'           => 99,
                'type'            => 'text',
                'value'           => $module,
                'data-filter'     => true,
                'data-visible'    => true,
                'data-width'      => 100,
                'data-value'      => $module,
            ],
            'term_order' => [
                'order'           => 2,
                'data-filter'     => false,
                'data-visible'    => true,
                'data-width'      => 80,
                'data-formatter'  => 'daicuo.admin.table.sortFormatter',
            ],
        ];
        //合并所有字段
        if($customs = model('common/Term','loglic')->metaList($module, $controll, $action)){
            $fields = array_merge($fields, DcFields($customs, $data));
        }
        //返回所有表单字段
        return adminFormRow($fields,'col-md-6');
    }
}