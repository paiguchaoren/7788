<?php
namespace app\admin\loglic;

use app\common\loglic\Update;

class Upgrade extends Update
{
    //在线升级回调（需执行SQL时更新该文件）
    public function init()
    {
        \think\Db::execute("update dc_term set term_action='index' where term_controll='navs';");
        
        return true;
    }
}