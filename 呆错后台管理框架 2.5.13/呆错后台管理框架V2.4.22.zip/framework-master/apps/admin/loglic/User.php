<?php
namespace app\admin\loglic;

class User
{
    public function fields($data=[])
    {
        $fields = [
            'user_id' => [
                'order'           => 1,
                'type'            => 'hidden',
                'value'           => $data['user_id'],
                'data-filter'     => false,
                'data-visible'    => true,
                'data-sortable'   => true,
                'data-width'      => '80',
                'data-width-unit' => 'px',
            ],
            'user_name' => [
                'order'           => 2,
                'type'            => 'text',
                'value'           => $data['user_name'],
                'required'        => true,
                'class'           => 'form-group col-md-6',
                'data-filter'     => false,
                'data-visible'    => true,
                'data-escape'     => true,
                'data-align'      => 'left',
                'data-width'      => '10',
                'data-width-unit' => '%',
            ],
            'user_pass' => [
                'order'           => 0,
                'type'            => 'password',
                'value'           => $data['user_pass'],
                'class'           => 'form-group col-md-4',
            ],
            'user_status' => [
                'order'           => 0,
                'type'            => 'select',
                'value'           => DcEmpty($data['user_status'],'normal'),
                'option'          => model('common/Attr','loglic')->statusOption(),
                'class'           => 'form-group col-md-2',
                'data-filter'     => true,
                'data-visible'    => false,
            ],
            'user_status_text' => [
                'order'           => 500,
                'data-title'      => lang('user_status'),
                'data-visible'    => true,
            ],
            'user_slug' => [
                'order'           => 0,
                'type'            => 'text',
                'value'           => $data['user_slug'],
                'class'           => 'form-group col-md-6',
            ],
            'user_nice_name' => [
                'order'           => 5,
                'type'            => 'text',
                'value'           => DcEmpty($data['user_nice_name'],uniqid()),
                'class'           => 'form-group col-md-4',
                'data-filter'     => false,
                'data-visible'    => true,
                'data-escape'     => true,
            ],
            'user_views' => [
                'order'           => 506,
                'type'            => 'text',
                'value'           => intval($data['user_views']),
                'class'           => 'form-group col-md-2',
                'data-sortable'   => true,
                'data-visible'    => true,
            ],
            'user_mobile' => [
                'order'           => 3,
                'type'            => 'text',
                'value'           => $data['user_mobile'],
                'class'           => 'form-group col-md-6',
                'data-filter'     => false,
                'data-visible'    => true,
                'data-escape'     => true,
                'data-sortable'   => true,
            ],
            'user_email' => [
                'order'           => 4,
                'type'            => 'email',
                'value'           => $data['user_email'],
                'class'           => 'form-group col-md-4',
                'data-filter'     => false,
                'data-visible'    => true,
                'data-escape'     => true,
            ],
            'user_hits' => [
                'order'           => 507,
                'type'            => 'text',
                'value'           => intval($data['user_hits']),
                'class'           => 'form-group col-md-2',
                'data-sortable'   => true,
                'data-visible'    => true,
            ],
            'user_token' => [
                'order'           => 0,
                'type'            => 'text',
                'value'           => $data['user_token'],
                'class'           => 'form-group col-md-6',
            ],
            'user_expire' => [
                'order'           => 0,
                'type'            => 'text',
                'value'           => $data['user_expire'],
                'class'           => 'form-group col-md-4',
            ],
            'user_create_time' => [
                'order'           => 508,
                'type'            => 'text',
                'value'           => $data['user_create_time'],
                'class'           => 'form-group col-md-2',
            ],
            'user_update_ip' => [
                'order'           => 510,
                'type'            => 'text',
                'value'           => $data['user_update_ip'],
                'class'           => 'form-group col-md-6',
                'data-visible'    => true,
            ],
            'user_create_ip' => [
                'order'           => 0,
                'type'            => 'text',
                'value'           => $data['user_create_ip'],
                'class'           => 'form-group col-md-4',
            ],
            'user_update_time' => [
                'order'           => 509,
                'type'            => 'text',
                'value'           => $data['user_update_time'],
                'class'           => 'form-group col-md-2',
                'data-visible'    => true,
                'data-sortable'   => true,
            ],
            'user_capabilities' => [
                'order'         => 6,
                'type'          => 'select',
                'option'        => model('common/Role','loglic')->option(),
                'value'         => DcEmpty($data['user_capabilities'],'subscriber'),
                'multiple'      => true,
                'size'          => 5,
                'data-filter'   => true,
                'data-visible'  => true,
            ],
            'user_caps' => [
                'order'  => 0,
                'type'   => 'textarea',
                'value'  => $data['user_caps'],
                'rows'   => 5,
            ],
        ];
        //合并用户模块所有字段
        if($customs = model('common/User','loglic')->metaList($data['user_action'])){
            $fields = array_merge($fields, DcFields($customs, $data));
        }
        //返回所有表单字段
        return adminFormRow($fields,'col-md-6');
    }
}