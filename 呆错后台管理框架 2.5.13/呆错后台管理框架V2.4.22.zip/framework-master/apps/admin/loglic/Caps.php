<?php
namespace app\admin\loglic;

class Caps
{
    //后台权限节点
    public function back()
    {
        $caps = [
            'admin/index/index',
            'admin/upload/index',
            'admin/video/index',
            'admin/cache/index',
            'admin/config/index',
            //'admin/update/index',
            //'admin/update/online',
            //'admin/union/index',
            '<hr>',
            'admin/upload/update',
            'admin/video/update',
            'admin/cache/update',
            'admin/config/update',
            '<hr>',
            'admin/apply/index',
            'admin/store/index',
            //'admin/pack/index',
            //'admin/pack/save',
            '<hr>',
            'admin/tool/index',
            'admin/tool/delete',
            '<hr>',
            'admin/user/index',
            'admin/user/save',
            'admin/user/delete',
            '<hr>',
            'admin/role/index',
            'admin/role/save',
            'admin/role/delete',
            '<hr>',
            'admin/auth/index',
            'admin/auth/save',
            'admin/auth/delete',
            '<hr>',
            'admin/navs/index',
            'admin/navs/save',
            'admin/navs/delete',
            '<hr>',
            'admin/menu/index',
            'admin/menu/save',
            'admin/menu/delete',
            '<hr>',
            'admin/category/index',
            'admin/category/save',
            'admin/category/delete',
            'admin/category/clear',
            '<hr>',
            'admin/tag/index',
            'admin/tag/save',
            'admin/tag/delete',
            'admin/tag/clear',
            '<hr>',
            'admin/route/index',
            'admin/route/save',
            'admin/route/delete',
            '<hr>',
            'admin/log/index',
            'admin/log/update',
            'admin/log/delete',
            '<hr>',
            'admin/field/index',
            'admin/field/save',
            'admin/field/delete',
            '<hr>',
            'admin/lang/index',
            'admin/lang/save',
            'admin/lang/delete',
            '<hr>',
        ];
        
        \think\Hook::listen('admin_caps_back', $caps);
        
        return $caps;
    }
    
    //前台权限节点
    public function front()
    {
        $caps = [
            'api/upload/save',
            'api/token/update',
            'api/token/refresh',
            'api/token/delete',
            'api/category/index',
            'api/category/detail',
            'api/tag/index',
            'api/tag/detail',
            'api/nav/index',
            'api/nav/detail',
            '<hr>',
        ];
        
        \think\Hook::listen('admin_caps_front', $caps);
        
        return $caps;
    }
}