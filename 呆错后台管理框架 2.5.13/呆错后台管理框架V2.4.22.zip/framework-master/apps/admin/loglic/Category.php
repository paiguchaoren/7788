<?php
namespace app\admin\loglic;

class Category
{
    public function fields($data=[])
    {
        $module   = DcEmpty($data['term_module'],'index');
        $controll = 'category';
        $action   = DcEmpty($data['term_action'],'index');
        $fields = [
            'term_id' => [
                'order'           => 1,
                'type'            => 'hidden',
                'value'           => $data['term_id'],
                'data-filter'     => false,
                'data-visible'    => true,
                'data-width'      => '80',
                'data-width-unit' => 'px',
            ],
            'term_parent' => [
                'order'           => 5,
                'type'            => 'select',
                'value'           => $data['term_parent'],
                'option'          => DcTermOption(['module'=>$module,'controll'=>$controll,'action'=>$action]),
                'class'           => 'form-group col-md-2',
                'data-filter'     => true,
                'data-visible'    => true,
                'data-width'      => 100,
            ],
            'term_status' => [
                'order'           => 0,
                'type'            => 'select',
                'value'           => DcEmpty($data['term_status'],'normal'),
                'option'          => model('common/Attr','loglic')->status(),
                'class'           => 'form-group col-md-2',
                'data-filter'     => true,
                'data-visible'    => false,
            ],
            'term_status_text' => [
                'order'           => 6,
                'data-title'      => lang('term_status'),
                'data-visible'    => true,
                'data-width'      => 100,
            ],
            'term_type' => [
                'order'           => 95,
                'type'            => 'select',
                'option'          => model('common/Attr','loglic')->categoryType(),
                'value'           => $data['term_type'],
                'class'           => 'form-group col-md-2',
                'data-filter'     => true,
                'data-visible'    => true,
                'data-width'      => 100,
            ],
            'term_action' => [
                'order'           => 97,
                'type'            => 'text',
                'value'           => $action,
                'class'           => 'form-group col-md-2',
                'data-filter'     => true,
                'data-visible'    => true,
                'data-width'      => 100,
                'data-value'      => $action,
            ],
            'term_controll' => [
                'order'           => 98,
                'type'            => 'text',
                'value'           => $controll,
                'class'           => 'form-group col-md-2',
                'disabled'        => true,
                'data-filter'     => false,
                'data-visible'    => true,
                'data-width'      => 100,
            ],
            'term_module' => [
                'order'           => 99,
                'type'            => 'text',
                'value'           => $module,
                'class'           => 'form-group col-md-2',
                'data-filter'     => true,
                'data-visible'    => true,
                'data-width'      => 100,
                'data-value'      => $module,
            ],
            'term_name' => [
                'order'           => 3,
                'type'            => 'text',
                'value'           => $data['term_name'],
                'required'        => true,
                'data-filter'     => false,
                'data-visible'    => true,
                'data-align'      => 'left',
            ],
            'term_slug' => [
                'order'           => 4,
                'type'            => 'text',
                'value'           => $data['term_slug'],
                'data-filter'     => false,
                'data-visible'    => true,
                'data-align'      => 'left',
            ],
            'term_title' => [
                'order'           => 0,
                'type'            => 'text',
                'value'           => $data['term_title'],
            ],
            'term_keywords' => [
                'order'           => 0,
                'type'            => 'text',
                'value'           => $data['term_keywords'],
            ],
            'term_description' => [
                'order'           => 0,
                'type'            => 'text',
                'value'           => $data['term_description'],
            ],
            'term_info' => [
                'order'           => 0,
                'type'            => 'text',
                'value'           => $data['term_info'],
            ],
            'term_limit' => [
                'order'           => 0,
                'type'            => 'number',
                'value'           => $data['term_limit'],
            ],
            'term_order' => [
                'order'           => 2,
                'type'            => 'number',
                'value'           => intval($data['term_order']),
                'data-filter'     => false,
                'data-visible'    => true,
                'data-width'      => 80,
                'data-formatter'  => 'daicuo.admin.table.sortFormatter',
            ],
            'order' => [
                'order'           => 2,
                'data-visible'    => true,
                'data-width'      => 80,
                'data-title'      => lang('term_order'),
                'data-formatter'  => 'daicuo.admin.table.termOrder',
            ],
            'term_count' => [
                'order'           => 96,
                'data-visible'    => true,
                'data-sortable'   => true,
                'data-width'      => 100,
            ],
            'term_tpl' => [
                'order'           => 0,
                'type'            => 'text',
                'value'           => $data['term_tpl'],
            ],
            'term_info_tpl' => [
                'order'           => 0,
                'type'            => 'text',
                'value'           => $data['term_info_tpl'],
            ],
        ];
        //合并所有字段
        if($customs = model('common/Term','loglic')->metaList($module, $controll, $action)){
            $fields = array_merge($fields, DcFields($customs, $data));
        }
        //返回所有表单字段
        return adminFormRow($fields,'col-md-6');
    }
}