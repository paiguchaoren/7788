<?php
return [
    'user_login_before'  => [
        'app\\admin\\behavior\\Hook',
    ],
];