<?php
return [
    //'controller_auto_search' => true,
    'url_common_param' => true,
    'url_html_suffix'  => '',
];