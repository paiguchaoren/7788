<?php
return [
    'index' => [
        'theme'     => 'default',
        'theme_wap' => 'default',
        'demo'      => 'demo',
    ]
];