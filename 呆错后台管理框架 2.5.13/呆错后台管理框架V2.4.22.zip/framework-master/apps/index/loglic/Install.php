<?php
namespace app\index\loglic;

class Install
{
    //安装MYSQL版回调
    public function mysql()
    {
        \daicuo\Apply::install('index','install');
        
        return true;
    }
    
    //设置首页路由
    private function mysqlRewrite()
    {
        return model('common/Route','loglic')->index('index/index/index', 'index');
    }
    
    //批量添加初始配置
    public function config()
    {
        config('common.validate_name', false);
        
        return model('common/Config','loglic')->install([
            'theme'       => 'default_pc',
            'theme_wap'   => 'default_wap',
            'title'       => '呆错首页插件演示',
            'keywords'    => 'DaiCuo,呆错,后台框架,后台模板',
            'description' => '呆错（DaiCuo）是一款基于ThinkPHP、Bootstrap、Jquery的自适应后台管理框架！',
        ],'index');
    }
    
    //批量定义语言包
    public function lang()
    {
        return model('common/Lang','loglic')->install([
            'index_config' => '表单扩展示例',
        ],'index','zh-cn');
    }
    
    //批量写入插件动态字段
    public function field()
    {
        return model('common/Field','loglic')->install([
            [
                'op_name'     => 'index_config',
                'op_value'    => json_encode([
                    'type'         => 'text',
                    'relation'     => 'eq',
                    'data-visible' => false,
                    'data-filter'  => false,
                ]),
                'op_module'   => 'index',
                'op_controll' => 'admin',
                'op_action'   => 'index',
            ]
        ]);
    }
    
    //批量添加路由伪静态
    public function route()
    {
        return model('common/Route','loglic')->install([
            [
                'rule'        => '/',
                'address'     => 'index/index/index',
                'method'      => 'get',
            ],
        ],'index');
    }
    
    //批量添加后台菜单
    public function menu()
    {
        config('common.validate_name', false);
        
        //批量添加后台一级菜单
        $result = model('common/Menu','loglic')->install([
            [
                'term_name'   => '首页',
                'term_slug'   => 'index',
                'term_info'   => 'fa-home',
                'term_module' => 'index',
                'term_order'  => 9,
            ],
        ]);
        
        //批量添加后台二级菜单
        $result = model('common/Menu','loglic')->install([
            [
                'term_name'   => '菜单管理',
                'term_slug'   => 'admin/navs/index?parent=index&navs_module=index',
                'term_info'   => 'fa-navicon',
                'term_module' => 'index',
                'term_order'  => 8,
            ],
            [
                'term_name'   => '分类管理',
                'term_slug'   => 'admin/category/index?parent=index&term_module=index',
                'term_info'   => 'fa-list',
                'term_module' => 'index',
                'term_order'  => 7,
            ],
            [
                'term_name'   => '标签管理',
                'term_slug'   => 'admin/tag/index?parent=index&term_module=index',
                'term_info'   => 'fa-tags',
                'term_module' => 'index',
                'term_order'  => 6,
            ],
            [
                'term_name'   => '路由管理',
                'term_slug'   => 'admin/route/index?parent=index&op_module=index',
                'term_info'   => 'fa-wifi',
                'term_module' => 'index',
                'term_order'  => 5,
            ],
            [
                'term_name'   => '字段管理',
                'term_slug'   => 'admin/field/index?parent=index&op_module=index',
                'term_info'   => 'fa-cube',
                'term_module' => 'index',
                'term_order'  => 4,
            ],
            [
                'term_name'   => '语言定义',
                'term_slug'   => 'admin/lang/index?parent=index&op_module=index',
                'term_info'   => 'fa-commenting',
                'term_module' => 'index',
                'term_order'  => 3,
            ],
            [
                'term_name'   => '后台菜单',
                'term_slug'   => 'admin/menu/index?parent=index&term_module=index',
                'term_info'   => 'fa-navicon',
                'term_module' => 'index',
                'term_order'  => 2,
            ],
            [
                'term_name'   => '频道设置',
                'term_slug'   => 'index/admin/index',
                'term_info'   => 'fa-gear',
                'term_module' => 'index',
                'term_order'  => 1,
            ],
        ],'首页');
        
        return true;
    }
    
    //批量添加前台菜单
    public function navs()
    {
        config('common.validate_name', false);
        
        model('common/Navs','loglic')->install([
            [
                'navs_name'       => '返回首页',
                'navs_url'        => 'index/index/index',
                'navs_type'       => 'navbar',
                'navs_module'     => 'index',
                'navs_action'     => 'index',
                'navs_order'      => 9,
                'navs_active'     => 'indexindexindex',
                'navs_target'     => '_self',
            ],
        ]);
        
        return true;
    }
    
    //批量添加初始分类
    public function category()
    {
        config('common.validate_name', false);
        
        model('common/Category','loglic')->install([
            [
                'term_name'       => '分类1',
                'term_slug'       => 'category1',
                'term_type'       => 'navbar',
                'term_module'     => 'index',
            ],
            [
                'term_name'       => '分类2',
                'term_slug'       => 'category2',
                'term_type'       => 'navbar',
                'term_module'     => 'index',
            ],
        ]);
        
        return true;
    }
    
    //批量添加初始标签
    public function tag()
    {
        config('common.validate_name', false);
        
        model('common/Tag','loglic')->install([
            [
                'term_name'       => '标签1',
                'term_slug'       => 'tag1',
                'term_module'     => 'index',
            ],
            [
                'term_name'       => '标签2',
                'term_slug'       => 'tag2',
                'term_module'     => 'index',
            ],
        ]);
        
        return true;
    }
}