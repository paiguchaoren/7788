<?php
namespace app\index\loglic;

class Datas
{
    //卸载
    public function remove()
    {
        return $this->delete();
    }

    //删除
    public function delete()
    {
        //删除插件配置表
        \daicuo\Op::delete_module('index');
        
        //删除插件队列表
        \daicuo\Term::delete_module('index');
        
        //删除插件用户表
        //\daicuo\User::delete_module('index');
        
        //清空缓存
        \think\Cache::clear();
        
        //返回结果
        return true;
	}
}