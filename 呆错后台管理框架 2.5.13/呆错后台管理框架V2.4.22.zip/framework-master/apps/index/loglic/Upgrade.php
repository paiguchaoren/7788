<?php
namespace app\index\loglic;

use app\common\loglic\Update;

class Upgrade extends Update
{
    //在线升级回调(MYSQL+SQL)
    public function init()
    {
        return true;
    }
    
    //更新应用状态
    public function storeStatus()
    {
        return \daicuo\Apply::updateStatus('index', 'enable');
    }
}