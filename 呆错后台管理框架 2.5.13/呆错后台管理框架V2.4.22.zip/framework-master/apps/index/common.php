<?php
/**
 * 过滤连续空白
 * @version 1.0.0 首次引入
 * @param string $str 待过滤的字符串
 * @return string 处理后的字符串
 */
function indexTrim($str=''){
    $str = str_replace("　",' ',str_replace("&nbsp;",' ',trim($str)));
    return preg_replace('#\s+#', ' ', $str);
}