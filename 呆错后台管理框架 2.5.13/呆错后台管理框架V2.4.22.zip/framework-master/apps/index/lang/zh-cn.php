<?php
return [
    'admin/index/config/title' => '首页设置',
];