<?php
namespace app\index\event;

use app\common\controller\Addon;

class Admin extends Addon
{
	
	public function _initialize()
    {
		parent::_initialize();
	}

	public function index()
    {
        $themes = DcThemeOption('index');
        
        $items  = DcFormItems([
            'title' => [
                'type'        => 'text',
                'name'        => 'title',
                'id'          => 'title',
                'value'       => config('index.title'),
                'title'       => lang('title'),
                'placeholder' => lang('title_placeholder'),
                'readonly'    => false,
                'disabled'    => false,
                'required'    => true,
            ],
            'keywords' => [
                'type'        => 'text',
                'name'        => 'keywords',
                'id'          => 'keywords',
                'value'       => config('index.keywords'),
                'title'       => lang('keywords'),
                'placeholder' => lang('keywords_placeholder'),
                'readonly'    => false,
                'disabled'    => false,
                'required'    => false,
            ],
            'description' => [
                'type'        => 'text',
                'name'        => 'description',
                'id'          => 'description',
                'value'       => config('index.description'),
                'title'       => lang('description'),
                'placeholder' => lang('description_placeholder'),
                'readonly'    => false,
                'disabled'    => false,
                'required'    => false,
            ],
            'theme' => [
                'type'        => 'custom',
                'name'        => 'theme',
                'id'          => 'theme',
                'value'       => config('index.theme'),
                'title'       => lang('theme'),
                'placeholder' => lang('theme_placeholder'),
                'option'      => $themes,
                'readonly'    => false,
                'disabled'    => false,
                'required'    => false,
                'multiple'    => false,
            ],
            'theme_wap' => [
                'type'        => 'custom',
                'name'        => 'theme_wap',
                'id'          => 'theme_wap',
                'title'       => lang('theme_wap'),
                'value'       => config('index.theme_wap'),
                'placeholder' => lang('wap_theme_placeholder'),
                'option'      => $themes,
                'readonly'    => false,
                'disabled'    => false,
                'required'    => false,
                'multiple'    => false,
            ],
        ]);
        //扩展表单字段
        $customs = model('common/Field','loglic')->forms([
            'module'   => 'index',
            'controll' => 'admin',
            'action'   => 'index',
        ]);
        if($customs){
            $items['hr'] = [
                'type'        => 'html',
                'value'       => '<hr>',
            ];
            $items = array_merge($items, DcFields($customs, config('index')));
        }
        //模板变量
        $this->assign('items', DcFormItems($items));
        //加载模板
        return $this->fetch('index@admin/index');
	}
    
    public function update()
    {
        $status = \daicuo\Op::write(input('post.'), 'index', 'config', 'system' ,0, 'yes');
		if( !$status ){
		    $this->error(lang('fail'));
        }
        $this->success(lang('success'));
	}
}