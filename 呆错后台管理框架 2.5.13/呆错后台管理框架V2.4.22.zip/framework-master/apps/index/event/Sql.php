<?php
namespace app\index\event;

class Sql
{
    /**
    * 安装时触发
    * @return bool 只有返回true时才会往下执行
    */
	public function install()
    {
        //初始配置
        model('index/Install','loglic')->config();
        
        //初始语言
        model('index/Install','loglic')->lang();
        
        //批量写入插件动态字段
        model('index/Install','loglic')->field();
        
        //批量添加路由伪静态
        model('index/Install','loglic')->route();

        //批量添加后台菜单
        model('index/Install','loglic')->menu();
        
        //批量添加前台导航
        model('index/Install','loglic')->navs();
        
        //批量添加前台导分类
        model('index/Install','loglic')->category();
        
        //批量添加前台标签
        model('index/Install','loglic')->tag();
        
        //清空缓存
        \think\Cache::clear();
        
        //返回结果
        return true;
	}
    
    /**
    * 升级时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function upgrade()
    {
        return model('index/Upgrade','loglic')->storeStatus();
    }
    
    /**
    * 卸载时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function remove()
    {
        return model('index/Datas','loglic')->delete();
    }
    
    /**
    * 删除时触发
    * @return bool 只有返回true时才会往下执行
    */
    public function unInstall()
    {
        return model('index/Datas','loglic')->delete();
	}
	
}