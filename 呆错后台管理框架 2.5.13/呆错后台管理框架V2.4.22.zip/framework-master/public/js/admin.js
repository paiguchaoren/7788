// 后台管理
window.daicuo.admin = {
    // 初始化
    init: function(){
        //侧栏事件
        this.sideBar();
        //版本检测
        this.version();
        //表格数据
        this.table.init('table[data-toggle="bootstrap-table"]');
        //AJAX
        daicuo.ajax.init();
        //表单
        daicuo.form.init();
        //JSON
        daicuo.json.init();
        //标签
        daicuo.tags.init();
        //上传
        daicuo.upload.init();
    },
    // 侧栏点击事件
    sideBar: function() {
        $(document).on('click', '[data-toggle="main-left"]', function() {
            $('.main-left').toggleClass('open');
            $('.main-left').toggleClass('d-block');
            $('.main-right').toggleClass('col-12');
        });
    },
    // 版本检测 获取服务器最新版本jsonp格式
    version: function() {
        var $dom = new Array();
        $('[data-toggle="version"]').each(function(key, value) {
            $dom[key] = $(this);
            $version = $dom[key].attr('data-version');
            $module = $dom[key].attr('data-module');
            if (!$version || !$module) {
                $this.removeClass();
                return false;
            }
            //后端请求防止恶意JS
            $.ajax({
                type: 'get',
                cache: false,
                url: daicuo.config.file + '/version/index/?version=' + $version + '&module=' + $module,
                dataType: 'json',
                timeout: 3000,
                success: function($json) {
                    if ($json.code == 1) {
                        $dom[key].html('<a class="badge badge-purple" href="' + $json.upgrade + '" data-toggle="get"><i class="fa fa-arrow-circle-up"></i> ' + $json.version + '</a> <a class="badge badge-secondary" href="' + $json.update + '" target="_blank">' + $json.msg + '</a>');
                    }
                }
            });
            $dom[key].removeClass();
        });
    },
    //表格
    table : {
        uniqueId   : '',
        urlSort    : '',
        urlEdit    : '',
        urlDelete  : '',
        urlPreview : '',
        // 表格初始化
        init : function(selector){
            //常用属性
            daicuo.admin.table.uniqueId   = $(selector).data('unique-id');
            daicuo.admin.table.urlSort    = $(selector).data('url-sort');
            daicuo.admin.table.urlEdit    = $(selector).data('url-edit');
            daicuo.admin.table.urlDelete  = $(selector).data('url-delete');
            daicuo.admin.table.urlPreview = $(selector).data('url-preview');
            //呆错表格初始化
            window.daicuo.table.init({
                selector: selector,
                onSuccess: function(element){
                    //表格箭头排序
                    daicuo.admin.table.sortEvents(selector);
                    //监听刷新按钮
                    $('[data-toggle="refresh"]').on("click", document.body, function() {
                        daicuo.table.refresh(element);
                    });
                }
            });
        },
        // 表格列格式器 op-order
        opOrder : function(value, row, index, field){
            return row.op_order;
        },
        // 表格列格式器 term-order
        termOrder : function(value, row, index, field){
            return row.term_order;
        },
        // 表格列格式器 data-formatter
        formatter : function(value, row, index, field){
            var $url = daicuo.config.file + '/' + daicuo.config.controll + '/' + daicuo.config.action + '/?'+ field +'='+value;
            return '<a class="text-purple" href="'+$url+'">'+value+'</a>';
        },
        // 回调函数－操作列
        operate : function(value, row, index, field){
            var id = row[daicuo.admin.table.uniqueId];
            var array = new Array(); 
            array.push('<div class="btn-group btn-group-sm">');
            if(daicuo.admin.table.urlPreview){
                array.push('<a class="btn btn-outline-secondary" href="'+daicuo.admin.table.urlPreview+id+'" data-toggle="preview" target="_blank"><i class="fa fa-fw fa-link"></i></a>');
            }
            if(daicuo.admin.table.urlEdit){
                array.push('<a class="btn btn-outline-secondary" href="'+daicuo.admin.table.urlEdit+id+'" data-toggle="edit" data-modal-xl="1"><i class="fa fa-fw fa-pencil"></i></a>');
            }
            if(daicuo.admin.table.urlDelete){
                array.push('<a class="btn btn-outline-secondary" href="'+daicuo.admin.table.urlDelete+id+'" data-toggle="delete"><i class="fa fa-fw fa-trash-o"></i></a>');
            }
            array.push('</div>');
            return array.join('');
        },
        // 表格列点击事件 data-events
        events : {
            'click [data-toggle="edit"]': function (event, value, row, index) {
                //daicuo.browser.console(event);
                //$(event.currentTarget).attr('data-callback','daicuo.' + daicuo.config.module + '.' + daicuo.config.controll + '.edit');
                var $btnCreate = $('a[data-toggle="create"]');
                if($btnCreate.length < 1){
                    $(event.currentTarget).removeAttr('data-toggle');
                    return false;
                }
                //窗口大小
                $(event.currentTarget).data('modal-xl',$btnCreate.data('modal-xl'));
                //是否回调
                if($btnCreate.data('callback')){
                    $(event.currentTarget).data('callback',$btnCreate.data('callback'));
                }
            }
        },
        // 箭头排序方法
        sortFormatter : function(value, row, index, field){
            return '<i class="fa fa-arrow-up mr-2 dc-order" data-toggle="dc-order" data-type="up" data-order="'+value+'" data-field="'+field+'"></i><i class="fa fa-arrow-down dc-order" data-toggle="dc-order" data-type="down" data-order="'+value+'" data-field="'+field+'"></i>';
        },
        // 箭头点击事件
        sortEvents: function(selector){
            $(document).on('click', '[data-toggle="dc-order"]', function() {
                var $url = './sort/?type='+$(this).data('type')+'&id='+$(this).parents('tr').data('uniqueid')+'&field='+$(this).data('field')+'&order='+$(this).data('order');
                $.ajax({
                    type: 'get',
                    cache: false,
                    url: $url,
                    dataType: 'json',
                    timeout: 3000,
                    success: function($json) {
                        $(selector).bootstrapTable('refresh');
                    }
                });
            });
        }
    },
    // 应用模块
    store : {
        //筛选选项
        query: function(params){
          return {
             pageNumber: params.pageNumber, 
             pageSize: params.pageSize,
             sortName: params.sortName,
             sortOrder: params.sortOrder,
             searchText: params.searchText,
             termId: $("#term_id").val(),
             price: $("#price").val()
          };
        }
    }
};